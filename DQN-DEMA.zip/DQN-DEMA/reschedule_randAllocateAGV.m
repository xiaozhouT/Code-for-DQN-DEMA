function reschedule_individual = reschedule_randAllocateAGV(Parameter,real_reschedule,reschedule_individual,information_pool,breakdown_fac)
if size(information_pool,1) == 1
    if breakdown_fac == 1
        reschedule = real_reschedule.F1;
    else
        reschedule = real_reschedule.F2;
    end
    under_load = information_pool(1).operation.position ~= inf;
    if any(under_load ~= 0) 
        job_under_load = information_pool(1).operation.Reschedule_integerschemes(under_load); 
        under_load_agv = information_pool(1).operation.position(under_load);
        for op = 1:size(job_under_load,2)
            integer = job_under_load(op);
            operation = mod(integer,100);
            job = (integer-operation)/100;
            if job == 1
                reschedule_individual.Code(4,operation) = under_load_agv(op);
            else
                reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = under_load_agv(op);
            end
        end
        temp = job_under_load' == reschedule(2,:);
        temp1 = [];
        for k = 1:size(temp,1)
            temp2 = reschedule(:,temp(k,:));
            temp1 = [temp1,temp2];  
        end
        temp3 = job_under_load' ~= reschedule(2,:);
        temp3 = all(temp3==1,1);
        temp4 = reschedule(:,temp3);
        reschedule = [temp1,temp4]; 
        for i = 1:size(temp4,2)
            integer = temp4(2,i);
            operation = mod(integer,100);
            job = (integer-operation)/100;
            agv = randi(Parameter.AGVNum);
            if job == 1
                reschedule_individual.Code(4,operation) = agv;
            else
                reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = agv;
            end
        end
        reschedule_individual.Code(1,end-information_pool(1).operation.Reschedule_operations+1:end) =  reschedule(1,:);
        reschedule_individual.Code(5,end-information_pool(1).operation.Reschedule_operations+1:end) =  reschedule(2,:);
    else 
        for i = 1:size(reschedule,2)
            integer = reschedule(2,i);
            operation = mod(integer,100);
            job = (integer-operation)/100;
            agv = randi(Parameter.AGVNum);
            if job == 1
                reschedule_individual.Code(4,operation) = agv;
            else
                reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = agv;
            end
        end
    end
else 
    for f = 1:Parameter.FactoryNum
        if f == 1
            reschedule = real_reschedule.F1;
            under_load = information_pool(f).operation.position ~= inf;
            if any(under_load ~= 0) 
                job_under_load = information_pool(f).operation.Reschedule_integerschemes(under_load); 
                under_load_agv = information_pool(f).operation.position(under_load); 
                for op = 1:size(job_under_load,2)
                    integer = job_under_load(op);
                    operation = mod(integer,100);
                    job = (integer-operation)/100;
                    if job == 1
                        reschedule_individual.Code(4,operation) = under_load_agv(op);
                    else
                        reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = under_load_agv(op);
                    end
                end
                temp = job_under_load' == reschedule(2,:);
                temp1 = [];
                for k = 1:size(temp,1)
                    temp2 = reschedule(:,temp(k,:));
                    temp1 = [temp1,temp2]; 
                end
                temp3 = job_under_load' ~= reschedule(2,:);
                temp3 = all(temp3==1,1);
                temp4 = reschedule(:,temp3); 

                reschedule1 = [temp1,temp4];
                for i = 1:size(temp4,2)
                    integer = temp4(2,i);
                    operation = mod(integer,100);
                    job = (integer-operation)/100;
                    agv = randi(Parameter.AGVNum);
                    if job == 1
                        reschedule_individual.Code(4,operation) = agv;
                    else
                        reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = agv;
                    end
                end
                reschedule_individual.Code(1,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations) =  reschedule1(1,:);
                reschedule_individual.Code(5,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations) =  reschedule1(2,:);
            else
                for i = 1:size(reschedule,2)
                    integer = reschedule(2,i);
                    operation = mod(integer,100);
                    job = (integer-operation)/100;
                    agv = randi(Parameter.AGVNum);
                    if job == 1
                        reschedule_individual.Code(4,operation) = agv;
                    else
                        reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = agv;
                    end
                end
            end
        else
            reschedule = real_reschedule.F2;
            under_load = information_pool(f).operation.position ~= inf;
            if any(under_load ~= 0) 
                job_under_load = information_pool(f).operation.Reschedule_integerschemes(under_load);
                under_load_agv = information_pool(f).operation.position(under_load); 
                for op = 1:size(job_under_load,2)
                    integer = job_under_load(op);
                    operation = mod(integer,100);
                    job = (integer-operation)/100;
                    if job == 1
                        reschedule_individual.Code(4,operation) = under_load_agv(op);
                    else
                        reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = under_load_agv(op);
                    end
                end
                temp = job_under_load' == reschedule(2,:);
                temp1 = [];
                for k = 1:size(temp,1)
                    temp2 = reschedule(:,temp(k,:));
                    temp1 = [temp1,temp2]; 
                end
                temp3 = job_under_load' ~= reschedule(2,:);
                temp3 = all(temp3==1,1);
                temp4 = reschedule(:,temp3);  
                reschedule2 = [temp1,temp4]; 
                for i = 1:size(temp4,2)
                    integer = temp4(2,i);
                    operation = mod(integer,100);
                    job = (integer-operation)/100;
                    agv = randi(Parameter.AGVNum);
                    if job == 1
                        reschedule_individual.Code(4,operation) = agv;
                    else
                        reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = agv;
                    end
                end
                reschedule_individual.Code(1,end-information_pool(2).operation.Reschedule_operations+1:end) =  reschedule2(1,:);
                reschedule_individual.Code(5,end-information_pool(2).operation.Reschedule_operations+1:end) =  reschedule2(2,:);
            else
                for i = 1:size(reschedule,2)
                    integer = reschedule(2,i);
                    operation = mod(integer,100);
                    job = (integer-operation)/100;
                    agv = randi(Parameter.AGVNum);
                    if job == 1
                        reschedule_individual.Code(4,operation) = agv;
                    else
                        reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = agv;
                    end
                end
            end
        end
    end
end
end