function Population = factoryinfor(Parameter,Population)
for i = 1:size(Population,1)
    temp11 = zeros(5,sum(Parameter.JobCOPNum));
    temp22 = zeros(5,sum(Parameter.JobCOPNum));
    for q = 1:Parameter.MaxJobNum
        if q == 1
            Fac = Population(i).Code(2,1);
        else
            Fac = Population(i).Code(2,sum(Parameter.JobCOPNum(1:q-1))+1);
        end
        if q == 1 && Fac == 1
            OPtemp1 = find(Population(i).Code(1,:)==q);
            temp11(1,OPtemp1) = Population(i).Code(1,OPtemp1);
            temp11(5,OPtemp1) = Population(i).Code(5,OPtemp1);
            temp11(2,1:Parameter.JobCOPNum(1)) = Population(i).Code(2,1:Parameter.JobCOPNum(1));
            temp11(3,1:Parameter.JobCOPNum(1)) = Population(i).Code(3,1:Parameter.JobCOPNum(1));
            temp11(4,1:Parameter.JobCOPNum(1)) = Population(i).Code(4,1:Parameter.JobCOPNum(1));
        elseif q == 1 && Fac == 2
            OPtemp2 = find(Population(i).Code(1,:)==q);
            temp22(1,OPtemp2) = Population(i).Code(1,OPtemp2);
            temp22(5,OPtemp2) = Population(i).Code(5,OPtemp2);
            temp22(2,1:Parameter.JobCOPNum(1)) = Population(i).Code(2,1:Parameter.JobCOPNum(1));
            temp22(3,1:Parameter.JobCOPNum(1)) = Population(i).Code(3,1:Parameter.JobCOPNum(1));
            temp22(4,1:Parameter.JobCOPNum(1)) = Population(i).Code(4,1:Parameter.JobCOPNum(1));
        elseif Fac == 1
            OPtemp1 = find(Population(i).Code(1,:)==q);
            temp11(1,OPtemp1) = Population(i).Code(1,OPtemp1);
            temp11(5,OPtemp1) = Population(i).Code(5,OPtemp1);
            temp11(2,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q))) = Population(i).Code(2,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)));
            temp11(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q))) = Population(i).Code(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)));
            temp11(4,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q))) = Population(i).Code(4,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)));
        elseif Fac == 2
            OPtemp2 = find(Population(i).Code(1,:)==q);
            temp22(1,OPtemp2) = Population(i).Code(1,OPtemp2);
            temp22(5,OPtemp2) = Population(i).Code(5,OPtemp2);
            temp22(2,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q))) = Population(i).Code(2,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)));
            temp22(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q))) = Population(i).Code(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)));
            temp22(4,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q))) = Population(i).Code(4,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)));
        end
    end
    Population(i).F1Infor = temp11;
    Population(i).F2Infor = temp22;
end

