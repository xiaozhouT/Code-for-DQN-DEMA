function [gradients, loss] = modelGradients(net, states, actions, targets)
    dlX = dlarray(states, 'CB');
    dlY = predict(net, dlX);
    
    % Compute Q-values for the taken actions
    idx = sub2ind(size(dlY), actions', 1:size(dlY, 2));
    qValues = dlY(idx);
    
    % Compute loss
    dlTargets = dlarray(targets, 'CB');
    loss = mse(qValues,dlTargets,"DataFormat",'CB');
    
    % Compute gradients
    gradients = dlgradient(loss, net.Learnables);
end