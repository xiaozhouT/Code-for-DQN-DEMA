function SelPopulation = Select(Parameter,Population,SelPopulation)
data = [-[Population.Rank]',[Population.Cd]'];
playerlist = ceil(size(data,1)*rand(Parameter.NP,2));

playerSize = size(playerlist,1);
for i = 1:playerSize
    players = playerlist(i,:);       
    winner = players(1);
    for j = 2:length(players)
        score1 = data(winner,:);     
        score2 = data(players(j),:); 
        if score2(1) > score1(1)     
            winner = players(j);     
        elseif score2(1)==score1(1)
            try
                if score2(2)>score1(2)
                    winner = players(j);
                end
            catch
            end
        end
    end
    SelPopulation(i) = Population(winner);
end


