function [reschedule_individual,need_reschedule] = adjust_encode(Parameter,reschedule_individual,information_pool)

if size(information_pool,1) == 1 
    need_reschedule = [reschedule_individual.Code(1,information_pool.operation.Reschedule_globalindex);...
        reschedule_individual.Code(5,information_pool.operation.Reschedule_globalindex)];
    reschedule_individual.Code(1,information_pool.operation.Reschedule_globalindex) = 0;
    reschedule_individual.Code(5,information_pool.operation.Reschedule_globalindex) = 0;
    nonzero_indices = find(reschedule_individual.Code(1,:) ~= 0);
    reschedule_individual.Code(1,:) = [reschedule_individual.Code(1,nonzero_indices),reschedule_individual.Code(1,information_pool.operation.Reschedule_globalindex)];
    reschedule_individual.Code(5,:) = [reschedule_individual.Code(5,nonzero_indices),reschedule_individual.Code(5,information_pool.operation.Reschedule_globalindex)];

    reschedule_individual.Code(1,end-information_pool.operation.Reschedule_operations+1:end) =  need_reschedule(1,:);
    reschedule_individual.Code(5,end-information_pool.operation.Reschedule_operations+1:end) =  need_reschedule(2,:);
    reschedule_individual = FixingEncoding(Parameter, reschedule_individual);
else 
    F1_need_reschedule = [reschedule_individual.Code(1,information_pool(1).operation.Reschedule_globalindex);...
        reschedule_individual.Code(5,information_pool(1).operation.Reschedule_globalindex)];

    F2_need_reschedule = [reschedule_individual.Code(1,information_pool(2).operation.Reschedule_globalindex);...
        reschedule_individual.Code(5,information_pool(2).operation.Reschedule_globalindex)];

    need_reschedule = [F1_need_reschedule,F2_need_reschedule];

    index = [information_pool(1).operation.Reschedule_globalindex,information_pool(2).operation.Reschedule_globalindex];
    reschedule_individual.Code(1,index) = 0;
    reschedule_individual.Code(5,index) = 0;
    nonzero_indices = find(reschedule_individual.Code(1,:) ~= 0);
    reschedule_individual.Code(1,:) = [reschedule_individual.Code(1,nonzero_indices),reschedule_individual.Code(1,index)];
    reschedule_individual.Code(5,:) = [reschedule_individual.Code(5,nonzero_indices),reschedule_individual.Code(5,index)];

    reschedule_individual.Code(1,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end) =  [need_reschedule(1,:)];
    reschedule_individual.Code(5,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end) =  [need_reschedule(2,:)];
    reschedule_individual = FixingEncoding(Parameter, reschedule_individual);
end
end


function  reschedule_individual = FixingEncoding(Parameter, reschedule_individual)
temp1 = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val1 =  reschedule_individual(1).Code(1,j);
    temp1(val1) = temp1(val1)+1;
    reschedule_individual(1).Code(5,j) = val1*100+temp1(val1);
end
end