function reSelPopulation = reMutation(Parameter,reSelPopulation,information_pool)
for j = 1:3:Parameter.NP
    p1 = rand;
    if Parameter.Pm > p1
        pos1 = unidrnd(Parameter.NP);
        c = randi(2);
        switch c
            case 1
                reSelPopulation = reSinglePointMutation(pos1,Parameter,reSelPopulation,information_pool); 
            case 2
                reSelPopulation = reReverseOrderMutation(pos1,Parameter,reSelPopulation,information_pool); 
        end
        reSelPopulation = FixingEncoding(pos1,Parameter,reSelPopulation);
        reSelPopulation = reRandomizeMutation(pos1,Parameter,reSelPopulation,information_pool); 
        reSelPopulation = FixingEncoding(pos1,Parameter,reSelPopulation);
    else
        continue;
    end
end
end

function reSelPopulation = reSinglePointMutation(pos1,Parameter,reSelPopulation,information_pool) 
father = reSelPopulation(pos1).Code(1,:);
if size(information_pool,1) == 1
    index1 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations+1,...
        sum(Parameter.JobCOPNum)],1,1);
    index2 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations+1,...
        sum(Parameter.JobCOPNum)],1,1);

    while index1 == index2
        index1 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations+1,...
            sum(Parameter.JobCOPNum)],1,1);
        index2 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations+1,...
            sum(Parameter.JobCOPNum)],1,1);
    end

    father(index1) = reSelPopulation(pos1).Code(1,index2);
    father(index2) = reSelPopulation(pos1).Code(1,index1);
    reSelPopulation(pos1).Code(1,:) = father;
else
    for f = 1:Parameter.FactoryNum
        if f == 1
            index1 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
            index2 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
            while index1 == index2
                index1 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                    information_pool(2).operation.Reschedule_operations+1,...
                    sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
                index2 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                    information_pool(2).operation.Reschedule_operations+1,...
                    sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
            end
            father(index1) = reSelPopulation(pos1).Code(1,index2);
            father(index2) = reSelPopulation(pos1).Code(1,index1);
        else
            index1 = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)],1,1);
            index2 = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)],1,1);
            while index1 == index2
                index1 = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                    sum(Parameter.JobCOPNum)],1,1);
                index2 = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                    sum(Parameter.JobCOPNum)],1,1);
            end
            father(index1) = reSelPopulation(pos1).Code(1,index2);
            father(index2) = reSelPopulation(pos1).Code(1,index1);
        end
    end
    reSelPopulation(pos1).Code(1,:) = father;
end
end

function reSelPopulation = reReverseOrderMutation(pos1,Parameter,reSelPopulation,information_pool)
if size(information_pool,1) == 1
    index1 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations+1,...
        sum(Parameter.JobCOPNum)],1,1);
    index2 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations+1,...
        sum(Parameter.JobCOPNum)],1,1);
    indext = [index1,index2];
    indext = sort(indext);
    reSelPopulation(pos1).Code(1,indext(1):indext(2))=fliplr(reSelPopulation(pos1).Code(1,indext(1):indext(2)));
else
    for f = 1:Parameter.FactoryNum
        if f == 1
            index1 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
            index2 = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
            indext = [index1,index2];
            indext = sort(indext);
            reSelPopulation(pos1).Code(1,indext(1):indext(2))=fliplr(reSelPopulation(pos1).Code(1,indext(1):indext(2)));
        else
            index1 = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)],1,1);
            index2 = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)],1,1);
            indext = [index1,index2];
            indext = sort(indext);
            reSelPopulation(pos1).Code(1,indext(1):indext(2))=fliplr(reSelPopulation(pos1).Code(1,indext(1):indext(2)));
        end
    end
end
end


function reSelPopulation = reRandomizeMutation(pos1,Parameter,reSelPopulation,information_pool)

if size(information_pool,1) == 1
    index = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations+1,...
        sum(Parameter.JobCOPNum)],1,1);

    val = reSelPopulation(pos1).Code(5,index);
    p = mod(val,100);
    q = (val - p)/100;
    AM = Parameter.AvalueMachine{q,p};
    while length(AM) == 1
        index = unidrnd(sum(Parameter.JobCOPNum));
        val = reSelPopulation(pos1).Code(5,index);
        p = mod(val,100);
        q = (val - p)/100;
        AM = Parameter.AvalueMachine{q,p};
    end
    if q == 1
        TAM = reSelPopulation(pos1).Code(3,p);
    else
        TAM = reSelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p);
    end
    t1 = length(AM);
    m = AM(1,randi(t1));
    while  m == TAM
        m = AM(1,randi(t1));
    end
    if q == 1
        reSelPopulation(pos1).Code(3,p) = m;
    else
        reSelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p) = m;
    end
else
    for f = 1:Parameter.FactoryNum
        if f == 1
            index = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
            val = reSelPopulation(pos1).Code(5,index);
            p = mod(val,100);
            q = (val - p)/100;
            AM = Parameter.AvalueMachine{q,p};
            while length(AM) == 1
                index = randi([sum(Parameter.JobCOPNum)-information_pool(1).operation.Reschedule_operations-...
                    information_pool(2).operation.Reschedule_operations+1,...
                    sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations],1,1);
                val = reSelPopulation(pos1).Code(5,index);
                p = mod(val,100);
                q = (val - p)/100;
                AM = Parameter.AvalueMachine{q,p};
            end
            if q == 1
                TAM = reSelPopulation(pos1).Code(3,p);
            else
                TAM = reSelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p);
            end
            t1 = length(AM);
            m = AM(1,randi(t1));
            while  m == TAM
                m = AM(1,randi(t1));
            end
            if q == 1
                reSelPopulation(pos1).Code(3,p) = m;
            else
                reSelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p) = m;
            end
        else
            index = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                sum(Parameter.JobCOPNum)],1,1);
            val = reSelPopulation(pos1).Code(5,index);
            p = mod(val,100);
            q = (val - p)/100;
            AM = Parameter.AvalueMachine{q,p};
            while length(AM) == 1
                index = randi([sum(Parameter.JobCOPNum)-information_pool(2).operation.Reschedule_operations+1,...
                    sum(Parameter.JobCOPNum)],1,1);
                val = reSelPopulation(pos1).Code(5,index);
                p = mod(val,100);
                q = (val - p)/100;
                AM = Parameter.AvalueMachine{q,p};
            end
            if q == 1
                TAM = reSelPopulation(pos1).Code(3,p);
            else
                TAM = reSelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p);
            end
            t1 = length(AM);
            m = AM(1,randi(t1));
            while  m == TAM
                m = AM(1,randi(t1));
            end
            if q == 1
                reSelPopulation(pos1).Code(3,p) = m;
            else
                reSelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p) = m;
            end
        end
    end
end
end

function reSelPopulation = FixingEncoding(pos1,Parameter,reSelPopulation)
temp1 = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val1 = reSelPopulation(pos1).Code(1,j);
    temp1(val1) = temp1(val1)+1;
    reSelPopulation(pos1).Code(5,j) = val1*100+temp1(val1);
end
end

