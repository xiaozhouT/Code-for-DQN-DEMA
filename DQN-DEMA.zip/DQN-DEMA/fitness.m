function Population = fitness(Population,Parameter)
for i = 1:size(Population,1)
    if  isempty(Population(i).Fit)
        break;
    else
        Population(i).Rank = Inf;
        Population(i).Cd = 0;
        Population(i).Fit = zeros(1,2);
        
        Population(i).F1MUCO2 = 0;
        Population(i).F1MLCO2 = 0;
        Population(i).F1AGVUCO2 = 0;
        Population(i).F1AGVLCO2 = 0;
        Population(i).F1JobCmax = zeros(1,Parameter.MaxJobNum);
        Population(i).F1MachineCmax = zeros(1,Parameter.MaxMachineNum);
        Population(i).F1AGV = zeros(2,Parameter.AGVNum);
        Population(i).F1AGVextralT = zeros(2,Parameter.AGVNum);
        Population(i).F1Decode = [];
        Population(i).F1Infor = [];
        
        Population(i).F2MUCO2 = 0;
        Population(i).F2MLCO2 = 0;
        Population(i).F2AGVUCO2 = 0;
        Population(i).F2AGVLCO2 = 0;
        Population(i).F2JobCmax = zeros(1,Parameter.MaxJobNum);
        Population(i).F2MachineCmax = zeros(1,Parameter.MaxMachineNum);
        Population(i).F2AGV = zeros(2,Parameter.AGVNum);
        Population(i).F2AGVextralT = zeros(2,Parameter.AGVNum);
        Population(i).F2Decode = [];
        Population(i).F2Infor = [];
    end
end
Population = factoryinfor(Parameter,Population);
Population =  factorycalculate(Parameter,Population); 
Population = Cmax_CO2(Parameter,Population);
end
function Population =  factorycalculate(Parameter,Population)
for i = 1:size(Population,1)
    for f = 1:Parameter.FactoryNum
        if f == 1
            tempInfor = Population(i).F1Infor; 
            temp = nnz(tempInfor(5,:));
            if temp ~=0 
                [Population,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = calculate(Parameter,Population,tempInfor,temp);
                Population(i).F1JobCmax = JobCmax;
                Population(i).F1MachineCmax = MachineCmax;
                Population(i).F1AGV = AGVInfor;
                Population(i).F1Decode = Decode;
                Population(i).F1AGVextralT = AGVextralT;
            end
        else
            tempInfor = Population(i).F2Infor;
            temp = nnz(tempInfor(5,:));
            if temp ~=0 
                [Population,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = calculate(Parameter,Population,tempInfor,temp);
                Population(i).F2JobCmax = JobCmax;
                Population(i).F2MachineCmax = MachineCmax;
                Population(i).F2AGV = AGVInfor;
                Population(i).F2Decode = Decode;
                Population(i).F2AGVextralT = AGVextralT;
            end
        end
    end
end
end
function [Population,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = calculate(Parameter,Population,tempInfor,temp)
Decode = zeros(11,temp);
JobCmax = zeros(1,Parameter.MaxJobNum); 
MachineCmax = zeros(1,Parameter.MaxMachineNum); 
AGVInfor = zeros(2,Parameter.AGVNum); 
AGVextralT = zeros(2,Parameter.AGVNum);
n = 0;
totalOP = sum(Parameter.JobCOPNum);
for j = 1:totalOP
    xiuzheng = false;
    OperationInteger = tempInfor(5,j);
    if OperationInteger == 0
        continue;
    else
        p = (mod(OperationInteger,100));  
        q = (OperationInteger-p)/100;     
        AM = Parameter.AvalueMachine{q,p}; 
        PT = Parameter.ProcessTime{q,p};   
        TST = Parameter.SetupTime(q,p);    
        n = n+1;
    end
    if q == 1
        TAM = tempInfor(3,p);  
        TAGV = tempInfor(4,p); 
    else
        TAM = tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p);
        TAGV = tempInfor(4,sum(Parameter.JobCOPNum(1:q-1))+p);
    end
    t1 = length(AM);
    for t2 = 1:t1
        if AM(t2) == TAM
            TPT = PT(t2);
            break;
        end
    end
    if all(MachineCmax(1,:)==0)
        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60;
        car_load_t = Parameter.AGVTime(1,TAM+1)/60;
        AGVStart = AGVInfor(1,TAGV)+ car_no_load_t;
        StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
        AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
        AGVInfor(2,TAGV) = TAM;
        tempj = j;
    else
        if q == 1
            if q == Decode(1,n-1)  
                if TAM == tempInfor(3,p-1)
                    TAGV = 0; 
                    car_no_load_t = 0;
                    car_load_t = 0;
                    AGVStart = 0;
                    xiuzheng = true;
                    Decode(10,n-1) = Decode(10,n-1)-Decode(8,n-1); 
                    MachineCmax(1,TAM) = Decode(10,n-1);
                    JobCmax(1,q) = Decode(10,n-1);
                    StartT = Decode(10,n-1); 
                    tempj = j;
                else 
                    car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,p-1)+1)/60;
                    car_load_t = Parameter.AGVTime(tempInfor(3,p-1)+1,TAM+1)/60;
                    if AGVInfor(1,TAGV) + car_no_load_t >= JobCmax(1,q)
                        temp1 = AGVInfor(1,TAGV)+car_no_load_t;
                    else
                        temp1 = JobCmax(1,q);
                    end
                    if temp1 + car_load_t >= MachineCmax(1,TAM)
                        StartT = temp1 + car_load_t;
                    else
                        StartT = MachineCmax(1,TAM);
                    end
                    AGVStart = temp1;
                    AGVInfor(1,TAGV) = temp1+car_load_t;
                    AGVInfor(2,TAGV) = TAM;
                    tempj = j;
                end
            else
                if JobCmax(1,q) == 0 
                    car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60;
                    car_load_t = Parameter.AGVTime(1,TAM+1)/60;
                    if AGVInfor(1,TAGV) + car_no_load_t + car_load_t >=  MachineCmax(TAM) 
                        StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t ; 
                    else
                        StartT = MachineCmax(TAM) ;
                    end
                    AGVStart = AGVInfor(1,TAGV) + car_no_load_t;
                    AGVInfor(1,TAGV) = AGVInfor(1,TAGV)+car_no_load_t+car_load_t;
                    AGVInfor(2,TAGV) = TAM;
                    tempj = j;
                else
                    if TAM == tempInfor(3,p-1)
                        in1 = find(Decode(11,:) == OperationInteger-1);
                        tempin1 = Decode(2,in1+1:n-1);
                        if ismember(tempInfor(3,p-1),tempin1)
                            car_no_load_t = 0;
                            car_load_t = 0;
                            AGVStart = 0;
                            TAGV = 0;
                            StartT =  MachineCmax(1,TAM);
                            tempj = j;
                        else
                            car_no_load_t = 0;
                            car_load_t = 0;
                            TAGV = 0;
                            xiuzheng = true;
                            AGVStart = 0;
                            Decode(10,in1) = Decode(10,in1)-Decode(8,in1);
                            MachineCmax(1,TAM) = Decode(10,in1);
                            JobCmax(1,q) = Decode(10,in1);
                            StartT = Decode(10,in1);
                            tempj = j;
                        end
                    else
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,p-1)+1)/60;
                        car_load_t = Parameter.AGVTime(tempInfor(3,p-1)+1,TAM+1)/60;
                        if AGVInfor(1,TAGV) + car_no_load_t >= JobCmax(1,q) 
                            temp1 = AGVInfor(1,TAGV) + car_no_load_t;
                        else
                            temp1 = JobCmax(1,q);
                        end
                        if temp1 + car_load_t >= MachineCmax(1,tempInfor(3,p)) 
                            StartT = temp1 + car_load_t ;
                        else
                            StartT = MachineCmax(1,tempInfor(3,p));
                        end
                        AGVStart = temp1;
                        AGVInfor(1,TAGV) = temp1 + car_load_t; 
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j; 
                    end
                end
            end
        else
            if q == tempInfor(1,tempj) 
                if TAM == tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1) 
                    TAGV = 0;
                    car_no_load_t = 0;
                    car_load_t = 0;
                    AGVStart = 0;
                    xiuzheng = true;
                    Decode(10,n-1) = Decode(10,n-1)-Decode(8,n-1); 
                    MachineCmax(1,TAM) = Decode(10,n-1);
                    JobCmax(1,q) = Decode(10,n-1);
                    StartT = Decode(10,n-1); 
                    tempj = j;
                else
                    car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60; 
                    car_load_t = Parameter.AGVTime(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1,TAM+1)/60; 
                    if AGVInfor(1,TAGV) + car_no_load_t >= JobCmax(1,q) 
                        temp1 = AGVInfor(1,TAGV)+car_no_load_t;
                    else
                        temp1 = JobCmax(1,q);
                    end
                    if temp1 + car_load_t >= MachineCmax(1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p)) 
                        StartT = temp1 + car_load_t ;
                    else
                        StartT = MachineCmax(1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p));
                    end
                    AGVStart = temp1;
                    AGVInfor(1,TAGV) = temp1 + car_load_t; 
                    AGVInfor(2,TAGV) = TAM;
                    tempj = j;
                end
            else
                if JobCmax(1,q) == 0
                    car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60; 
                    car_load_t = Parameter.AGVTime(1,TAM+1)/60;
                    if AGVInfor(1,TAGV) + car_no_load_t + car_load_t >=  MachineCmax(1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p))
                        StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t ; 
                    else
                        StartT = MachineCmax(1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p));
                    end
                    AGVStart = AGVInfor(1,TAGV) + car_no_load_t;
                    AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                    AGVInfor(2,TAGV) = TAM;
                    tempj = j; 
                else
                    if TAM == tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)
                        in1 = find(Decode(11,:) == OperationInteger-1);
                        tempin1 = Decode(2,in1+1:n-1);
                        if ismember(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1),tempin1)
                            car_no_load_t = 0;
                            car_load_t = 0;
                            AGVStart = 0;
                            TAGV = 0;
                            StartT = MachineCmax(1,TAM); 
                            tempj = j;
                        else
                            car_no_load_t = 0;
                            car_load_t = 0;
                            TAGV = 0;
                            AGVStart = 0;
                            xiuzheng = true;
                            Decode(10,in1) = Decode(10,in1)-Decode(8,in1);
                            MachineCmax(1,TAM) = Decode(10,in1);
                            JobCmax(1,q) = Decode(10,in1);
                            StartT = Decode(10,in1);
                            tempj = j;
                        end
                    else
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60; 
                        car_load_t = Parameter.AGVTime(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1,TAM+1)/60; 
                        if AGVInfor(1,TAGV) + car_no_load_t >= JobCmax(1,q)
                            temp1 = AGVInfor(1,TAGV) + car_no_load_t;
                        else
                            temp1 = JobCmax(1,q);
                        end
                        if temp1 + car_load_t >= MachineCmax(1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p)) 
                            StartT = temp1 + car_load_t ;
                        else
                            StartT = MachineCmax(1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p));
                        end
                        AGVStart = temp1;
                        AGVInfor(1,TAGV) = temp1 + car_load_t; 
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j; 
                    end
                end
            end
        end
    end
    Decode(1,n) = q; 
    Decode(2,n) = TAM;
    Decode(3,n) = TAGV;
    Decode(4,n) = car_no_load_t;
    Decode(5,n) = AGVStart; 
    Decode(6,n) = car_load_t;
    Decode(7,n) = AGVStart + car_load_t; 
    Decode(8,n) = TST;
    Decode(9,n) = StartT;
    if xiuzheng 
        Decode(10,n) = StartT+TPT+TST;
    else
        Decode(10,n) = StartT+TST+TPT+TST;    
    end
    Decode(11,n) = OperationInteger;
    MachineCmax(1,TAM) = Decode(10,n);  
    JobCmax(1,q) = Decode(10,n);
end

for q = 1:Parameter.MaxJobNum
    temp = find(Decode(1,:)==q);
    if isempty(temp)
        continue;
    end
    finaMachine = Decode(2,temp(end));
    car_no_load_retrieval = zeros(1,Parameter.AGVNum);
    for x = 1:Parameter.AGVNum
        current_position_of_car = AGVInfor(2,x) + 1;
        car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,finaMachine+1)/60;
    end
    if min(car_no_load_retrieval) >= JobCmax(1,q)
        carnum = find(car_no_load_retrieval == min(car_no_load_retrieval),1); 
        carposition = AGVInfor(2,carnum);
        car_no_load_t = Parameter.AGVTime(carposition+1,finaMachine+1)/60;
        car_load_t = Parameter.AGVTime(finaMachine+1,end)/60;
        AGVextralT(1,carnum) =  AGVextralT(1,carnum)+car_no_load_t; 
        AGVextralT(2,carnum) =  AGVextralT(2,carnum)+car_load_t;
        AGVInfor(1,carnum) = AGVInfor(1,carnum) + car_no_load_t + car_load_t;
        AGVInfor(2,carnum) = size(Parameter.AGVTime,2)-1;
        JobCmax(q) =  AGVInfor(1,carnum) + car_no_load_t + car_load_t;
    else
        car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval; 
        tmp = car_no_load_retrieval_temp > 0; 
        carnum = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1); 
        carposition = AGVInfor(2,carnum);
        car_no_load_t = Parameter.AGVTime(carposition+1,finaMachine+1)/60; 
        car_load_t = Parameter.AGVTime(finaMachine+1,end)/60;
        AGVextralT(1,carnum) =  AGVextralT(1,carnum)+car_no_load_t; 
        AGVextralT(2,carnum) =  AGVextralT(2,carnum)+car_load_t; 
        AGVInfor(1,carnum) = AGVInfor(1,carnum) + car_no_load_t + car_load_t;
        AGVInfor(2,carnum) = size(Parameter.AGVTime,2)-1;
        JobCmax(q) =  JobCmax(1,q) + car_load_t;
    end
end

for n = 1:Parameter.AGVNum
    carposition2 = AGVInfor(2,n); 
    car_no_load_t = Parameter.AGVTime(carposition2+1,0+1)/60;
    car_load_t = 0;

    AGVextralT(1,n) =  AGVextralT(1,n)+car_no_load_t;
    AGVextralT(2,n) =  AGVextralT(2,n)+car_load_t; 
    AGVInfor(1,n) = AGVInfor(1,n) + car_no_load_t + car_load_t;
    AGVInfor(2,n) = 0; 
end
end
function Population = Cmax_CO2(Parameter,Population)
for i = 1:size(Population,1)

    temp1 = max(Population(i).F1JobCmax);
    temp2 = max(Population(i).F2JobCmax);
    Population(i).Fit(1,1) = max(temp1,temp2);
    
    if nnz(Population(i).F1Decode) ~=0
        [~,pos1] = sort(Population(i).F1Decode(2,:));
        F1Decodetmep = Population(i).F1Decode(:,pos1);
    end

    if nnz(Population(i).F2Decode) ~=0
        [~,pos2] = sort(Population(i).F2Decode(2,:));
        F2Decodetmep = Population(i).F2Decode(:,pos2);
    end
    for Factemp = 1:Parameter.FactoryNum
        if Factemp == 1
            if nnz(Population(i).F1Decode) ~=0
                [~,First_m_index] = unique(F1Decodetmep(2,:));
                for j = 1:size(Population(i).F1Decode,2)
                    if ismember(j,First_m_index)
                        Population(i).F1MUCO2 = Population(i).F1MUCO2 + F1Decodetmep(9,j)/60 * Parameter.MULP(1,F1Decodetmep(2,j)) * Parameter.EF;
                        Population(i).F1MLCO2 = Population(i).F1MLCO2 + (F1Decodetmep(10,j) - F1Decodetmep(9,j))/60 * ...
                            Parameter.MLP(1,F1Decodetmep(2,j)) * Parameter.EF;
                    else
                        Population(i).F1MUCO2 = Population(i).F1MUCO2 + (F1Decodetmep(9,j) - F1Decodetmep(10,j-1))/60 * Parameter.MULP(1,F1Decodetmep(2,j)) * Parameter.EF;
                        Population(i).F1MLCO2 = Population(i).F1MLCO2 + (F1Decodetmep(10,j) - F1Decodetmep(9,j))/60 * ...
                            Parameter.MLP(1,F1Decodetmep(2,j)) * Parameter.EF;
                    end
                end
                Population(i).F1AGVUCO2 = (sum(Population(i).F1Decode(4,:)) + sum(Population(i).F1AGVextralT(1,:)))/60 * Parameter.AGVULP * Parameter.EF; 
                Population(i).F1AGVLCO2 = (sum(Population(i).F1Decode(6,:)) + sum(Population(i).F1AGVextralT(2,:)))/60 * Parameter.AGVLP * Parameter.EF;  
            end
        else
            if nnz(Population(i).F2Decode) ~=0
                [~,First_m_index] = unique(F2Decodetmep(2,:));
                for j = 1:size(Population(i).F2Decode,2)
                    if ismember(j,First_m_index) 
                        Population(i).F2MUCO2 = Population(i).F2MUCO2 + F2Decodetmep(9,j)/60 * Parameter.MULP(1,F2Decodetmep(2,j)) * Parameter.EF; 
                        Population(i).F2MLCO2 = Population(i).F2MLCO2 + (F2Decodetmep(10,j) - F2Decodetmep(9,j))/60 * ...
                            Parameter.MLP(1,F2Decodetmep(2,j)) * Parameter.EF;
                    else
                        Population(i).F2MUCO2 = Population(i).F2MUCO2 + (F2Decodetmep(9,j) - F2Decodetmep(10,j-1))/60 * Parameter.MULP(1,F2Decodetmep(2,j)) * Parameter.EF;
                        Population(i).F2MLCO2 = Population(i).F2MLCO2 + (F2Decodetmep(10,j) - F2Decodetmep(9,j))/60 * ...
                            Parameter.MLP(1,F2Decodetmep(2,j)) * Parameter.EF;
                    end
                end
                Population(i).F2AGVUCO2 = (sum(Population(i).F2Decode(4,:)) + sum(Population(i).F2AGVextralT(1,:)))/60 * Parameter.AGVULP * Parameter.EF;
                Population(i).F2AGVLCO2 = (sum(Population(i).F2Decode(6,:)) + sum(Population(i).F2AGVextralT(2,:)))/60 * Parameter.AGVLP * Parameter.EF;  
            end
        end
    end

    Population(i).Fit(1,2) = Population(i).F1MUCO2 + Population(i).F1MLCO2 + Population(i).F1AGVUCO2 + Population(i).F1AGVLCO2 + ...
        Population(i).F2MUCO2 + Population(i).F2MLCO2 + Population(i).F2AGVUCO2 + Population(i).F2AGVLCO2;
end
end

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        