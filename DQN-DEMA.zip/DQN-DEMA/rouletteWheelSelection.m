function selected_indices = rouletteWheelSelection(fit,Parameter)

fit(isnan(fit(:,1)),:) = [];

fit(isnan(fit(:,2)),:) = [];

if ~isempty(fit)
    fitness1 = fit(:,1);
    if size(fitness1,1)==1
        normalized_fitness1 = 1;
    else
        if max(fitness1) == min(fitness1)
            normalized_fitness1 = ones(size(fitness1,1),1);
        else
            normalized_fitness1 = (fitness1 - min(fitness1))./(max(fitness1) - min(fitness1));
        end
    end

    fitness2 = fit(:,2);
    if size(fitness2,1)==1
        normalized_fitness2 = 1;
    else
        if max(fitness2) == min(fitness2)
            normalized_fitness2 = ones(size(fitness2),1);
        else
            normalized_fitness2 = (fitness2 - min(fitness2))./(max(fitness2) - min(fitness2));
        end
    end

    combined_fitness = normalized_fitness1 + normalized_fitness2;
    selection_probabilities = combined_fitness / sum(combined_fitness);
    cumulative_probabilities = cumsum(selection_probabilities);
    selected_indices = zeros(1, Parameter.NP);

    for i = 1:Parameter.NP
        r = rand(1);
        selected_index = find(cumulative_probabilities >= r,1);
        selected_indices(1,i) = selected_index;
    end
else
    selected_indices = ones(1,Parameter.NP);
end
selected_indices = selected_indices';


