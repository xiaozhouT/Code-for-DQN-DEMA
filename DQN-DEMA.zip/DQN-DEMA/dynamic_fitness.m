function reschedule_individual = dynamic_fitness(reschedule_individual,Parameter,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time)

for i = 1:size(reschedule_individual,1)

    reschedule_individual(i).Rank = Inf;
    reschedule_individual(i).Cd = 0;
    reschedule_individual(i).Fit = zeros(1,2);
    if size(information_pool,1)
        if breakdown_fac == 1

            reschedule_individual(i).F1MUCO2 = 0;
            reschedule_individual(i).F1MLCO2 = 0;
            reschedule_individual(i).F1AGVUCO2 = 0;
            reschedule_individual(i).F1AGVLCO2 = 0;
            reschedule_individual(i).F1JobCmax = zeros(1,Parameter.MaxJobNum);
            reschedule_individual(i).F1MachineCmax = zeros(1,Parameter.MaxMachineNum);
            reschedule_individual(i).F1AGV = zeros(2,Parameter.AGVNum);
            reschedule_individual(i).F1AGVextralT = zeros(2,Parameter.AGVNum);
            reschedule_individual(i).F1Infor = [];
        else
            reschedule_individual(i).F2MUCO2 = 0;
            reschedule_individual(i).F2MLCO2 = 0;
            reschedule_individual(i).F2AGVUCO2 = 0;
            reschedule_individual(i).F2AGVLCO2 = 0;
            reschedule_individual(i).F2JobCmax = zeros(1,Parameter.MaxJobNum);
            reschedule_individual(i).F2MachineCmax = zeros(1,Parameter.MaxMachineNum);
            reschedule_individual(i).F2AGV = zeros(2,Parameter.AGVNum);
            reschedule_individual(i).F2AGVextralT = zeros(2,Parameter.AGVNum);
            reschedule_individual(i).F2Infor = [];
        end
    else 
        reschedule_individual(i).F1MUCO2 = 0;
        reschedule_individual(i).F1MLCO2 = 0;
        reschedule_individual(i).F1AGVUCO2 = 0;
        reschedule_individual(i).F1AGVLCO2 = 0;
        reschedule_individual(i).F1JobCmax = zeros(1,Parameter.MaxJobNum);
        reschedule_individual(i).F1MachineCmax = zeros(1,Parameter.MaxMachineNum);
        reschedule_individual(i).F1AGV = zeros(2,Parameter.AGVNum);
        reschedule_individual(i).F1AGVextralT = zeros(2,Parameter.AGVNum);
        reschedule_individual(i).F1Infor = [];

        reschedule_individual(i).F2MUCO2 = 0;
        reschedule_individual(i).F2MLCO2 = 0;
        reschedule_individual(i).F2AGVUCO2 = 0;
        reschedule_individual(i).F2AGVLCO2 = 0;
        reschedule_individual(i).F2JobCmax = zeros(1,Parameter.MaxJobNum);
        reschedule_individual(i).F2MachineCmax = zeros(1,Parameter.MaxMachineNum);
        reschedule_individual(i).F2AGV = zeros(2,Parameter.AGVNum);
        reschedule_individual(i).F2AGVextralT = zeros(2,Parameter.AGVNum);
        reschedule_individual(i).F2Infor = [];
    end
end
reschedule_individual = factoryinfor(Parameter,reschedule_individual);  

reschedule_individual =  dynamic_factorycalculate(Parameter,reschedule_individual,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time); 

reschedule_individual  = dynamic_co2andcmax(Parameter,reschedule_individual,information_pool,breakdown_fac,breakdown_machine,repair_time);