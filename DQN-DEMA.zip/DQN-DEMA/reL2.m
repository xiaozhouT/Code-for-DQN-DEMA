function reIndividualsLS = reL2(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time)

reIndividualsLS = reEliteIndividual_temp(i);
reIndividualsLS = recriticalbottleneck(reIndividualsLS,Parameter,information_pool,breakdown_fac); 

temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = reIndividualsLS.Code(1,j);
    temp(val) = temp(val)+1;
    reIndividualsLS.Code(5,j) = val*100+temp(val);
end

reIndividualsLS = dynamic_adjust(reIndividualsLS,Parameter,information_pool);

reIndividualsLS = dynamic_fitness(reIndividualsLS,Parameter,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
end

function reIndividualsLS = recriticalbottleneck(reIndividualsLS,Parameter,information_pool,breakdown_fac)

if size(information_pool,1) == 1

    if breakdown_fac == 1
        tempDecode = reIndividualsLS.F1Decode;
        tempCriticalPath = reIndividualsLS.F1CriticalPath;
    else
        tempDecode = reIndividualsLS.F2Decode;
        tempCriticalPath = reIndividualsLS.F2CriticalPath;
    end

    temp = size(tempDecode,2);
    for k = temp-information_pool(1).operation.Reschedule_operations+1:temp
       if ~ismember(k,tempCriticalPath)
           retempCriticalPath=[];
           continue
       else
           pos = find(tempCriticalPath==k,1);
           retempCriticalPath = tempCriticalPath(pos:end);
           break
       end
    end

    if ~isempty(retempCriticalPath)
        reIndividualsLS = reExecutecriticalbottleneck(reIndividualsLS,tempDecode,retempCriticalPath,Parameter);
    end
else 
    for f = 1:Parameter.FactoryNum
        if fac == 1
            tempDecode = reIndividualsLS.F1Decode;
            tempCriticalPath = reIndividualsLS.F1CriticalPath;
            temp = size(tempDecode,2);
            for k = temp-information_pool(f).operation.Reschedule_operations+1:temp
                if ~ismember(k,tempCriticalPath)
                    retempCriticalPath=[];
                    continue
                else
                    pos = find(tempCriticalPath==k,1);
                    retempCriticalPath = tempCriticalPath(pos:end);
                    break
                end
            end
            if ~isempty(retempCriticalPath)
                reIndividualsLS = reExecutecriticalbottleneck(reIndividualsLS,tempDecode,retempCriticalPath,Parameter);
            end
        else
            tempDecode = reIndividualsLS.F2Decode;
            tempCriticalPath = reIndividualsLS.F2CriticalPath;
            temp = size(tempDecode,2);
            for k = temp-information_pool(f).operation.Reschedule_operations+1:temp
                if ~ismember(k,tempCriticalPath)
                    retempCriticalPath=[];
                    continue
                else
                    pos = find(tempCriticalPath==k,1);
                    retempCriticalPath = tempCriticalPath(pos:end);
                    break
                end
            end
            if ~isempty(retempCriticalPath)
                reIndividualsLS = reExecutecriticalbottleneck(reIndividualsLS,tempDecode,retempCriticalPath,Parameter);
            end
        end
    end
end
end

function reIndividualsLS = reExecutecriticalbottleneck(reIndividualsLS,tempDecode,retempCriticalPath,Parameter)

Criticalcode = tempDecode(:,retempCriticalPath);
bottleneckindex = find((Criticalcode(10,:) - Criticalcode(9,:)) == max(Criticalcode(10,:) - Criticalcode(9,:)),1);
opo = Criticalcode(11,bottleneckindex);
p = mod(opo,100);
q = (opo-p)/100 ; 
AM = Parameter.AvalueMachine{q,p};
PT = Parameter.ProcessTime{q,p};
minPT = find(PT == min(PT),1);
M = AM(minPT);
if M ~= Criticalcode(2,bottleneckindex)
    TAM = M;
else 
    Engery = zeros(1,length(retempCriticalPath));  
    for i = 1:length(retempCriticalPath)
        Engery(i) = (Criticalcode(10,i) - Criticalcode(9,i))*Parameter.MLP(Criticalcode(2,i));
    end
    bottleneckEngery = find(Engery==max(Engery),1);
    opo = Criticalcode(11,bottleneckEngery);
    p = mod(opo,100); 
    q = (opo-p)/100 ; 
    AM = Parameter.AvalueMachine{q,p};
    PT = Parameter.ProcessTime{q,p};
    Power = Parameter.MLP(AM);
    E = PT.*Power;
    minE = find(E == min(E),1);
    M = AM(minE);
    TAM = M;
    if M == Criticalcode(2,bottleneckEngery)
        poss = randi(size(AM,2));
        TAM = AM(poss);
    end    
end
if q == 1
    reIndividualsLS.Code(3,p) = TAM;
else
    reIndividualsLS.Code(3,sum(Parameter.JobCOPNum(1:q-1))+p) = TAM;
end
end






