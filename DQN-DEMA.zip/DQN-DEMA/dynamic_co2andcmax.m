function reschedule_individual  = dynamic_co2andcmax(Parameter,reschedule_individual,information_pool,breakdown_fac,breakdown_machine,repair_time)
for i = 1:size(reschedule_individual,1)
    temp1 = max(reschedule_individual(i).F1JobCmax);
    temp2 = max(reschedule_individual(i).F2JobCmax);
    reschedule_individual(i).Fit(1,1) = max(temp1,temp2);
    if size(information_pool,1)
        if breakdown_fac == 1
            [~,pos1] = sort(reschedule_individual(i).F1Decode(2,:));
            F1Decodetmep = reschedule_individual(i).F1Decode(:,pos1);
            [~,First_m_index] = unique(F1Decodetmep(2,:));
            for j = 1:size(reschedule_individual(i).F1Decode,2)
                if ismember(j,First_m_index)
                    reschedule_individual(i).F1MUCO2 = reschedule_individual(i).F1MUCO2 + F1Decodetmep(9,j)/60 * Parameter.MULP(1,F1Decodetmep(2,j)) * Parameter.EF;
                    reschedule_individual(i).F1MLCO2 = reschedule_individual(i).F1MLCO2 + (F1Decodetmep(10,j) - F1Decodetmep(9,j))/60 * ...
                        Parameter.MLP(1,F1Decodetmep(2,j)) * Parameter.EF;
                else
                    reschedule_individual(i).F1MUCO2 = reschedule_individual(i).F1MUCO2 + (F1Decodetmep(9,j) - F1Decodetmep(10,j-1))/60 * Parameter.MULP(1,F1Decodetmep(2,j)) * Parameter.EF;
                    reschedule_individual(i).F1MLCO2 = reschedule_individual(i).F1MLCO2 + (F1Decodetmep(10,j) - F1Decodetmep(9,j))/60 * ...
                        Parameter.MLP(1,F1Decodetmep(2,j)) * Parameter.EF;
                end
            end

            for mm = 1:Parameter.MaxMachineNum
                if mm == breakdown_machine
                    reschedule_individual(i).F1MLCO2 = reschedule_individual(i).F1MLCO2-(repair_time/60 * Parameter.EF);
                end
            end

            reschedule_individual(i).F1AGVUCO2 = (sum(reschedule_individual(i).F1Decode(4,:)) + sum(reschedule_individual(i).F1AGVextralT(1,:)))/60 * Parameter.AGVULP * Parameter.EF; 
            reschedule_individual(i).F1AGVLCO2 = (sum(reschedule_individual(i).F1Decode(6,:)) + sum(reschedule_individual(i).F1AGVextralT(2,:)))/60 * Parameter.AGVLP * Parameter.EF; 
        else
            [~,pos2] = sort(reschedule_individual(i).F2Decode(2,:));
            F2Decodetmep = reschedule_individual(i).F2Decode(:,pos2);
            [~,First_m_index] = unique(F2Decodetmep(2,:));
            for j = 1:size(reschedule_individual(i).F2Decode,2)
                if ismember(j,First_m_index) 
                    reschedule_individual(i).F2MUCO2 = reschedule_individual(i).F2MUCO2 + F2Decodetmep(9,j)/60 * Parameter.MULP(1,F2Decodetmep(2,j)) * Parameter.EF; 
                    reschedule_individual(i).F2MLCO2 = reschedule_individual(i).F2MLCO2 + (F2Decodetmep(10,j) - F2Decodetmep(9,j))/60 * ...
                        Parameter.MLP(1,F2Decodetmep(2,j)) * Parameter.EF;
                else
                    reschedule_individual(i).F2MUCO2 = reschedule_individual(i).F2MUCO2 + (F2Decodetmep(9,j) - F2Decodetmep(10,j-1))/60 * Parameter.MULP(1,F2Decodetmep(2,j)) * Parameter.EF;
                    reschedule_individual(i).F2MLCO2 = reschedule_individual(i).F2MLCO2 + (F2Decodetmep(10,j) - F2Decodetmep(9,j))/60 * ...
                        Parameter.MLP(1,F2Decodetmep(2,j)) * Parameter.EF;
                end
            end
            for mm = 1:Parameter.MaxMachineNum
                if mm == breakdown_machine
                    reschedule_individual(i).F2MLCO2 = reschedule_individual(i).F2MLCO2-(repair_time/60 * Parameter.EF);
                end
            end
            reschedule_individual(i).F2AGVUCO2 = (sum(reschedule_individual(i).F2Decode(4,:)) + sum(reschedule_individual(i).F2AGVextralT(1,:)))/60 * Parameter.AGVULP * Parameter.EF; 
            reschedule_individual(i).F2AGVLCO2 = (sum(reschedule_individual(i).F2Decode(6,:)) + sum(reschedule_individual(i).F2AGVextralT(2,:)))/60 * Parameter.AGVLP * Parameter.EF;  
        end
    else
        [~,pos1] = sort(reschedule_individual(i).F1Decode(2,:));
        F1Decodetmep = reschedule_individual(i).F1Decode(:,pos1);

        [~,pos2] = sort(reschedule_individual(i).F2Decode(2,:));
        F2Decodetmep = reschedule_individual(i).F2Decode(:,pos2);

        for Factemp = 1:Parameter.FactoryNum
            if Factemp == 1
                if nnz(reschedule_individual(i).F1Decode) ~=0
                    [~,First_m_index] = unique(F1Decodetmep(2,:));
                    for j = 1:size(reschedule_individual(i).F1Decode,2)
                        if ismember(j,First_m_index)
                            reschedule_individual(i).F1MUCO2 = reschedule_individual(i).F1MUCO2 + F1Decodetmep(9,j)/60 * Parameter.MULP(1,F1Decodetmep(2,j)) * Parameter.EF;
                            reschedule_individual(i).F1MLCO2 = reschedule_individual(i).F1MLCO2 + (F1Decodetmep(10,j) - F1Decodetmep(9,j))/60 * ...
                                Parameter.MLP(1,F1Decodetmep(2,j)) * Parameter.EF;
                        else
                            reschedule_individual(i).F1MUCO2 = reschedule_individual(i).F1MUCO2 + (F1Decodetmep(9,j) - F1Decodetmep(10,j-1))/60 * Parameter.MULP(1,F1Decodetmep(2,j)) * Parameter.EF;
                            reschedule_individual(i).F1MLCO2 = reschedule_individual(i).F1MLCO2 + (F1Decodetmep(10,j) - F1Decodetmep(9,j))/60 * ...
                                Parameter.MLP(1,F1Decodetmep(2,j)) * Parameter.EF;
                        end
                    end
                    for mm = 1:Parameter.MaxMachineNum
                        if mm == breakdown_machine(Factemp)
                            reschedule_individual(i).F1MLCO2 = reschedule_individual(i).F1MLCO2-(repair_time/60 * Parameter.EF);
                        end
                    end
                    reschedule_individual(i).F1AGVUCO2 = (sum(reschedule_individual(i).F1Decode(4,:)) + sum(reschedule_individual(i).F1AGVextralT(1,:)))/60 * Parameter.AGVULP * Parameter.EF; 
                    reschedule_individual(i).F1AGVLCO2 = (sum(reschedule_individual(i).F1Decode(6,:)) + sum(reschedule_individual(i).F1AGVextralT(2,:)))/60 * Parameter.AGVLP * Parameter.EF;  
                end
            else
                if nnz(reschedule_individual(i).F2Decode) ~=0
                    [~,First_m_index] = unique(F2Decodetmep(2,:));
                    for j = 1:size(reschedule_individual(i).F2Decode,2)
                        if ismember(j,First_m_index) 
                            reschedule_individual(i).F2MUCO2 = reschedule_individual(i).F2MUCO2 + F2Decodetmep(9,j)/60 * Parameter.MULP(1,F2Decodetmep(2,j)) * Parameter.EF; 
                            reschedule_individual(i).F2MLCO2 = reschedule_individual(i).F2MLCO2 + (F2Decodetmep(10,j) - F2Decodetmep(9,j))/60 * ...
                                Parameter.MLP(1,F2Decodetmep(2,j)) * Parameter.EF;
                        else
                            reschedule_individual(i).F2MUCO2 = reschedule_individual(i).F2MUCO2 + (F2Decodetmep(9,j) - F2Decodetmep(10,j-1))/60 * Parameter.MULP(1,F2Decodetmep(2,j)) * Parameter.EF;
                            reschedule_individual(i).F2MLCO2 = reschedule_individual(i).F2MLCO2 + (F2Decodetmep(10,j) - F2Decodetmep(9,j))/60 * ...
                                Parameter.MLP(1,F2Decodetmep(2,j)) * Parameter.EF;
                        end
                    end
                    for mm = 1:Parameter.MaxMachineNum
                        if mm == breakdown_machine(Factemp)
                            reschedule_individual(i).F2MLCO2 = reschedule_individual(i).F2MLCO2-(repair_time/60 * Parameter.EF);
                        end
                    end
                    reschedule_individual(i).F2AGVUCO2 = (sum(reschedule_individual(i).F2Decode(4,:)) + sum(reschedule_individual(i).F2AGVextralT(1,:)))/60 * Parameter.AGVULP * Parameter.EF; 
                    reschedule_individual(i).F2AGVLCO2 = (sum(reschedule_individual(i).F2Decode(6,:)) + sum(reschedule_individual(i).F2AGVextralT(2,:)))/60 * Parameter.AGVLP * Parameter.EF;  
                end
            end
        end
    end
    reschedule_individual(i).Fit(1,2) = reschedule_individual(i).F1MUCO2 + reschedule_individual(i).F1MLCO2 + reschedule_individual(i).F1AGVUCO2 + reschedule_individual(i).F1AGVLCO2 + ...
        reschedule_individual(i).F2MUCO2 + reschedule_individual(i).F2MLCO2 + reschedule_individual(i).F2AGVUCO2 + reschedule_individual(i).F2AGVLCO2;
end
