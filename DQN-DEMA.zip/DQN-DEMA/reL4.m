function reIndividualsLS = reL4(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time)
reIndividualsLS = reEliteIndividual_temp(i);
reIndividualsLS = recriticaloper(reIndividualsLS,Parameter,information_pool,breakdown_fac);

temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = reIndividualsLS.Code(1,j);
    temp(val) = temp(val)+1;
    reIndividualsLS.Code(5,j) = val*100+temp(val);
end


reIndividualsLS = dynamic_adjust(reIndividualsLS,Parameter,information_pool);

reIndividualsLS = dynamic_fitness(reIndividualsLS,Parameter,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
end

function reIndividualsLS = recriticaloper(reIndividualsLS,Parameter,information_pool,breakdown_fac)
if size(information_pool,1) == 1
    if breakdown_fac == 1
        tempDecode = reIndividualsLS.F1Decode;
        tempCriticalPath = reIndividualsLS.F1CriticalPath;
    else
        tempDecode = reIndividualsLS.F2Decode;
        tempCriticalPath = reIndividualsLS.F2CriticalPath;
    end

    temp = size(tempDecode,2);
    for k = temp-information_pool(1).operation.Reschedule_operations+1:temp
        if ~ismember(k,tempCriticalPath)
            retempCriticalPath=[];
            continue
        else
            pos = find(tempCriticalPath==k,1);
            retempCriticalPath = tempCriticalPath(pos:end);
            break
        end
    end
    if ~isempty(retempCriticalPath)
        if size(retempCriticalPath,1)>1
            reIndividualsLS = reExecutecriticaloper(reIndividualsLS,tempDecode,retempCriticalPath);
        end
    end
else
    for f = 1:Parameter.FactoryNum
        if fac == 1
            tempDecode = reIndividualsLS.F1Decode;
            tempCriticalPath = reIndividualsLS.F1CriticalPath;
            temp = size(tempDecode,2);
            for k = temp-information_pool(f).operation.Reschedule_operations+1:temp
                if ~ismember(k,tempCriticalPath)
                    retempCriticalPath=[];
                    continue
                else
                    pos = find(tempCriticalPath==k,1);
                    retempCriticalPath = tempCriticalPath(pos:end);
                    break
                end
            end
            if ~isempty(retempCriticalPath)
                if size(retempCriticalPath,1)>1
                    reIndividualsLS = reExecutecriticaloper(reIndividualsLS,tempDecode,retempCriticalPath);
                else
                    continue
                end
            end
        else
            tempDecode = reIndividualsLS.F2Decode;
            tempCriticalPath = reIndividualsLS.F2CriticalPath;
            temp = size(tempDecode,2);
            for k = temp-information_pool(f).operation.Reschedule_operations+1:temp
                if ~ismember(k,tempCriticalPath)
                    retempCriticalPath=[];
                    continue
                else
                    pos = find(tempCriticalPath==k,1);
                    retempCriticalPath = tempCriticalPath(pos:end);
                    break
                end
            end
            if ~isempty(retempCriticalPath)
                if size(retempCriticalPath,1)>1
                    reIndividualsLS = reExecutecriticaloper(reIndividualsLS,tempDecode,retempCriticalPath);
                else
                    continue
                end
            end
        end
    end
end
end

function reIndividualsLS = reExecutecriticaloper(reIndividualsLS,tempDecode,retempCriticalPath)

Criticalcode = tempDecode(:,retempCriticalPath);

pos = randperm(length(retempCriticalPath));
pos1 = pos(randi(length(retempCriticalPath)));
pos2 = pos(randi(length(retempCriticalPath)));

while pos1 == pos2
    pos2 = pos(randi(length(retempCriticalPath)));
end

opo1 = Criticalcode(11,pos1);
opo2 = Criticalcode(11,pos2);

opo1index = find(reIndividualsLS.Code(5,:)==opo1);
opo2index = find(reIndividualsLS.Code(5,:)==opo2);

temp = reIndividualsLS.Code(1,opo2index);
reIndividualsLS.Code(1,opo2index) = reIndividualsLS.Code(1,opo1index);
reIndividualsLS.Code(1,opo1index) = temp;
end


