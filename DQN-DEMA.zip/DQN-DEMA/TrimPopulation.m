function MergePopulation = TrimPopulation(Parameter,MergePopulation)

MergePopulation = frontDiversity(Parameter,MergePopulation);
MergePopulation = distanceDiversity(Parameter,MergePopulation);

function MergePopulation = frontDiversity(Parameter,MergePopulation)
rank_num = unique([MergePopulation.Rank]');
total_rank_num = length(rank_num);
retainIndiv = zeros(total_rank_num,1);
availableIndiv = zeros(total_rank_num,1);
availableIndiv(1) = nnz([MergePopulation.Rank]'==1);
allowedIndiv = ceil(Parameter.NP*Parameter.PF);
if availableIndiv(1) >= allowedIndiv
    retainIndiv(1) = allowedIndiv;
else
    retainIndiv(1) = availableIndiv(1);
end
if total_rank_num>1
    fixed_ratio = 0.8;
    variable_coefficients = 0;
    for i = 2:total_rank_num
        availableIndiv(i) = nnz([MergePopulation.Rank]'==i);
        allowedIndiv = ceil(Parameter.NP*fixed_ratio^(i-1)*((1-fixed_ratio)/(1-fixed_ratio^total_rank_num)))+variable_coefficients;
        if availableIndiv(i) >= allowedIndiv
            retainIndiv(i) = allowedIndiv;
        else
            retainIndiv(i) = availableIndiv(i);
            variable_coefficients = allowedIndiv - availableIndiv(i);
        end
    end
end
front = total_rank_num;
increase = 0.1;
while sum(retainIndiv)<=Parameter.NP
    if retainIndiv(front)<availableIndiv(front)
        retainIndiv(front) = min(availableIndiv(front),ceil(retainIndiv(front)*(1+increase)));
        increase = increase*0.95;
    end
    if front == 1
        front = total_rank_num;       
        increase = 0.1;
    else
        front = front-1;
    end
end
popSize = size(MergePopulation,1);
for i = 1:rank_num
    pos = 1:popSize;
    index = ([MergePopulation.Rank]'==i);
    if retainIndiv(i)<nnz(index)  
        if retainIndiv(i)==0  
            continue;  
        end
        playerlist = pos(index);
        losers = tournament2(playerlist,MergePopulation,retainIndiv(i));
        MergePopulation(losers)=[];
        popSize = size(MergePopulation,1);
    end
end
function losers = tournament2(playerlist,MergePopulation,allowed)
CD = [MergePopulation.Cd]';
[~,sortedIndex] = sort(CD(playerlist),'descend');
losers = playerlist(sortedIndex(allowed+1:end)); 
function MergePopulation = distanceDiversity(Parameter,MergePopulation)
remove = length([MergePopulation.Rank]') - Parameter.NP;
if remove > 0
    Rank = [MergePopulation.Rank]';
    Cd = [MergePopulation.Cd]';
    [~,I] = sortrows([Rank,Cd],[1,-2]);
    nPop = size(Rank,1);
    to_remove = I(nPop:-1:(nPop-remove+1));
    MergePopulation(to_remove) = [];
end