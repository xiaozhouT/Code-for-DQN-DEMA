function IndividualsLS = L3(i,Parameter,ItEliteIndividual)
IndividualsLS = ItEliteIndividual(i);
IndividualsLS = criticalAGV(IndividualsLS,Parameter);
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = IndividualsLS.Code(1,j);
    temp(val) = temp(val)+1;
    IndividualsLS.Code(5,j) = val*100+temp(val);
end
IndividualsLS = fitness(IndividualsLS,Parameter);
end

function IndividualsLS = criticalAGV(IndividualsLS,Parameter)
for fac = 1:Parameter.FactoryNum
    if fac == 1
        tempDecode = IndividualsLS.F1Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F1CriticalPath;
            IndividualsLS = ExecutecriticalAGV(IndividualsLS,tempDecode,tempCriticalPath,Parameter);
        end
    else
        tempDecode = IndividualsLS.F2Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F2CriticalPath;
            IndividualsLS = ExecutecriticalAGV(IndividualsLS,tempDecode,tempCriticalPath,Parameter);
        end
    end
end
end

function IndividualsLS = ExecutecriticalAGV(IndividualsLS,tempDecode,tempCriticalPath,Parameter)
Criticalcode = tempDecode(:,tempCriticalPath);
p = 0.8;
AGV = sort(randperm(Parameter.AGVNum));
for i = 1:length(tempCriticalPath)
    if p >= rand
        if Criticalcode(3,i) == 0
            continue
        else
            opo = Criticalcode(11,i);
            p = mod(opo,100);
            q = (opo-p)/100 ; 
            agv = Criticalcode(3,i);
            index = AGV ~= agv;
            TAGV = AGV(index); 
            ind = randi(length(TAGV));
            tagv =  TAGV(ind);
            if q == 1
                IndividualsLS.Code(4,p) = tagv;
            else
                IndividualsLS.Code(4,sum(Parameter.JobCOPNum(1:q-1))+p) = tagv;
            end
        end
    end
end
end






