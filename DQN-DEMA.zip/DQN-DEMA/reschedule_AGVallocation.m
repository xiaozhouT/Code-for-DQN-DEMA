function reschedule_individual = reschedule_AGVallocation(reschedule_individual,real_reschedule,information_pool,Parameter,breakdown_fac,R)

if R 
    reschedule_individual = reschedule_randAllocateAGV(Parameter,real_reschedule,reschedule_individual,information_pool,breakdown_fac); 
else 
    reschedule_individual = reschedule_allocateAGV(Parameter,real_reschedule,reschedule_individual,information_pool,breakdown_fac);
end
end

