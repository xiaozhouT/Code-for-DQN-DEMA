function [Q_network,target_Q_network,losses,rewardsPerEpisode] = DQNtraining(Population,Parameter)


num_individuals = size(Population,1);
num_states = 4*sum(Parameter.JobCOPNum);  
num_actions = 4;   


input_size = num_states;  
output_size = num_actions;  
hidden_layer_size1 = 64;  
hidden_layer_size2 = 32;  
hidden_layer_size3 = 16;  


epsilon_max = 1.0;  
epsilon_min = 0.01;  
gamma = 0.9; 
batch_size = 64; 
updateTargetFrequency = 9;  
learning_rate = 0.0001;  
bufferSize = 1536;
epsilon_decay = 0.99;  


layers = [
    featureInputLayer(input_size,'Normalization', 'none', 'Name', 'state')
    fullyConnectedLayer(hidden_layer_size1,'Name', 'fc1','BiasLearnRateFactor', 1, 'BiasInitializer', 'narrow-normal','WeightsInitializer', 'he')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(hidden_layer_size2,'Name', 'fc2','BiasLearnRateFactor', 1, 'BiasInitializer', 'narrow-normal','WeightsInitializer', 'he')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(hidden_layer_size3,'Name', 'fc3','BiasLearnRateFactor', 1, 'BiasInitializer', 'narrow-normal','WeightsInitializer', 'he')
    reluLayer('Name', 'relu3')
    fullyConnectedLayer(output_size,'Name', 'output')
    softmaxLayer
    ];


experienceBuffer = cell(bufferSize, 1);
currentBufferSize = 0;


Population = findCriticalpath4(Parameter,Population);

Q_network = dlnetwork(layers);
target_Q_network = Q_network;

gradientsBuffer = [];
velocityBuffer = [];

num_epochs = 800;  
losses = [];
rewardsPerEpisode = [];

for epoch = 1:num_epochs
    epsilon = max(epsilon_min, epsilon_max * epsilon_decay^epoch);
    cumulativeReward = 0;
    for i = 1:num_individuals
        Individual = Population(i);
        state = [Individual.Code(1,:),Individual.Code(2,:),Individual.Code(3,:),Individual.Code(4,:)];
        for t = 1:10
            action = selectaction(state,Q_network,epsilon,num_actions);
            [reward,next_state,~,Population,~] = computeReward(i,action,Parameter,Individual,Population);
            cumulativeReward = cumulativeReward + reward;
            [experienceBuffer, currentBufferSize] = storeExperience(experienceBuffer, currentBufferSize, state, action, reward, next_state, bufferSize);
            if currentBufferSize >= batch_size
                miniBatch = sampleMiniBatch(experienceBuffer,currentBufferSize,batch_size);
                states = cell2mat(cellfun(@(x) x{1}, miniBatch, 'UniformOutput', false))';
                actions = cell2mat(cellfun(@(x) x{2}, miniBatch, 'UniformOutput', false));
                rewards = cell2mat(cellfun(@(x) x{3}, miniBatch, 'UniformOutput', false));
                nextStates = cell2mat(cellfun(@(x) x{4}, miniBatch, 'UniformOutput', false))';
                dlNextStates = dlarray(nextStates, 'CB');
                targetQValues = predict(target_Q_network, dlNextStates);
                maxNextQValues = max(extractdata(targetQValues), [], 1);
                targets = rewards' + gamma * maxNextQValues;
                [gradients, loss] = dlfeval(@modelGradients,Q_network,states,actions,targets);
                [Q_network, gradientsBuffer, velocityBuffer] = adamupdate(Q_network, gradients, gradientsBuffer, velocityBuffer, epoch,learning_rate);
                losses = [losses; double(loss)];
            end
            state = next_state;
        end
        if mod(i,updateTargetFrequency) == 0
            target_Q_network.Learnables.Value = Q_network.Learnables.Value;
        end
    end
    rewardsPerEpisode = [rewardsPerEpisode; cumulativeReward];
    fprintf('Episode %d: Total Reward = %.2f\n', epoch, cumulativeReward);
end

saveFolder = 'E:\20240715DQNDEMA\20240510DEMA\目标网络';
saveFileName = 'ORB09_target_Q_network.mat';

savePath = fullfile(saveFolder,saveFileName);
save(savePath,'target_Q_network');

end


function action = selectaction(state,net,epsilon,num_actions)
    if rand()<epsilon
        action = randi(num_actions); 
    else
        dlX = dlarray(state','CB');
        qValues = predict(net, dlX); 
        [~, action] = max(extractdata(qValues));
    end
end


function [reward,next_state,IndividualsLS,Population,Individual] = computeReward(i,action,Parameter,Individual,Population)

switch action
    case 1
        IndividualsLS = L1(1,Parameter,Individual);
    case 2
        IndividualsLS = L2(1,Parameter,Individual);
    case 3
        IndividualsLS = L3(1,Parameter,Individual);
    case 4
        IndividualsLS = L4(1,Parameter,Individual);
end

IndividualsLS = findCriticalpath4(Parameter,IndividualsLS);

next_state = [IndividualsLS.Code(1,:),IndividualsLS.Code(2,:),IndividualsLS.Code(3,:),IndividualsLS.Code(4,:)];

if any(IndividualsLS(1).Fit<Individual(1).Fit) && all(IndividualsLS(1).Fit<=Individual(1).Fit)
    reward = 10; 
    Population(i) = IndividualsLS;
elseif any(IndividualsLS(1).Fit<=Individual(1).Fit)
    reward = 0; 
elseif any(IndividualsLS(1).Fit>Individual(1).Fit) && all(IndividualsLS(1).Fit>=Individual(1).Fit)
    reward = 0; 
end
end

function [experienceBuffer, currentBufferSize] = storeExperience(experienceBuffer, currentBufferSize, state, action, reward, nextState, bufferSize)
    experience = {state, action, reward, nextState};
    if currentBufferSize < bufferSize
        currentBufferSize = currentBufferSize + 1;
    else
        experienceBuffer = experienceBuffer(2:end); % Remove the oldest experience
    end
    experienceBuffer{currentBufferSize} = experience; % Add new experience to the end
end

function miniBatch = sampleMiniBatch(experienceBuffer, currentBufferSize, miniBatchSize)
    if currentBufferSize < miniBatchSize
        error('Not enough samples in the experience buffer to sample a mini-batch');
    end
    indices = randperm(currentBufferSize, miniBatchSize);
    miniBatch = experienceBuffer(indices);
end

function [gradients, loss] = modelGradients(net, states, actions, targets)
    dlX = dlarray(states, 'CB');
    dlY = predict(net, dlX);
    
    % Compute Q-values for the taken actions
    idx = sub2ind(size(dlY), actions', 1:size(dlY, 2));
    qValues = dlY(idx);
    
    % Compute loss
    dlTargets = dlarray(targets, 'CB');
    loss = mse(qValues,dlTargets,"DataFormat",'CB');
    
    % Compute gradients
    gradients = dlgradient(loss, net.Learnables);
end
