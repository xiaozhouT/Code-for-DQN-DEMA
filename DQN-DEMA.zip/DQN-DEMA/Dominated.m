function Population = Dominated(Population)

popSize = size(Population,1);
rankedIndiv = false(popSize,1);
rankCounter = 1;

while ~all(rankedIndiv) && nnz(isfinite([Population.Rank]')) <= popSize
    front = false(popSize,1); 
    for p = 1:popSize
        if rankedIndiv(p)
            continue;
        end
        dominates = true;
        for q = 1:popSize
            if rankedIndiv(q)|| p==q  
                continue;
            end
            if any(Population(q).Fit<Population(p).Fit) && all(Population(q).Fit<=Population(p).Fit) 
                dominates = false;
                break;
            end
        end
        if dominates 
            Population(p).Rank = rankCounter;  
            front(p) = true;
        end
    end
    for p = 1:popSize
        if front(p)
            rankedIndiv(p) = true;
        end
    end
    rankCounter = rankCounter+1;
end

    