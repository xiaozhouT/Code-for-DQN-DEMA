function reIndividualsLS = reL1(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time)

reIndividualsLS = reEliteIndividual_temp(i);
reIndividualsLS = reN6(reIndividualsLS,Parameter,information_pool,breakdown_fac);

temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = reIndividualsLS.Code(1,j);
    temp(val) = temp(val)+1;
    reIndividualsLS.Code(5,j) = val*100+temp(val);
end

reIndividualsLS = dynamic_adjust(reIndividualsLS,Parameter,information_pool);
reIndividualsLS = dynamic_fitness(reIndividualsLS,Parameter,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);

function reIndividualsLS = reN6(reIndividualsLS,Parameter,information_pool,breakdown_fac)
if size(information_pool,1) == 1
    if breakdown_fac == 1
        tempDecode = reIndividualsLS.F1Decode;
        tempCriticalPath = reIndividualsLS.F1CriticalPath;
        tempCriticalBlockB = reIndividualsLS.F1CriticalBlock.B;
        tempCriticalBlockC = reIndividualsLS.F1CriticalBlock.C;
    else
        tempDecode = reIndividualsLS.F2Decode;
        tempCriticalPath = reIndividualsLS.F2CriticalPath;
        tempCriticalBlockB = reIndividualsLS.F2CriticalBlock.B;
        tempCriticalBlockC = reIndividualsLS.F2CriticalBlock.C;
    end
    temp = size(tempDecode,2);
    for k = temp-information_pool(1).operation.Reschedule_operations+1:temp
        if ~ismember(k,tempCriticalPath)
            continue
        else
            pos = find(tempCriticalPath==k,1);
            retempCriticalPath = tempCriticalPath(pos:end);
            break
        end
    end
    BlockB = length(tempCriticalBlockB);
    BlockC = length(tempCriticalBlockC);
    for k = 1:BlockB
        if ~ismember(tempCriticalPath(pos),tempCriticalBlockB(k).B)
            continue
        else
            retempCriticalBlockB = tempCriticalBlockB(k:end);
            break
        end
    end
    for k = 1:BlockC
        if ~ismember(tempCriticalPath(pos),tempCriticalBlockC(k).C)
            continue
        else
            retempCriticalBlockC = tempCriticalBlockC(k:end);
            break
        end
    end
    reBlockB = length(retempCriticalBlockB);
    reBlockC = length(retempCriticalBlockC); 

    for k = 1:reBlockB 
        tempB = retempCriticalBlockB(k).B;
        tempBinteger = tempDecode(11,tempB);
        if all(ismember(tempBinteger,information_pool(1).operation.Reschedule_integerschemes))
            continue
        else
            [isMember,~] = ismember(tempBinteger,information_pool(1).operation.Reschedule_integerschemes);
            noncon = find(~isMember);
            retempCriticalBlockB(k).B(noncon) = [];
        end
    end
    for k = 1:reBlockC 
        tempC = retempCriticalBlockC(k).C;
        tempCinteger = tempDecode(11,tempC);
        if all(ismember(tempCinteger,information_pool(1).operation.Reschedule_integerschemes))
            continue
        else
            [isMember,~] = ismember(tempCinteger,information_pool(1).operation.Reschedule_integerschemes);
            noncon = find(~isMember);
            retempCriticalBlockC(k).C(noncon) = [];
        end
    end
    reIndividualsLS = ExecuteN6(reIndividualsLS,tempDecode,retempCriticalPath,reBlockB,reBlockC,retempCriticalBlockB,retempCriticalBlockC);
else
    for f = 1:Parameter.FactoryNum
        if f == 1
            tempDecode = reIndividualsLS.F1Decode;
            tempCriticalPath = reIndividualsLS.F1CriticalPath;
            tempCriticalBlockB = reIndividualsLS.F1CriticalBlock.B;
            tempCriticalBlockC = reIndividualsLS.F1CriticalBlock.C;
            temp = size(tempDecode,2);
            for k = temp-information_pool(f).operation.Reschedule_operations+1:temp
                if ~ismember(k,tempCriticalPath)
                    continue
                else
                    pos = find(tempCriticalPath==k,1);
                    retempCriticalPath = tempCriticalPath(pos:end);
                    break
                end
            end
            BlockB = length(tempCriticalBlockB);
            BlockC = length(tempCriticalBlockC);
            for k = 1:BlockB
                if ~ismember(tempCriticalPath(pos),tempCriticalBlockB(k).B)
                    continue
                else
                    retempCriticalBlockB = tempCriticalBlockB(k:end);
                    break
                end
            end
            for k = 1:BlockC
                if ~ismember(tempCriticalPath(pos),tempCriticalBlockC(k).C)
                    continue
                else
                    retempCriticalBlockC = tempCriticalBlockC(k:end);
                    break
                end
            end
            reBlockB = length(retempCriticalBlockB);
            reBlockC = length(retempCriticalBlockC);
            for k = 1:reBlockB
                tempB = retempCriticalBlockB(k).B;
                tempBinteger = tempDecode(11,tempB);
                if all(ismember(tempBinteger,information_pool(f).operation.Reschedule_integerschemes))
                    continue
                else
                    [isMember,~] = ismember(tempBinteger,information_pool(f).operation.Reschedule_integerschemes);
                    noncon = find(~isMember);
                    retempCriticalBlockB(k).B(noncon) = [];
                end
            end
            for k = 1:reBlockC
                tempC = retempCriticalBlockC(k).C;
                tempCinteger = tempDecode(11,tempC);
                if all(ismember(tempCinteger,information_pool(f).operation.Reschedule_integerschemes))
                    continue
                else
                    [isMember,~] = ismember(tempCinteger,information_pool(f).operation.Reschedule_integerschemes);
                    noncon = find(~isMember);
                    retempCriticalBlockC(k).C(noncon) = [];
                end
            end
            reIndividualsLS = ExecuteN6(reIndividualsLS,tempDecode,retempCriticalPath,reBlockB,reBlockC,retempCriticalBlockB,retempCriticalBlockC);
        else
            tempDecode = reIndividualsLS.F2Decode;
            tempCriticalPath = reIndividualsLS.F2CriticalPath;
            tempCriticalBlockB = reIndividualsLS.F2CriticalBlock.B;
            tempCriticalBlockC = reIndividualsLS.F2CriticalBlock.C;
            temp = size(tempDecode,2);
            for k = temp-information_pool(f).operation.Reschedule_operations+1:temp
                if ~ismember(k,tempCriticalPath)
                    continue
                else
                    pos = find(tempCriticalPath==k,1);
                    retempCriticalPath = tempCriticalPath(pos:end);
                    break
                end
            end
            BlockB = length(tempCriticalBlockB);
            BlockC = length(tempCriticalBlockC);
            for k = 1:BlockB
                if ~ismember(tempCriticalPath(pos),tempCriticalBlockB(k).B)
                    continue
                else
                    retempCriticalBlockB = tempCriticalBlockB(k:end);
                    break
                end
            end
            for k = 1:BlockC
                if ~ismember(tempCriticalPath(pos),tempCriticalBlockC(k).C)
                    continue
                else
                    retempCriticalBlockC = tempCriticalBlockC(k:end);
                    break
                end
            end
            reBlockB = length(retempCriticalBlockB);
            reBlockC = length(retempCriticalBlockC);
            for k = 1:reBlockB
                tempB = retempCriticalBlockB(k).B;
                tempBinteger = tempDecode(11,tempB);
                if all(ismember(tempBinteger,information_pool(f).operation.Reschedule_integerschemes))
                    continue
                else
                    [isMember,~] = ismember(tempBinteger,information_pool(f).operation.Reschedule_integerschemes);
                    noncon = find(~isMember);
                    retempCriticalBlockB(k).B(noncon) = [];
                end
            end
            for k = 1:reBlockC
                tempC = retempCriticalBlockC(k).C;
                tempCinteger = tempDecode(11,tempC);
                if all(ismember(tempCinteger,information_pool(f).operation.Reschedule_integerschemes))
                    continue
                else
                    [isMember,~] = ismember(tempCinteger,information_pool(f).operation.Reschedule_integerschemes);
                    noncon = find(~isMember);
                    retempCriticalBlockC(k).C(noncon) = [];
                end
            end
            reIndividualsLS = ExecuteN6(reIndividualsLS,tempDecode,retempCriticalPath,reBlockB,reBlockC,retempCriticalBlockB,retempCriticalBlockC);
        end
    end
end


function reIndividualsLS = ExecuteN6(reIndividualsLS,tempDecode,retempCriticalPath,reBlockB,reBlockC,retempCriticalBlockB,retempCriticalBlockC)

tempIndex = zeros(1,length(retempCriticalPath));
for l = 1:length(retempCriticalPath)
    tempIndex(l) = find(reIndividualsLS.Code(5,:) == tempDecode(11,retempCriticalPath(l))); 
end

for b = 1:reBlockB
    BL = length(retempCriticalBlockB(b).B);
    if BL>1
        if b == 1
            Index1 = ceil(rand*(BL-1));
            Index2 = BL;
            Index1 = retempCriticalBlockB(b).B(Index1); 
            Index2 = retempCriticalBlockB(b).B(Index2);
            Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1)); 
            Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11); 
            Index222 = find(tempIndex==Index22);
            tmp1 = reIndividualsLS.Code(1,tempIndex(Index111));
            for j = Index111:Index222-1
                reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j+1));
            end
            reIndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
        end

        if b == reBlockB
            Index1=1;  
            Index2=ceil(rand*(BL-1))+1;
            Index1 = retempCriticalBlockB(b).B(Index1);
            Index2 = retempCriticalBlockB(b).B(Index2);
            Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11); 
            Index222 = find(tempIndex==Index22);
            tmp1 = reIndividualsLS.Code(1,tempIndex(Index222));
            for j = Index222:-1:Index111+1
                reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j-1));
            end
            reIndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
        end

        if b > 1 && b < reBlockB && BL > 2
            Index1=ceil(rand*(BL-2))+1; 
            Index2 = BL;
            Index1 = retempCriticalBlockB(b).B(Index1);
            Index2 = retempCriticalBlockB(b).B(Index2);
            Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11);
            Index222 = find(tempIndex==Index22);
            tmp1 = reIndividualsLS(1).Code(1,tempIndex(Index111));
            for j = Index111:Index222-1
                reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j+1));
            end
            reIndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
            Index1=1; 
            Index2=ceil(rand*(BL-2))+1;
            Index1 = retempCriticalBlockB(b).B(Index1);
            Index2 = retempCriticalBlockB(b).B(Index2);
            Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11);
            Index222 = find(tempIndex==Index22);
            tmp1 = reIndividualsLS.Code(1,tempIndex(Index222));
            for j = Index222:-1:Index111+1
                reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j-1));
            end
            reIndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
        end
    end
end

for c = 1:reBlockC
    CL = length(retempCriticalBlockC(c).C);
    if CL>1
        if c == 1
            Index1 = ceil(rand*(CL-1)); 
            Index2 = CL; 
            Index1 = retempCriticalBlockC(c).C(Index1);
            Index2 = retempCriticalBlockC(c).C(Index2);
            Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1)); 
            Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11); 
            Index222 = find(tempIndex==Index22);
            tmp1 = reIndividualsLS(1).Code(1,tempIndex(Index111));
            for j = Index111:Index222-1
                reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j+1));
            end
            reIndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
        end

         if c == reBlockC
            Index1=1;  
            Index2=ceil(rand*(CL-1))+1;
            Index1 = retempCriticalBlockC(c).C(Index1);
            Index2 = retempCriticalBlockC(c).C(Index2);
            Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11);
            Index222 = find(tempIndex==Index22);
            tmp1 = reIndividualsLS.Code(1,tempIndex(Index222));
            for j = Index222:-1:Index111+1
                reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j-1));
            end
            reIndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
         end

         if c > 1 && c < reBlockC && CL > 2
             Index1=ceil(rand*(CL-2))+1; 
             Index2 = CL;
             Index1 = retempCriticalBlockC(c).C(Index1);
             Index2 = retempCriticalBlockC(c).C(Index2);
             Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1)); 
             Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
             Index111 = find(tempIndex==Index11); 
             Index222 = find(tempIndex==Index22);
             tmp1 = reIndividualsLS(1).Code(1,tempIndex(Index111));
             for j = Index111:Index222-1
                 reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j+1));
             end
             reIndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
             Index1=1;  
             Index2=ceil(rand*(CL-2))+1;
             Index1 = retempCriticalBlockC(c).C(Index1);
             Index2 = retempCriticalBlockC(c).C(Index2);
             Index11 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index1));
             Index22 = find(reIndividualsLS.Code(5,:) == tempDecode(11,Index2));
             Index111 = find(tempIndex==Index11);
             Index222 = find(tempIndex==Index22);
             tmp1 = reIndividualsLS.Code(1,tempIndex(Index222));
             for j = Index222:-1:Index111+1
                 reIndividualsLS.Code(1,tempIndex(j)) = reIndividualsLS.Code(1,tempIndex(j-1));
             end
             reIndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
         end
    end
end












