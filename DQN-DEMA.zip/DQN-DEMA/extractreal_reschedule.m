function real_reschedule = extractreal_reschedule(reschedule_individual,information_pool,breakdown_fac)

if size(information_pool,1) == 1
    reschedule = zeros(2,information_pool(1).operation.Reschedule_operations);
    reschedule(1,:) =  reschedule_individual.Code(1,end-information_pool(1).operation.Reschedule_operations+1:end);
    reschedule(2,:) =  reschedule_individual.Code(5,end-information_pool(1).operation.Reschedule_operations+1:end);
    if breakdown_fac == 1
        real_reschedule.F1 = reschedule;
        real_reschedule.F2 = [];
    else
        real_reschedule.F1 = [];
        real_reschedule.F2 = reschedule;
    end
else
    for f = 1:Parameter.FactoryNum
        reschedule = zeros(2,information_pool(f).operation.Reschedule_operations);
        if f == 1
            reschedule(1,:) = reschedule_individual.Code(1,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations);
            reschedule(2,:) = reschedule_individual.Code(5,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations);
            real_reschedule.F1 = reschedule;
        else
            reschedule(1,:) = reschedule_individual.Code(1,end-information_pool(2).operation.Reschedule_operations+1:end);
            reschedule(2,:) = reschedule_individual.Code(5,end-information_pool(2).operation.Reschedule_operations+1:end);
            real_reschedule.F2 = reschedule;
        end
    end
end


