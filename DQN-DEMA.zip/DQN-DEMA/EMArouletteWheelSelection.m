function selected_indices = EMArouletteWheelSelection(fit,Parameter)

fitness1 = fit(:,1);
if size(fitness1,1)==1
    normalized_fitness1 = 1;
else
    normalized_fitness1 = (fitness1 - min(fitness1))./(max(fitness1) - min(fitness1));
end

fitness2 = fit(:,2);
if size(fitness2,1)==1
    normalized_fitness2 = 1;
else
    normalized_fitness2 = (fitness2 - min(fitness2))./(max(fitness2) - min(fitness2));
end

combined_fitness = normalized_fitness1 + normalized_fitness2;
selection_probabilities = combined_fitness / sum(combined_fitness);
cumulative_probabilities = cumsum(selection_probabilities);
selected_indices = zeros(1,Parameter.NP);

for i = 1:Parameter.NP
    r = rand();
    selected_index = find(cumulative_probabilities >= r,1,'first');
    selected_indices(i) = selected_index;
end
selected_indices = selected_indices';


