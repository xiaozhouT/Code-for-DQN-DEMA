% This function is used to generate breakdown information

function [breakdown_fac,breakdown_time,repair_time,breakdown_machine,breakdown_pos] = generatebreakinfor(reschedule_individual,Parameter)
if max(reschedule_individual.F1MachineCmax) < Parameter.DynamicT && max((reschedule_individual.F2MachineCmax) < Parameter.DynamicT)
    breakdown_fac = randi(Parameter.FactoryNum);
    if breakdown_fac == 1
        breakdown_pos = randi([ceil(0.2*size(reschedule_individual.F1Decode,2)),ceil(0.8*size(reschedule_individual.F1Decode,2))]); 
        breakdown_machine = reschedule_individual.F1Decode(2,breakdown_pos); 
        breakdown_time = reschedule_individual.F1Decode(9,breakdown_pos)+(reschedule_individual.F1Decode(10,breakdown_pos)-reschedule_individual.F1Decode(9,breakdown_pos))*rand;
        repair_time = (0.1/0.90)*breakdown_time; 
    else
        breakdown_pos = randi([ceil(0.2*size(reschedule_individual.F2Decode,2)),ceil(0.8*size(reschedule_individual.F2Decode,2))]); 
        breakdown_machine = reschedule_individual.F2Decode(2,breakdown_pos); 
        breakdown_time = reschedule_individual.F2Decode(9,breakdown_pos)+(reschedule_individual.F2Decode(10,breakdown_pos)-reschedule_individual.F2Decode(9,breakdown_pos))*rand;
        repair_time = (0.1/0.90)*breakdown_time;
    end
elseif max(reschedule_individual.F1MachineCmax) >= Parameter.DynamicT || max((reschedule_individual.F2MachineCmax) >= Parameter.DynamicT)
    if max(reschedule_individual.F1MachineCmax) > max(reschedule_individual.F2MachineCmax)
        breakdown_fac = 1;
    else
        breakdown_fac = 2;
    end
    breakdown_time = Parameter.DynamicT;
    repair_time = Parameter.RepairT;
    if breakdown_fac == 1
        useful_pos1 = reschedule_individual.F1Decode(9,:) < breakdown_time;
        useful_pos2 = reschedule_individual.F1Decode(10,:) >= breakdown_time;
        useful_pos = [useful_pos1;useful_pos2];
        breakdown_pos = find(useful_pos(1,:)==useful_pos(2,:),1);  
        breakdown_machine = reschedule_individual.F1Decode(2,breakdown_pos); 
        if isempty(breakdown_machine)
            breakdown_pos = find(useful_pos(2,:) == 1,1);
            breakdown_machine = reschedule_individual.F1Decode(2,breakdown_pos); 
            breakdown_time = reschedule_individual.F1Decode(9,breakdown_pos)+(reschedule_individual.F1Decode(10,breakdown_pos)-reschedule_individual.F1Decode(9,breakdown_pos))*rand;
            repair_time = (0.1/0.90)*breakdown_time;
        end
    else
        useful_pos1 = reschedule_individual.F2Decode(9,:) < breakdown_time;
        useful_pos2 = reschedule_individual.F2Decode(10,:) >= breakdown_time;
        useful_pos = [useful_pos1;useful_pos2];
        breakdown_pos = find(useful_pos(1,:)==useful_pos(2,:),1);  
        breakdown_machine = reschedule_individual.F2Decode(2,breakdown_pos); 
        if isempty(breakdown_machine)
            breakdown_pos = find(useful_pos(2,:) == 1,1);
            breakdown_machine = reschedule_individual.F2Decode(2,breakdown_pos); 
            breakdown_time = reschedule_individual.F2Decode(9,breakdown_pos)+(reschedule_individual.F2Decode(10,breakdown_pos)-reschedule_individual.F2Decode(9,breakdown_pos))*rand;
            repair_time = (0.1/0.90)*breakdown_time;
        end
    end
elseif max(reschedule_individual.F1MachineCmax) >= Parameter.DynamicT && max((reschedule_individual.F2MachineCmax) >= Parameter.DynamicT)
    breakdown_fac = [1,2];
    breakdown_time = Parameter.DynamicT;
    repair_time = Parameter.RepairT;
    for f = 1:2
        if breakdown_fac(f) == 1
            useful_pos1 = reschedule_individual.F1Decode(9,:) < breakdown_time;
            useful_pos2 = reschedule_individual.F1Decode(10,:) >= breakdown_time;
            useful_pos = [useful_pos1;useful_pos2];
            breakdown_pos1 = find(useful_pos(1,:)==useful_pos(2,:),1);  
            breakdown_machine1 = reschedule_individual.F1Decode(2,breakdown_pos1); 
        else
            useful_pos1 = reschedule_individual.F2Decode(9,:) < breakdown_time;
            useful_pos2 = reschedule_individual.F2Decode(10,:) >= breakdown_time;
            useful_pos = [useful_pos1;useful_pos2];
            breakdown_pos2 = find(useful_pos(1,:)==useful_pos(2,:),1); 
            breakdown_machine2 = reschedule_individual.F2Decode(2,breakdown_pos2);
        end
    end
    breakdown_pos = [breakdown_pos1,breakdown_pos2];
    breakdown_machine = [breakdown_machine1,breakdown_machine2];
end