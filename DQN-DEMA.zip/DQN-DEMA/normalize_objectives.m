function [PopObj,M] = normalize_objectives(PopObj)

[N,M]  = size(PopObj);
fmin   = min(min(PopObj,[],1),zeros(1,M)); 
fmax   = max(PopObj,[],1)*1.1; 
PopObj = (PopObj-repmat(fmin ,N,1))./repmat(fmax -fmin ,N,1);
PopObj(any(PopObj>1,2),:) = [];

end