function reschedule_individual = reschedule_allocateAGV(Parameter,real_reschedule,reschedule_individual,information_pool,breakdown_fac)
if size(information_pool,1) == 1 
    if breakdown_fac == 1
        tempDecode = reschedule_individual.F1Decode;
        f = 1;
        reschedule = real_reschedule.F1;
        [reschedule_individual,reschedule] = reschedule_allocate(Parameter,reschedule,tempDecode,reschedule_individual,information_pool,f);
    else
        tempDecode = reschedule_individual.F2Decode;
        f = 1;  
        reschedule = real_reschedule.F2;
        [reschedule_individual,reschedule] = reschedule_allocate(Parameter,reschedule,tempDecode,reschedule_individual,information_pool,f);
    end
    reschedule_individual.Code(1,end-information_pool(1).operation.Reschedule_operations+1:end) =  reschedule(1,:);
    reschedule_individual.Code(5,end-information_pool(1).operation.Reschedule_operations+1:end) =  reschedule(2,:);
else 
    for f = 1:Parameter.FactoryNum
        if f == 1
            tempDecode = reschedule_individual.F1Decode;
            reschedule = real_reschedule.F1;
            [reschedule_individual,reschedule] = reschedule_allocate(Parameter,reschedule,tempDecode,reschedule_individual,information_pool,f);
            reschedule_individual.Code(1,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations) =  reschedule(1,:);
            reschedule_individual.Code(5,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations) =  reschedule(2,:);
        else
            tempDecode = reschedule_individual.F2Decode;
            reschedule = real_reschedule.F2;
            [reschedule_individual,reschedule] = reschedule_allocate(Parameter,reschedule,tempDecode,reschedule_individual,information_pool,f);
            reschedule_individual.Code(1,end-information_pool(2).operation.Reschedule_operations+1:end) =  reschedule(1,:);
            reschedule_individual.Code(5,end-information_pool(2).operation.Reschedule_operations+1:end) =  reschedule(2,:);
        end
    end
end
end

function [reschedule_individual,reschedule] = reschedule_allocate(Parameter,reschedule,tempDecode,reschedule_individual,information_pool,f)

under_load = information_pool(f).operation.position ~= inf;  
if any(under_load ~= 0) 
    job_under_load = information_pool(f).operation.Reschedule_integerschemes(under_load);
    under_load_agv = information_pool(f).operation.position(under_load); 
    for op = 1:size(job_under_load,2)
        integer = job_under_load(op);
        operation = mod(integer,100);
        job = (integer-operation)/100;
        if job == 1
            reschedule_individual.Code(4,operation) = under_load_agv(op);
        else
            reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = under_load_agv(op);
        end
    end
    temp = job_under_load' == reschedule(2,:);
    temp1 = [];
    for k = 1:size(temp,1)
        temp2 = reschedule(:,temp(k,:));
        temp1 = [temp1,temp2]; 
    end

    temp3 = job_under_load' ~= reschedule(2,:);
    temp3 = all(temp3==1,1);
    temp4 = reschedule(:,temp3);
    reschedule = [temp1,temp4]; 
end 

for i = 1:size(reschedule,2)
    tempDecode(:,tempDecode(11,:) == reschedule(2,i)) = [];
end

Decode = zeros(9,information_pool(f).operation.Reschedule_operations);
JobCmax = zeros(1,Parameter.MaxJobNum); 
MachineCmax = zeros(1,Parameter.MaxMachineNum);
MachineCmax(1,:) = information_pool(f).machine.Reschedule_release;  
AGVInfor = zeros(2,Parameter.AGVNum); 

for k = 1:size(reschedule,2)
    bufenpei = false;
    xiuzheng = false;
    integer = reschedule(2,k);
    operation = mod(integer,100);
    job = (integer-operation)/100;
    if job == 1
        m = reschedule_individual.Code(3,operation); 
        if operation == 1
            op_m = 0;
        else
            op_m = reschedule_individual.Code(3,operation-1);
        end
    else
        m = reschedule_individual.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation);
        if operation == 1
            op_m = 0;
        else
            op_m = reschedule_individual.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation-1);
        end
    end

    index = information_pool(f).operation.Reschedule_integerschemes == integer;
    AM = information_pool(f).machine.Reschedule_available{index};
    PT = information_pool(f).machine.Reschedule_processtime{index};
    index1 = AM == m;
    TPT = PT(index1); 
    TST = Parameter.SetupTime(job,operation);
    if information_pool(f).operation.position(index) ~= inf  
        if job == 1
            TAGV = reschedule_individual.Code(4,operation);
        else
            TAGV = reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation);
        end
    else 
        TAGV = 0;
    end

    if TAGV ~= 0 
       
        origin_m = information_pool(f).AGV.nextposition(1,TAGV); 
        if op_m == m 
            car_no_load_t = 0;
            car_load_t = information_pool(f).AGV.rate(1,TAGV)*Parameter.AGVTime(op_m+1,origin_m+1)/60; 
            indexx = find(Decode(9,:) == (integer-1),1);
            if isempty(indexx)
                tt_mmm_index = Decode(2,:)==m;
                if isempty(tt_mmm_index)
                    yizhixing_index = tempDecode(2,:)==m;
                    yizhixing = tempDecode(:,yizhixing_index);
                    if yizhixing(11,end) == integer-1
                        xiuzheng = true;
                    else
                        xiuzheng = false;
                    end
                    if information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t > MachineCmax(1,m)
                        StartT = information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t;
                    else
                        StartT = MachineCmax(1,m);
                    end
                else
                    mmm = Decode(:,tt_mmm_index);
                    shangyidao_index = find(mmm(9,:) == (integer-1),1);
                    current_index = find(mmm(9,:) == integer,1);
                    if current_index == shangyidao_index+1
                        xiuzheng = true;
                    else
                        xiuzheng = false;
                    end
                    if information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t > MachineCmax(1,m)
                        StartT = information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t;
                    else
                        StartT = MachineCmax(1,m);
                    end
                end
            end
        else
            if m == origin_m 
                car_no_load_t = 0;
                car_load_t = (1-information_pool(f).AGV.rate(1,TAGV)) * Parameter.AGVTime(op_m+1,origin_m+1)/60;
                if information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t > MachineCmax(1,m)
                    StartT = information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t;
                else
                    StartT = MachineCmax(1,m);
                end
            else
                car_no_load_t = 0;
                a = Parameter.AGVTime(op_m+1,origin_m+1)/60;
                b = Parameter.AGVTime(op_m+1,m+1)/60;
                c = Parameter.AGVTime(origin_m+1,m+1)/60;
                theta_rad = acos((a^2+b^2-c^2)/(2*a*b));
                a = information_pool(f).AGV.rate(1,TAGV)*Parameter.AGVTime(op_m+1,origin_m+1)/60;
                car_load_t = sqrt(a^2+b^2-2*a*b*cos(theta_rad));
                if information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t > MachineCmax(1,m)
                    StartT = information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t;
                else
                    StartT = MachineCmax(1,m);
                end
            end
        end
        if AGVInfor(1,TAGV) == 0
            AGVInfor(1,TAGV) = information_pool(f).AGV.Reschedule_release(1,TAGV)+car_load_t;
            AGVInfor(2,TAGV) = m;
        else
            AGVInfor(1,TAGV) = AGVInfor(1,TAGV)+car_no_load_t+car_load_t;
            AGVInfor(2,TAGV) = m;
        end
    else 
        car_no_load_retrieval = zeros(1,Parameter.AGVNum); 
        car_no_load_t_temp = zeros(1,Parameter.AGVNum);
        for x = 1:Parameter.AGVNum
            if AGVInfor(2,x) == 0 
                if information_pool(f).AGV.rate(1,x) ~= inf && information_pool(f).AGV.rate(1,x) ~= 0 
                    origin_m = information_pool(f).AGV.nextposition(1,x);
                    if information_pool(f).AGV.position(1,x) == op_m
                        if op_m == m
                            bufenpei = true;
                            indexx = find(Decode(9,:) == (integer-1),1); 
                            break
                        else
                            car_no_load_t = information_pool(f).AGV.rate(1,x)*Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,origin_m+1)/60;
                            car_no_load_t_temp(1,x) = car_no_load_t;
                            car_no_load_retrieval(1,x) = information_pool(f).AGV.Reschedule_release(1,x)+car_no_load_t;
                        end
                    else
                        if op_m == m     
                            bufenpei = true;
                            indexx = find(Decode(9,:) == (integer-1),1);
                            break
                        else
                            if origin_m == m 
                                a = Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,origin_m+1)/60;
                                b = Parameter.AGVTime(op_m+1,origin_m+1)/60;
                                c =  Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,op_m+1)/60;
                                theta_rad = acos((a^2+b^2-c^2)/(2*a*b));
                                a = (1-information_pool(f).AGV.rate(1,x))*Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,origin_m+1)/60;
                                car_no_load_t = sqrt(a^2+b^2-2*a*b*cos(theta_rad));
                                car_no_load_t_temp(1,x) = car_no_load_t;
                                car_no_load_retrieval(1,x) = information_pool(f).AGV.Reschedule_release(1,x)+car_no_load_t;
                            else
                                if origin_m == op_m 
                                    car_no_load_t = (1-information_pool(f).AGV.rate(1,x))*Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,origin_m+1)/60;
                                    car_no_load_t_temp(1,x) = car_no_load_t;
                                    car_no_load_retrieval(1,x) = information_pool(f).AGV.Reschedule_release(1,x)+car_no_load_t;
                                else
                                    a = Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,origin_m+1)/60;
                                    b = Parameter.AGVTime(op_m+1,origin_m+1)/60;
                                    c =  Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,op_m+1)/60;
                                    theta_rad = acos((a^2+b^2-c^2)/(2*a*b));
                                    a = (1-information_pool(f).AGV.rate(1,x))*Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,origin_m+1)/60;
                                    car_no_load_t = sqrt(a^2+b^2-2*a*b*cos(theta_rad));
                                    car_no_load_t_temp(1,x) = car_no_load_t;
                                    car_no_load_retrieval(1,x) = information_pool(f).AGV.Reschedule_release(1,x)+car_no_load_t;
                                end
                            end
                        end
                    end
                else 
                    if op_m == m 
                        bufenpei = true;
                        indexx = find(Decode(9,:) == (integer-1),1);
                        break
                    else
                        if information_pool(f).AGV.position(1,x) == op_m
                            car_no_load_t = 0;
                        else
                            car_no_load_t  = Parameter.AGVTime(information_pool(f).AGV.position(1,x)+1,op_m+1)/60;
                        end
                        car_no_load_t_temp(1,x) = car_no_load_t;
                        car_no_load_retrieval(1,x) = information_pool(f).AGV.Reschedule_release(1,x)+car_no_load_t;
                    end
                end
            else
                current_position = AGVInfor(2,x);
                if op_m == m
                    bufenpei = true;
                    indexx = find(Decode(9,:) == (integer-1),1);
                    break
                else
                    if current_position == op_m
                        car_no_load_t = 0;
                    else
                        car_no_load_t = Parameter.AGVTime(current_position+1,op_m+1)/60;
                    end
                    car_no_load_t_temp(1,x) = car_no_load_t;
                    car_no_load_retrieval(1,x) = AGVInfor(1,x)+car_no_load_t;
                end
            end
        end
        if bufenpei 
            TAGV = 0;
            car_no_load_t = 0;
            car_load_t = 0;
            if isempty(indexx)
                t_mmm_index = Decode(2,:) == m;
                if isempty(t_mmm_index)
                    yizhixing_index = tempDecode(2,:) == m;
                    yizhixing = tempDecode(:,yizhixing_index);
                    if yizhixing(11,end) == integer-1
                        xiuzheng = true;
                        StartT = information_pool(f).machine.Reschedule_release(1,m);
                    else 
                        xiuzheng = false;
                        StartT = information_pool(f).machine.Reschedule_release(1,m);
                    end
                else
                    xiuzheng = false;
                    StartT = MachineCmax(1,m);
                end
            else 
                mmm_index = Decode(2,:) == m;
                mmm = Decode(:,mmm_index);
                shangyidao_index = find(mmm(9,:) == (integer-1),1);
                current_index = find(mmm(9,:) == integer,1);
                if current_index == shangyidao_index+1 
                    xiuzheng = true;
                    Decode(8,indexx) = Decode(8,indexx)-Decode(6,indexx);
                    MachineCmax(1,m) = Decode(8,indexx);
                    JobCmax(1,job) = Decode(8,indexx);
                    StartT = Decode(8,indexx);
                else
                    xiuzheng = false;
                    StartT = MachineCmax(1,m);
                end
            end
        else
            if min(car_no_load_retrieval) >= JobCmax(1,job)
                TAGV = find(car_no_load_retrieval == min(car_no_load_retrieval),1);
                car_no_load_t = car_no_load_t_temp(1,TAGV);
                car_load_t = Parameter.AGVTime(op_m+1,m+1)/60;
                if car_no_load_retrieval(1,TAGV)+car_load_t > MachineCmax(1,m)
                    StartT = car_no_load_retrieval(1,TAGV)+car_load_t;
                else
                    StartT = MachineCmax(1,m);
                end
                AGVInfor(1,TAGV) = car_no_load_retrieval(1,TAGV)+car_load_t;
                AGVInfor(2,TAGV) = m;
            else
                car_no_load_retrieval_temp = JobCmax(1,job) - car_no_load_retrieval; 
                tmp = car_no_load_retrieval_temp > 0; 
                TAGV = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1);
                car_load_t = Parameter.AGVTime(op_m+1,m+1)/60;
                if car_no_load_retrieval(1,TAGV)>=JobCmax(1,job)
                    temp = car_no_load_retrieval(1,TAGV);
                else
                    temp = JobCmax(1,job);
                end
                if  temp+car_load_t > MachineCmax(1,m)
                    StartT = temp+car_load_t;
                else
                    StartT = MachineCmax(1,m);
                end
                AGVInfor(1,TAGV) = car_no_load_retrieval(1,TAGV)+car_load_t;
                AGVInfor(2,TAGV) = m;
            end
        end
    end
    Decode(1,k) = job;
    Decode(2,k) = m;
    Decode(3,k) = TAGV;
    Decode(4,k) = car_no_load_t;
    Decode(5,k) = car_load_t;
    Decode(6,k) = TST;
    Decode(7,k) = StartT;
    if xiuzheng
        Decode(8,k) = StartT+TPT+TST;
    else
        Decode(8,k) = StartT+TST+TPT+TST;
    end
    Decode(9,k) = integer;
    MachineCmax(1,m) = Decode(8,k);
    JobCmax(1,job) = Decode(8,k);

    if TAGV == 0
        if job == 1
            reschedule_individual.Code(4,operation) = randi(Parameter.AGVNum); 
        else
            reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation)=randi(Parameter.AGVNum);
        end
    else
        if job == 1
            reschedule_individual.Code(4,operation) = TAGV; 
        else
            reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation)= TAGV;
        end
    end
end
end
