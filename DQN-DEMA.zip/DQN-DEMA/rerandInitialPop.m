function [reschedule_individual1,reschedule_individual2] = rerandInitialPop(reschedule_individual,information_pool,Parameter)

reschedule_individual1 = reschedule_individual;
reschedule_individual2 = reschedule_individual;
if size(information_pool,1) == 1 
    machine1 = zeros(1,information_pool(1).operation.Reschedule_operations);
    machine2 = zeros(1,information_pool(1).operation.Reschedule_operations);
    for i = 1:information_pool(1).operation.Reschedule_operations
        machinetemp = information_pool(1).machine.Reschedule_available{i};
        index1 = randi(size(machinetemp,2));
        machine1(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index1);
        index2 = randi(size(machinetemp,2));
        machine2(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index2);
    end
    for i = 1:information_pool(1).operation.Reschedule_operations
        integer = information_pool(1).operation.Reschedule_integerschemes(i);
        operation = mod(integer,100);
        job = (integer-operation)/100;
        m1 = machine1(1,i);
        m2 = machine2(1,i);
         if job == 1
            reschedule_individual1.Code(3,operation) = m1;
            reschedule_individual2.Code(3,operation) = m2;
        else
            reschedule_individual1.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m1;
            reschedule_individual2.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m2;
         end
    end
else
    if f == 1
        machine1 = zeros(1,information_pool(f).operation.Reschedule_operations);
        machine2 = zeros(1,information_pool(f).operation.Reschedule_operations);
        for i = 1:information_pool(f).operation.Reschedule_operations
            machinetemp = information_pool(f).machine.Reschedule_available{i};
            index1 = randi(size(machinetemp,2));
            machine1(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index1);
            index2 = randi(size(machinetemp,2));
            machine2(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index2);
        end
        for i = 1:information_pool(f).operation.Reschedule_operations
            integer = information_pool(f).operation.Reschedule_integerschemes(i);
            operation = mod(integer,100);
            job = (integer-operation)/100;
            m1 = machine1(1,i);
            m2 = machine2(1,i);
            if job == 1
                reschedule_individual1.Code(3,operation) = m1;
                reschedule_individual2.Code(3,operation) = m2;
            else
                reschedule_individual1.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m1;
                reschedule_individual2.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m2;
            end
        end
        machine1 = zeros(1,information_pool(f).operation.Reschedule_operations);
        machine2 = zeros(1,information_pool(f).operation.Reschedule_operations);
        for i = 1:information_pool(f).operation.Reschedule_operations
            machinetemp = information_pool(f).machine.Reschedule_available{i};
            index1 = randi(size(machinetemp,2));
            machine1(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index1);
            index2 = randi(size(machinetemp,2));
            machine2(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index2);
        end
        for i = 1:information_pool(f).operation.Reschedule_operations
            integer = information_pool(f).operation.Reschedule_integerschemes(i);
            operation = mod(integer,100);
            job = (integer-operation)/100;
            m1 = machine1(1,i);
            m2 = machine2(1,i);
            if job == 1
                reschedule_individual1.Code(3,operation) = m1;
                reschedule_individual2.Code(3,operation) = m2;
            else
                reschedule_individual1.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m1;
                reschedule_individual2.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m2;
            end
        end
    end
end
end


