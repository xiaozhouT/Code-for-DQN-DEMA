function Population = CrowdDistance(Population)
popSize = size(Population,1); 
numData = 2; 

temp = [Population.Rank]';
temp2 = zeros(popSize,2);
for i = 1:popSize
    fit = Population(i).Fit;
    temp2(i,:) = fit;
end
only_rank = unique(temp);
rank_num = length(only_rank);
for j = 1:rank_num
    rank_Index = temp ==j;
    Index = find(temp ==j);
    Fit_temp = temp2(rank_Index,:);
    rank_Size = size(Fit_temp,1);
    for m = 1:numData
        data = temp2(rank_Index,m);
        [~,index] = sort(data);
        Population(Index(index(1))).Cd = Inf;
        Population(Index(index(end))).Cd = Inf;
        i = 2;
        while i<rank_Size
            Population(Index(index(i))).Cd = Population(Index(index(i))).Cd + (data(index(i+1))-data(index(i-1)))/abs((data(index(end))-data(index(1))));
            i =i+1;
        end
    end
end
            