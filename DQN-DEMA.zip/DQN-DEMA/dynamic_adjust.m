function rePopualtion = dynamic_adjust(rePopualtion,Parameter,information_pool)
for i = 1:size(rePopualtion)
    reIndividualsLS = rePopualtion(i);
    if size(information_pool,1)
        reschedule(1,:) = reIndividualsLS.Code(1,end-information_pool(1).operation.Reschedule_operations+1:end);
        reschedule(2,:) = reIndividualsLS.Code(5,end-information_pool(1).operation.Reschedule_operations+1:end);
        under_load = information_pool(1).operation.position ~= inf;
        if any(under_load ~= 0)
            job_under_load = information_pool(1).operation.Reschedule_integerschemes(under_load); 
            under_load_agv = information_pool(1).operation.position(under_load);
            for op = 1:size(job_under_load,2)
                integer = job_under_load(op);
                operation = mod(integer,100);
                job = (integer-operation)/100;
                if job == 1
                    reIndividualsLS.Code(4,operation) = under_load_agv(op);
                else
                    reIndividualsLS.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = under_load_agv(op);
                end
            end
            temp = job_under_load' == reschedule(2,:);
            temp1 = [];
            for k = 1:size(temp,1)
                temp2 = reschedule(:,temp(k,:));
                temp1 = [temp1,temp2];
            end

            temp3 = job_under_load' ~= reschedule(2,:);
            temp3 = all(temp3==1,1);
            temp4 = reschedule(:,temp3);

            reschedule = [temp1,temp4];

            reIndividualsLS.Code(1,end-information_pool(1).operation.Reschedule_operations+1:end) = reschedule(1,:);
            reIndividualsLS.Code(5,end-information_pool(1).operation.Reschedule_operations+1:end) = reschedule(2,:);
        end
    else
        for f = 1:Parameter.FactoryNum
            if f == 1
                reschedule(1,:) = reIndividualsLS.Code(1,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations);
                reschedule(2,:) = reIndividualsLS.Code(5,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations);
                under_load = information_pool(f).operation.position ~= inf;
                if any(under_load ~= 0)
                    job_under_load = information_pool(f).operation.Reschedule_integerschemes(under_load); 
                    under_load_agv = information_pool(f).operation.position(under_load);
                    for op = 1:size(job_under_load,2)
                        integer = job_under_load(op);
                        operation = mod(integer,100);
                        job = (integer-operation)/100;
                        if job == 1
                            reIndividualsLS.Code(4,operation) = under_load_agv(op);
                        else
                            reIndividualsLS.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = under_load_agv(op);
                        end
                    end
                    temp = job_under_load' == reschedule(2,:);
                    temp1 = [];
                    for k = 1:size(temp,1)
                        temp2 = reschedule(:,temp(k,:));
                        temp1 = [temp1,temp2]; 
                    end

                    temp3 = job_under_load' ~= reschedule(2,:);
                    temp3 = all(temp3==1,1);
                    temp4 = reschedule(:,temp3); 

                    reschedule = [temp1,temp4];

                    reIndividualsLS.Code(1,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations) = reschedule(1,:);
                    reIndividualsLS.Code(5,end-(information_pool(1).operation.Reschedule_operations - information_pool(2).operation.Reschedule_operations) +1:end-information_pool(2).operation.Reschedule_operations) = reschedule(2,:);
                end
            else
                reschedule(1,:) = reIndividualsLS.Code(1,end-information_pool(2).operation.Reschedule_operations+1:end);
                reschedule(2,:) = reIndividualsLS.Code(5,end-information_pool(2).operation.Reschedule_operations+1:end);
                under_load = information_pool(f).operation.position ~= inf;
                if any(under_load ~= 0)
                    job_under_load = information_pool(f).operation.Reschedule_integerschemes(under_load); 
                    under_load_agv = information_pool(f).operation.position(under_load);
                    for op = 1:size(job_under_load,2)
                        integer = job_under_load(op);
                        operation = mod(integer,100);
                        job = (integer-operation)/100;
                        if job == 1
                            reIndividualsLS.Code(4,operation) = under_load_agv(op);
                        else
                            reIndividualsLS.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation) = under_load_agv(op);
                        end
                    end
                    temp = job_under_load' == reschedule(2,:);
                    temp1 = [];
                    for k = 1:size(temp,1)
                        temp2 = reschedule(:,temp(k,:));
                        temp1 = [temp1,temp2]; 
                    end

                    temp3 = job_under_load' ~= reschedule(2,:);
                    temp3 = all(temp3==1,1);
                    temp4 = reschedule(:,temp3);

                    reschedule = [temp1,temp4];

                    reIndividualsLS.Code(1,end-information_pool(2).operation.Reschedule_operations+1:end) = reschedule(1,:);
                    reIndividualsLS.Code(5,end-information_pool(2).operation.Reschedule_operations+1:end) = reschedule(2,:);
                end
            end
        end
    end
    reIndividualsLS = FixingEncoding(Parameter,reIndividualsLS);
    rePopualtion(i) = reIndividualsLS;
end
end

function reSelPopulation = FixingEncoding(Parameter,reSelPopulation)
temp1 = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val1 = reSelPopulation(1).Code(1,j);
    temp1(val1) = temp1(val1)+1;
    reSelPopulation(1).Code(5,j) = val1*100+temp1(val1);
end
end



