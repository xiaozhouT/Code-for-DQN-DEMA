function Population = AGVallocation(Population,Parameter,R)
if nargin == 2 
    R = false;
end
if R 
    Population = randAllocateAGV(Parameter,Population);
else 
    Population = allocateAGV(Parameter,Population);
end
end

function Population = randAllocateAGV(Parameter,Population)
for i = 1:size(Population,1)
    for q = 1:Parameter.MaxJobNum
        temp = zeros(1,Parameter.JobCOPNum(q));
        for p = 1:Parameter.JobCOPNum(q)
            temp(1,p) = randi(Parameter.AGVNum);
        end
        if q == 1
            Population(i).Code(4,1:Parameter.JobCOPNum(q))=temp;
        else
            Population(i).Code(4,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=temp;
        end
    end
end
end

function Population = allocateAGV(Parameter,Population)
Population = factoryinfor(Parameter,Population);

for i = 1:Parameter.NP
    for f = 1:Parameter.FactoryNum
        if f == 1
            tempInfor = Population(i).F1Infor; 
            temp = nnz(tempInfor(5,:));
            if temp ~=0 
                Population = allocate(i,Parameter,Population,tempInfor,temp);
            end
        else
            tempInfor = Population(i).F2Infor;
            temp = nnz(tempInfor(5,:));
            if temp ~=0 
                Population = allocate(i,Parameter,Population,tempInfor,temp);
            end
        end
    end
end
end
function Population = allocate(i,Parameter,Population,tempInfor,temp)
Decode = zeros(9,temp);
JobCmax = zeros(1,Parameter.MaxJobNum);
MachineCmax = zeros(1,Parameter.MaxMachineNum); 
AGVInfor = zeros(2,Parameter.AGVNum); 
n = 0;
totalOP = sum(Parameter.JobCOPNum);
for j = 1:totalOP
    xiuzheng =  false;
    OperationInteger = tempInfor(5,j);
    if OperationInteger == 0
        continue;
    else
        p = (mod(OperationInteger,100));   
        q = (OperationInteger-p)/100;      
        AM = Parameter.AvalueMachine{q,p}; 
        PT = Parameter.ProcessTime{q,p};   
        TST = Parameter.SetupTime(q,p);    
        n = n+1; 
    end
    if q == 1
        TAM = tempInfor(3,p);
    else
        TAM = tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p);
    end
    t1 = length(AM);
    for t2 = 1:t1
        if AM(t2) == TAM
            TPT = PT(t2);
            break;
        end
    end
    if all(MachineCmax(1,:)==0) 
        TAGV = 1;
        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60;
        car_load_t = Parameter.AGVTime(1,TAM+1)/60;
        StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
        AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
        AGVInfor(2,TAGV) = TAM;
        tempj = j;
    else
        if q == 1 
            if q == Decode(1,n-1) 
                if TAM == tempInfor(3,p-1) 
                    TAGV = 0;
                    car_no_load_t = 0;
                    car_load_t = 0;
                    xiuzheng = true;
                    Decode(8,n-1) = Decode(8,n-1)-Decode(6,n-1); 
                    MachineCmax(1,TAM) = Decode(8,n-1);
                    JobCmax(1,q) = Decode(8,n-1);
                    StartT = Decode(8,n-1); 
                    tempj = j;
                else
                    car_no_load_retrieval = zeros(1,Parameter.AGVNum);
                    for x = 1:Parameter.AGVNum
                        current_position_of_car = AGVInfor(2,x) + 1;
                        car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,tempInfor(3,p-1)+1)/60;
                    end
                    if min(car_no_load_retrieval) >= JobCmax(1,q) 
                        TAGV = find(car_no_load_retrieval == min(car_no_load_retrieval),1); 
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,p-1)+1)/60;
                        car_load_t = Parameter.AGVTime(tempInfor(3,p-1)+1,TAM+1)/60;
                        if AGVInfor(1,TAGV) + car_no_load_t + car_load_t > MachineCmax(1,TAM)
                            StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM);
                        end
                        AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    else 
                        car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval; 
                        tmp = car_no_load_retrieval_temp > 0;
                        TAGV = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1); 
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,p-1)+1)/60; 
                        car_load_t = Parameter.AGVTime(tempInfor(3,p-1)+1,TAM+1)/60;
                        if car_no_load_retrieval(1,TAGV)>=JobCmax(1,q)
                            tmmp = car_no_load_retrieval(1,TAGV);
                        else
                            tmmp = JobCmax(1,q);
                        end
                        if tmmp + car_load_t > MachineCmax(1,TAM)
                            StartT = tmmp + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM);
                        end
                        AGVInfor(1,TAGV) = tmmp + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    end
                end
            else 
                if JobCmax(1,q) == 0 
                    car_no_load_retrieval = zeros(1,Parameter.AGVNum);
                    for x = 1:Parameter.AGVNum
                        current_position_of_car = AGVInfor(2,x) + 1;
                        car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,1)/60; 
                    end
                    if min(car_no_load_retrieval) >= JobCmax(1,q)
                        TAGV = find(car_no_load_retrieval == min(car_no_load_retrieval),1);
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60;
                        car_load_t = Parameter.AGVTime(1,TAM+1)/60;
                        if AGVInfor(1,TAGV) + car_no_load_t + car_load_t > MachineCmax(1,TAM) 
                            StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM);
                        end
                        AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    else
                        car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval; 
                        tmp = car_no_load_retrieval_temp > 0; 
                        TAGV = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1);
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60; 
                        car_load_t = Parameter.AGVTime(1,TAM+1)/60;
                        if car_no_load_retrieval(1,TAGV) > JobCmax(1,q)
                            tmmp = car_no_load_retrieval(1,TAGV);
                        else
                            tmmp = JobCmax(1,q);
                        end
                        if tmmp + car_load_t > MachineCmax(1,TAM)
                            StartT = tmmp + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM);
                        end
                        AGVInfor(1,TAGV) = tmmp + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    end
                else 
                    if TAM == tempInfor(3,p-1) 
                        in1 = find(Decode(9,:) == OperationInteger-1);
                        tempin1 = Decode(2,in1+1:n-1);
                        if ismember(tempInfor(3,p-1),tempin1) 
                            car_no_load_t = 0;
                            car_load_t = 0;
                            TAGV = 0;
                            StartT =  MachineCmax(1,TAM);
                            tempj = j;
                        else 
                            car_no_load_t = 0;
                            car_load_t = 0;
                            TAGV = 0;
                            xiuzheng = true;
                            Decode(8,in1) = Decode(8,in1)-Decode(6,in1); 
                            MachineCmax(1,TAM) = Decode(8,in1);
                            JobCmax(1,q) = Decode(8,in1);
                            StartT = Decode(8,in1); 
                            tempj = j;
                        end
                    else
                        car_no_load_retrieval = zeros(1,Parameter.AGVNum);
                        for x = 1:Parameter.AGVNum
                            current_position_of_car = AGVInfor(2,x) + 1;
                            car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,tempInfor(3,p-1)+1)/60;
                        end
                        if min(car_no_load_retrieval) >= JobCmax(1,q)
                            TAGV = find(car_no_load_retrieval == min(car_no_load_retrieval),1);
                            car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,p-1)+1)/60;
                            car_load_t = Parameter.AGVTime(tempInfor(3,p-1)+1,TAM+1)/60;
                            if AGVInfor(1,TAGV) + car_no_load_t + car_load_t > MachineCmax(1,TAM) 
                                StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                            else
                                StartT = MachineCmax(1,TAM);
                            end
                            AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                            AGVInfor(2,TAGV) = TAM;
                            tempj = j;
                        else
                            car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval; 
                            tmp = car_no_load_retrieval_temp > 0; 
                            TAGV = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1);
                            car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,p-1)+1)/60;
                            car_load_t = Parameter.AGVTime(tempInfor(3,p-1)+1,TAM+1)/60;
                            if car_no_load_retrieval(1,TAGV) > JobCmax(1,q)
                                tmmp = car_no_load_retrieval(1,TAGV);
                            else
                                tmmp = JobCmax(1,q);
                            end
                            if tmmp + car_load_t > MachineCmax(1,TAM)
                                StartT = tmmp + car_load_t;
                            else
                                StartT = MachineCmax(1,TAM);
                            end
                            AGVInfor(1,TAGV) = tmmp + car_load_t;
                            AGVInfor(2,TAGV) = TAM;
                            tempj = j;
                        end
                    end
                end
            end
        else 
            if q == Decode(1,n-1)
                if TAM == tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)
                    TAGV = 0; 
                    car_no_load_t = 0;
                    car_load_t = 0;
                    xiuzheng = true;
                    Decode(8,n-1) = Decode(8,n-1)-Decode(6,n-1); 
                    MachineCmax(1,TAM) = Decode(8,n-1);
                    JobCmax(1,q) = Decode(8,n-1);
                    StartT = Decode(8,n-1); 
                    tempj = j;
                else
                    car_no_load_retrieval = zeros(1,Parameter.AGVNum);
                    for x = 1:Parameter.AGVNum
                        current_position_of_car = AGVInfor(2,x) + 1;
                        car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60;
                    end
                    if min(car_no_load_retrieval) >= JobCmax(1,q)
                        TAGV = find(car_no_load_retrieval == min(car_no_load_retrieval),1); 
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60;
                        car_load_t = Parameter.AGVTime(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1,TAM+1)/60;
                        if AGVInfor(1,TAGV) + car_no_load_t + car_load_t > MachineCmax(1,TAM) 
                            StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM);
                        end
                        AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    else 
                        car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval;
                        tmp = car_no_load_retrieval_temp > 0; 
                        TAGV = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1);
                        car_no_load_t =  Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60; 
                        car_load_t = Parameter.AGVTime(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1,TAM+1)/60;
                        if car_no_load_retrieval(1,TAGV) > JobCmax(1,q)
                            tmmp = car_no_load_retrieval(1,TAGV);
                        else
                            tmmp = JobCmax(1,q);
                        end
                        if tmmp + car_load_t > MachineCmax(1,TAM)
                            StartT = tmmp + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM)+TST;
                        end
                        AGVInfor(1,TAGV) = tmmp + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    end
                end
            else
                if JobCmax(1,q) == 0 
                    car_no_load_retrieval = zeros(1,Parameter.AGVNum);
                    for x = 1:Parameter.AGVNum
                        current_position_of_car = AGVInfor(2,x) + 1;
                        car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,1)/60;
                    end
                    if min(car_no_load_retrieval) >= JobCmax(1,q)
                        TAGV = find(car_no_load_retrieval == min(car_no_load_retrieval),1); 
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60;
                        car_load_t = Parameter.AGVTime(1,TAM+1)/60;
                        if AGVInfor(1,TAGV) + car_no_load_t + car_load_t > MachineCmax(1,TAM)
                            StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM);
                        end
                        AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    else
                        car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval; 
                        tmp = car_no_load_retrieval_temp > 0;
                        TAGV = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1); 
                        car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,1)/60; 
                        car_load_t = Parameter.AGVTime(1,TAM+1)/60;
                        if car_no_load_retrieval(1,TAGV) > JobCmax(1,q)
                            tmmp = car_no_load_retrieval(1,TAGV);
                        else
                            tmmp = JobCmax(1,q);
                        end
                        if tmmp + car_load_t > MachineCmax(1,TAM)
                            StartT = tmmp + car_load_t;
                        else
                            StartT = MachineCmax(1,TAM);
                        end
                        AGVInfor(1,TAGV) = tmmp + car_load_t;
                        AGVInfor(2,TAGV) = TAM;
                        tempj = j;
                    end
                else
                    if TAM == tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1) 
                        in1 = find(Decode(9,:) == OperationInteger-1);
                        tempin1 = Decode(2,in1+1:n-1);
                        if ismember(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1),tempin1) 
                            car_no_load_t = 0;
                            car_load_t = 0;
                            TAGV = 0;
                            StartT =  MachineCmax(1,TAM);
                            tempj = j;
                        else 
                            car_no_load_t = 0;
                            car_load_t = 0;
                            TAGV = 0;
                            xiuzheng = true;
                            Decode(8,in1) = Decode(8,in1)-Decode(6,in1); 
                            MachineCmax(1,TAM) = Decode(8,in1);
                            JobCmax(1,q) = Decode(8,in1);
                            StartT = Decode(8,in1); 
                            tempj = j;
                        end
                    else
                        car_no_load_retrieval = zeros(1,Parameter.AGVNum);
                        for x = 1:Parameter.AGVNum
                            current_position_of_car = AGVInfor(2,x) + 1;
                            car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60;
                        end
                        if min(car_no_load_retrieval) >= JobCmax(1,q)
                            TAGV = find(car_no_load_retrieval == min(car_no_load_retrieval),1); 
                            car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60;
                            car_load_t = Parameter.AGVTime(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1,TAM+1)/60;
                            if AGVInfor(1,TAGV) + car_no_load_t + car_load_t > MachineCmax(1,TAM)
                                StartT = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                            else
                                StartT = MachineCmax(1,TAM);
                            end
                            AGVInfor(1,TAGV) = AGVInfor(1,TAGV) + car_no_load_t + car_load_t;
                            AGVInfor(2,TAGV) = TAM;
                            tempj = j;
                        else
                            car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval; 
                            tmp = car_no_load_retrieval_temp > 0;
                            TAGV = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1);
                            car_no_load_t = Parameter.AGVTime(AGVInfor(2,TAGV)+1,tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1)/60;
                            car_load_t = Parameter.AGVTime(tempInfor(3,sum(Parameter.JobCOPNum(1:q-1))+p-1)+1,TAM+1)/60;
                            if car_no_load_retrieval(1,TAGV) > JobCmax(1,q)
                                tmmp = car_no_load_retrieval(1,TAGV);
                            else
                                tmmp = JobCmax(1,q);
                            end
                            if tmmp + car_load_t > MachineCmax(1,TAM)
                                StartT = tmmp + car_load_t;
                            else
                                StartT = MachineCmax(1,TAM);
                            end
                            AGVInfor(1,TAGV) = tmmp + car_load_t;
                            AGVInfor(2,TAGV) = TAM;
                            tempj = j;
                        end
                    end
                end
            end
        end
    end
    Decode(1,n) = q; 
    Decode(2,n) = TAM;
    Decode(3,n) = TAGV;
    Decode(4,n) = car_no_load_t;
    Decode(5,n) = car_load_t;
    Decode(6,n) = TST;
    Decode(7,n) = StartT;
    if xiuzheng
        Decode(8,n) = StartT+TPT+TST;
    else
        Decode(8,n) = StartT+TST+TPT+TST;
    end
    Decode(9,n) = OperationInteger;
    MachineCmax(1,TAM) = Decode(8,n); 
    JobCmax(1,q) = Decode(8,n);
    if TAGV == 0
        TAGV = randi(Parameter.AGVNum);
    end
    if q == 1
        Population(i).Code(4,p) = TAGV;
    else
        Population(i).Code(4,sum(Parameter.JobCOPNum(1:q-1))+p)=TAGV;
    end
end
end

