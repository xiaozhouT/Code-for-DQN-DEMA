function IndividualsLS = L1(i,Parameter,ItEliteIndividual)
IndividualsLS = ItEliteIndividual(i); 
IndividualsLS = N6(IndividualsLS,Parameter);
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = IndividualsLS.Code(1,j);
    temp(val) = temp(val)+1;
    IndividualsLS.Code(5,j) = val*100+temp(val);
end
IndividualsLS = fitness(IndividualsLS,Parameter); 
end

function IndividualsLS = N6(IndividualsLS,Parameter)
for fac = 1:Parameter.FactoryNum
    if fac == 1
        tempDecode = IndividualsLS.F1Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F1CriticalPath;
            BlockB = length(IndividualsLS.F1CriticalBlock.B); 
            BlockC = length(IndividualsLS.F1CriticalBlock.C); 
            tempCriticalBlockB = IndividualsLS.F1CriticalBlock.B;
            tempCriticalBlockC = IndividualsLS.F1CriticalBlock.C;
            IndividualsLS = ExecuteN6(IndividualsLS,tempDecode,tempCriticalPath,BlockB,BlockC,tempCriticalBlockB,tempCriticalBlockC);
        end
    else
        tempDecode = IndividualsLS.F2Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F2CriticalPath;
            BlockB = length(IndividualsLS.F2CriticalBlock.B); 
            BlockC = length(IndividualsLS.F2CriticalBlock.C); 
            tempCriticalBlockB = IndividualsLS.F2CriticalBlock.B;
            tempCriticalBlockC = IndividualsLS.F2CriticalBlock.C;
            IndividualsLS = ExecuteN6(IndividualsLS,tempDecode,tempCriticalPath,BlockB,BlockC,tempCriticalBlockB,tempCriticalBlockC);
        end
    end
end
end

function IndividualsLS = ExecuteN6(IndividualsLS,tempDecode,tempCriticalPath,BlockB,BlockC,tempCriticalBlockB,tempCriticalBlockC)

tempIndex = zeros(1,length(tempCriticalPath));
for l = 1:length(tempCriticalPath)
    tempIndex(l) = find(IndividualsLS.Code(5,:) == tempDecode(11,tempCriticalPath(l))); 
end

for b = 1:BlockB
    BL = length(tempCriticalBlockB(b).B);
    if BL>1
        if b == 1
            Index1 = ceil(rand*(BL-1)); 
            Index2 = BL;
            Index1 = tempCriticalBlockB(b).B(Index1); 
            Index2 = tempCriticalBlockB(b).B(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1)); 
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11);
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS.Code(1,tempIndex(Index111));
            for j = Index111:Index222-1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j+1));
            end
            IndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
        end

        if b == BlockB
            Index1=1;  
            Index2=ceil(rand*(BL-1))+1;
            Index1 = tempCriticalBlockB(b).B(Index1);
            Index2 = tempCriticalBlockB(b).B(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11);
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS.Code(1,tempIndex(Index222));
            for j = Index222:-1:Index111+1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j-1));
            end
            IndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
        end

        if b > 1 && b < BlockB && BL > 2
            Index1=ceil(rand*(BL-2))+1; 
            Index2 = BL;
            Index1 = tempCriticalBlockB(b).B(Index1);
            Index2 = tempCriticalBlockB(b).B(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1)); 
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11); 
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS(1).Code(1,tempIndex(Index111));
            for j = Index111:Index222-1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j+1));
            end
            IndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
            Index1=1; 
            Index2=ceil(rand*(BL-2))+1;
            Index1 = tempCriticalBlockB(b).B(Index1);
            Index2 = tempCriticalBlockB(b).B(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11);
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS.Code(1,tempIndex(Index222));
            for j = Index222:-1:Index111+1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j-1));
            end
            IndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
        end
    end
end

for c = 1:BlockC
    CL = length(tempCriticalBlockC(c).C);
    if CL>1
        if c == 1
            Index1 = ceil(rand*(CL-1));
            Index2 = CL; 
            Index1 = tempCriticalBlockC(c).C(Index1); 
            Index2 = tempCriticalBlockC(c).C(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1)); 
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11); 
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS(1).Code(1,tempIndex(Index111));
            for j = Index111:Index222-1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j+1));
            end
            IndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
        end

        if c == BlockC
            Index1=1; 
            Index2=ceil(rand*(CL-1))+1;
            Index1 = tempCriticalBlockC(c).C(Index1);
            Index2 = tempCriticalBlockC(c).C(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11); 
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS.Code(1,tempIndex(Index222));
            for j = Index222:-1:Index111+1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j-1));
            end
            IndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
        end

        if c > 1 && c < BlockC && CL > 2
            Index1=ceil(rand*(CL-2))+1; 
            Index2 = CL;
            Index1 = tempCriticalBlockC(c).C(Index1);
            Index2 = tempCriticalBlockC(c).C(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11); 
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS(1).Code(1,tempIndex(Index111));
            for j = Index111:Index222-1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j+1));
            end
            IndividualsLS.Code(1,tempIndex(Index222)) = tmp1;
            Index1=1;
            Index2=ceil(rand*(CL-2))+1;
            Index1 = tempCriticalBlockC(c).C(Index1);
            Index2 = tempCriticalBlockC(c).C(Index2);
            Index11 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index1));
            Index22 = find(IndividualsLS.Code(5,:) == tempDecode(11,Index2));
            Index111 = find(tempIndex==Index11);
            Index222 = find(tempIndex==Index22);
            tmp1 = IndividualsLS.Code(1,tempIndex(Index222));
            for j = Index222:-1:Index111+1
                IndividualsLS.Code(1,tempIndex(j)) = IndividualsLS.Code(1,tempIndex(j-1));
            end
            IndividualsLS.Code(1,tempIndex(Index111)) = tmp1;
        end
    end
end
end

        




    


    