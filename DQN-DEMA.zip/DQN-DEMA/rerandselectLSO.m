function [Parameter,reEliteIndividual] = rerandselectLSO(selected_indices,Parameter,reEliteIndividual_temp,reEliteIndividual,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time)
for i = 1:size(reEliteIndividual_temp,1)
    % state = reshape(reEliteIndividual_temp(i).Code(1:4,:),1,4*sum(Parameter.JobCOPNum))';
    % dlState = dlarray(state, 'CB');
    % qValues = predict(target_Q_network, dlState);
    % qValues = extractdata(qValues);
    % [~, action] = max(qValues);
    action = randi(4);
    switch action
        case 1
            reIndividualsLS = reL1(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
        case 2
            reIndividualsLS = reL2(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
        case 3
            reIndividualsLS = reL3(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
        case 4
            reIndividualsLS = reL4(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
    end
    if any(reIndividualsLS(1).Fit<reEliteIndividual_temp(i).Fit) && all(reIndividualsLS(1).Fit<=reEliteIndividual_temp(i).Fit)
        reEliteIndividual(selected_indices(i)) = reIndividualsLS(1);
        continue
    elseif any(reIndividualsLS(1).Fit<=reEliteIndividual_temp(i).Fit)
        continue
    elseif any(reIndividualsLS(1).Fit>reEliteIndividual_temp(i).Fit) && all(reIndividualsLS(1).Fit>=reEliteIndividual_temp(i).Fit)
        continue
    end
end

end