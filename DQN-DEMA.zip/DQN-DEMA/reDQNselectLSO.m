function [Parameter,reEliteIndividual,experienceBuffer,currentBufferSize,target_Q_network] = reDQNselectLSO(selected_indices,Parameter,reEliteIndividual_temp,reEliteIndividual,target_Q_network,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time,...
    experienceBuffer,currentBufferSize,batch_size,learning_rate,updateTargetFrequency)
newtarget_Q_network = target_Q_network;
for i = 1:size(reEliteIndividual_temp,1)
    state = reshape(reEliteIndividual_temp(i).Code(1:4,:),1,4*sum(Parameter.JobCOPNum))';
    dlState = dlarray(state, 'CB');
    qValues = predict(target_Q_network, dlState);
    qValues = extractdata(qValues);
    [~, action] = max(qValues);
    switch action
        case 1
            reIndividualsLS = reL1(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
        case 2
            reIndividualsLS = reL2(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
        case 3
            reIndividualsLS = reL3(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
        case 4
            reIndividualsLS = reL4(i,Parameter,reEliteIndividual_temp,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
    end
    if any(reIndividualsLS(1).Fit<reEliteIndividual_temp(i).Fit) && all(reIndividualsLS(1).Fit<=reEliteIndividual_temp(i).Fit)
        reEliteIndividual(selected_indices(i)) = reIndividualsLS(1);
        reward = 10;
        continue
    elseif any(reIndividualsLS(1).Fit<=reEliteIndividual_temp(i).Fit)
        reward = 0;
        continue
    elseif any(reIndividualsLS(1).Fit>reEliteIndividual_temp(i).Fit) && all(reIndividualsLS(1).Fit>=reEliteIndividual_temp(i).Fit)
        reward = 0;
        continue
    end
    next_state = [reIndividualsLS.Code(1,:),reIndividualsLS.Code(2,:),reIndividualsLS.Code(3,:),reIndividualsLS.Code(4,:)];
    [experienceBuffer, currentBufferSize] = storeExperience(experienceBuffer, currentBufferSize, state, action, reward, next_state, bufferSize);
    if currentBufferSize >= batch_size
        miniBatch = sampleMiniBatch(experienceBuffer,currentBufferSize,batch_size);
        states = cell2mat(cellfun(@(x) x{1}, miniBatch, 'UniformOutput', false))';
        actions = cell2mat(cellfun(@(x) x{2}, miniBatch, 'UniformOutput', false));
        rewards = cell2mat(cellfun(@(x) x{3}, miniBatch, 'UniformOutput', false));
        nextStates = cell2mat(cellfun(@(x) x{4}, miniBatch, 'UniformOutput', false))';
        dlNextStates = dlarray(nextStates, 'CB');
        targetQValues = predict(newtarget_Q_network, dlNextStates);
        maxNextQValues = max(extractdata(targetQValues), [], 1);
        targets = rewards' + gamma * maxNextQValues;
        [gradients, loss] = dlfeval(@modelGradients,target_Q_network,states,actions,targets);
        [target_Q_network, gradientsBuffer, velocityBuffer] = adamupdate(target_Q_network, gradients, gradientsBuffer, velocityBuffer,i,learning_rate);
        losses = [losses; double(loss)];
        if mod(i,updateTargetFrequency) == 0
            newtarget_Q_network.Learnables.Value = target_Q_network.Learnables.Value;
        end
    end
end
target_Q_network = newtarget_Q_network;
end

function [experienceBuffer, currentBufferSize] = storeExperience(experienceBuffer, currentBufferSize, state, action, reward, nextState, bufferSize)
    experience = {state, action, reward, nextState};
    if currentBufferSize < bufferSize
        currentBufferSize = currentBufferSize + 1;
    else
        experienceBuffer = experienceBuffer(2:end); 
    end
    experienceBuffer{currentBufferSize} = experience; 
end
function miniBatch = sampleMiniBatch(experienceBuffer, currentBufferSize, miniBatchSize)
    if currentBufferSize < miniBatchSize
        error('Not enough samples in the experience buffer to sample a mini-batch');
    end
    indices = randperm(currentBufferSize, miniBatchSize);
    miniBatch = experienceBuffer(indices);
end