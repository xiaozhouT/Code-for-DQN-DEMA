
function Population = findCriticalpath4(Parameter,Population)
Path_Block_T.F1CriticalPath = [];
Path_Block_T.F1CriticalBlock.B = struct;
Path_Block_T.F1CriticalBlock.C= struct;
Path_Block_T.F2CriticalPath = [];
Path_Block_T.F2CriticalBlock.B = struct;
Path_Block_T.F2CriticalBlock.C= struct;
Path_Block = repmat(Path_Block_T,size(Population,1),1);  
for n = 1:size(Population,1)
    for fac = 1:Parameter.FactoryNum
        if fac == 1
            tempDecode = Population(n).F1Decode;
            if ~ isempty(tempDecode) 
                [Path,BlockB,BlockC] = Criticalpath(tempDecode,Parameter); 
                Path_Block(n).F1CriticalPath = Path;
                Path_Block(n).F1CriticalBlock.B = BlockB;
                Path_Block(n).F1CriticalBlock.C = BlockC;
            end
        else
            tempDecode = Population(n).F2Decode;
            if ~ isempty(tempDecode)
                [Path,BlockB,BlockC] = Criticalpath(tempDecode,Parameter);
                Path_Block(n).F2CriticalPath = Path;
                Path_Block(n).F2CriticalBlock.B = BlockB;
                Path_Block(n).F2CriticalBlock.C = BlockC;
            end
        end
    end
    Population(n).F1CriticalPath = Path_Block(n).F1CriticalPath;
    Population(n).F2CriticalPath = Path_Block(n).F2CriticalPath;
    Population(n).F1CriticalBlock.B = Path_Block(n).F1CriticalBlock.B;
    Population(n).F2CriticalBlock.B = Path_Block(n).F2CriticalBlock.B;
    Population(n).F1CriticalBlock.C = Path_Block(n).F1CriticalBlock.C;
    Population(n).F2CriticalBlock.C = Path_Block(n).F2CriticalBlock.C;
end
end

function [Path,BlockB,BlockC] = Criticalpath(tempDecode,Parameter)

p_chrom = tempDecode(1,:);
m_chrom = tempDecode(2,:);
agv_chrom = tempDecode(3,:);
SH = length(p_chrom);
Path = [];
digraph = zeros(SH,4); 
dflag = zeros(SH,4);

s1 = p_chrom;
s2 = zeros(1,SH);
p=zeros(1,Parameter.MaxJobNum); 
for i = 1:SH
    p(s1(i)) = p(s1(i))+1;
    s2(i) = p(s1(i));
end

for i = 1:SH
    to = p_chrom(i);
    tm = m_chrom(i);
    for j = i+1:SH
        if to == p_chrom(j) && dflag(i,1)==0
            digraph(i,1) = j;
            dflag(i,1) = 1;
            digraph(j,3) = i;
            dflag(j,3) = 1;
        end
        if tm == m_chrom(j) && dflag(i,2)==0
            digraph(i,2) = j;
            dflag(i,2) = 1;
            digraph(j,4) = i;
            dflag(j,4) = 1;
        end
        if (dflag(i,1)==1 || s2(i)==p(s1(i))) && dflag(i,2)==1
            break;
        end
    end
end

VELTime = cell(SH,2);  
%% Earliest start time
for i = 1:SH
    VELTime{i,1} = tempDecode(9,i);
end

%% Calculating the latest start time
Lastnode = tempDecode(10,find(tempDecode(10,:) == max(tempDecode(10,:)),1));

for i = SH:-1:1
    if digraph(i,1) == 0
        if digraph(i,2) == 0
            VELTime{i,2} = Lastnode-(tempDecode(10,i)-tempDecode(9,i));
        else
            next = digraph(i,2); 
            t1 = Lastnode-(tempDecode(10,i)-tempDecode(9,i));
            t2 = VELTime{next,2}-(tempDecode(10,i)-tempDecode(9,i));
            if t1 > t2
                VELTime{i,2} = t2;
            else
                VELTime{i,2} = t1;
            end
        end
        continue
    end

    t1 = 0;
    t2 = 0;
    if digraph(i,1) ~= 0
        next = digraph(i,1); 
        if agv_chrom(1,next) == 0 
            t1 = VELTime{next,2} - (tempDecode(10,i)-tempDecode(9,i));
        else
            t1 = tempDecode(5,next) - (tempDecode(10,i)-tempDecode(9,i));
        end
        if digraph(i,2) == 0 
            VELTime{i,2} = t1;
            continue
        end
    end
    if digraph(i,2) ~= 0 
        next = digraph(i,2);
        t2 = VELTime{next,2}-(tempDecode(10,i)-tempDecode(9,i));
    end
    if t1 > t2
        VELTime{i,2} = t2;
    else
        VELTime{i,2} = t1;
    end
end
Idletime = cell(SH,1);
precisionThreshold = 0.00001;
for i = 1:SH
    Idletime{i,1}=VELTime{i,2}-VELTime{i,1};
    if abs(Idletime{i,1})<precisionThreshold
        Idletime{i,1} = 0;
    end
end
minIndex = 1;
if isempty(Idletime{1,1})
    minIdleT = 0;
else
    minIdleT = Idletime{1,1};
end
for i = 2:SH
    if minIdleT > Idletime{i,1}
        minIndex=i;
        minIdleT=Idletime{i,1};
    end
end
for i = 1:SH
    if minIdleT == Idletime{i,1}
        Path = [Path,i];
    end
end

if Path(1) ~= 1 
    index = Path(1);
    tempin = index;
    for aa = 1:Path(1)
        previous_index = find_previous_index(agv_chrom,tempin);
        if previous_index == -1
            break
        end
        Path = [previous_index,Path];
        tempin = previous_index;
    end
end

L = length(Path);
block = 1;
BlockB = struct;
BlockB.B = struct;
BlockB(block).B = []; 
BlockB(block).B = [BlockB(block).B,Path(1)];
m0 = m_chrom(Path(1));
for i = 2:L
    m = m_chrom(Path(i));
    if m0 == m
        if abs(tempDecode(9,Path(i))-tempDecode(10,Path(i-1)))<= precisionThreshold
            BlockB(block).B = [BlockB(block).B,Path(i)];
        else
            block = block+1;
            BlockB(block).B = [];
            BlockB(block).B = [BlockB(block).B,Path(i)];
            continue
        end
    else
        block = block+1;
        BlockB(block).B = [];
        BlockB(block).B = [BlockB(block).B,Path(i)];
    end
    m0 = m;
end

block = 1;
BlockC = struct;
BlockC.C = struct;
BlockC(block).C= [];
BlockC(block).C = [BlockC(block).C,Path(1)];
agv0 = agv_chrom(Path(1));
for i = 2:L
    agv = agv_chrom(Path(i));
    if agv0 == agv
        if abs((tempDecode(5,Path(i))-tempDecode(4,Path(i))) - tempDecode(7,Path(i-1))) <= precisionThreshold
            BlockC(block).C = [BlockC(block).C,Path(i)];
        else
            block = block+1;
            BlockC(block).C = [];
            BlockC(block).C = [BlockC(block).C,Path(i)];
            continue
        end
    else
        block = block+1;
        BlockC(block).C = [];
        BlockC(block).C = [BlockC(block).C,Path(i)];
    end
    agv0 = agv;
end

end

function previous_index = find_previous_index(arr, current_index)
    current_value = arr(current_index);
    for j = current_index - 1:-1:1
        if arr(j) == current_value
            previous_index = j;
            return;
        end
    end
    previous_index = -1; 
end

function back_index = find_back_index(arr, current_index)
    current_value = arr(current_index);
    for j = current_index + 1:1:length(arr)
        if arr(j) == current_value
            back_index = j;
            return;
        end
    end
    back_index = -1;
end
