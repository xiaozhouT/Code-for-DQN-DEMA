% First Stage Algorithm to sovle stactic FJSP
% This function needs to implement the static pre-scheduling of the first stage to obtain the scheduling result
function [Population,Parameter,Trace,Preschedule_Score,EliteIndividual,Preschedule,Preschedule_PF]= EMA(Parameter,Population,Individual,target_Q_network)
Population = InitialPop(Population,Parameter,1);
Population = AGVallocation(Population,Parameter,1);

Population = fitness(Population,Parameter);
Population = Dominated(Population);
Population = CrowdDistance(Population);
EliteIndividual = Population([find([Population.Rank]'==1)]); 
Trace = zeros(Parameter.MaxIt,2); 
for it = 1:Parameter.MaxIt 

    SelPopulation = repmat(Individual,Parameter.NP,1); 
    SelPopulation = Select(Parameter,Population,SelPopulation); 
    SelPopulation = Cross(Parameter,SelPopulation); 
    SelPopulation = Mutation(Parameter,SelPopulation);
    SelPopulation = fitness(SelPopulation,Parameter);

    MergePopulation = [Population;SelPopulation];   
    MergePopulation = Dominated(MergePopulation); 
    MergePopulation = CrowdDistance(MergePopulation); 
    MergePopulation = TrimPopulation(Parameter,MergePopulation);

    Population = MergePopulation;

    EliteIndex = [Population.Rank]'==1; 
    EliteIndividual =[EliteIndividual;Population(EliteIndex)]; %#ok<*AGROW>
    onlyfit = zeros(size(EliteIndividual,1),2);
    for i = 1:size(EliteIndividual,1)
        fit = EliteIndividual(i).Fit;
        onlyfit(i,:) = fit;
    end
    [onlyfit,ia] = unique(onlyfit,'rows');
    EliteIndividual = EliteIndividual(ia);
    Ittem = it;
    if Ittem >= Parameter.MaxIt * Parameter.historyIt
        selected_indices = EMArouletteWheelSelection(onlyfit,Parameter);
        EliteIndividual_temp = EliteIndividual(selected_indices);
        EliteIndividual_temp = findCriticalpath4(Parameter,EliteIndividual_temp);
        [Parameter,EliteIndividual] = DQNselectLSO(selected_indices,Parameter,EliteIndividual_temp,EliteIndividual,target_Q_network);
    end

    onlyfit = zeros(size(EliteIndividual,1),2);
    for i = 1:size(EliteIndividual,1)
        fit = EliteIndividual(i).Fit;
        onlyfit(i,:) = fit;
    end
    [~,ia] = unique(onlyfit,'rows');
    EliteIndividual = EliteIndividual(ia);
    Trace(it,1) = mean(onlyfit(:,1));
    Trace(it,2) = mean(onlyfit(:,2));
end

onlyfit = zeros(size(EliteIndividual,1),2);
for i = 1:size(EliteIndividual,1)
    fit = EliteIndividual(i).Fit;
    onlyfit(i,:) = fit;
end
[~,ia] = unique(onlyfit,'rows');
EliteIndividual = EliteIndividual(ia);
EliteIndividual = Dominated(EliteIndividual); 
EliteIndividual = CrowdDistance(EliteIndividual); 

Preschedule = EliteIndividual([EliteIndividual.Rank]'==1); 
Preschedule_PF = zeros(size(Preschedule,1),2);
for i = 1:size(Preschedule,1)
    fit = Preschedule(i).Fit;
    Preschedule_PF (i,:) = fit;
end
Preschedule_Score = ExperimentalIndicators(Preschedule_PF, Parameter);
end