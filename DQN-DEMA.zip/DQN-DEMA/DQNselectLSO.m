
function [Parameter,EliteIndividual] = DQNselectLSO(selected_indices,Parameter,EliteIndividual_temp,EliteIndividual,target_Q_network)
% Divisiontemp = cumsum(Division);
for i = 1:size(EliteIndividual_temp,1)
    % state = reshape(EliteIndividual_temp(i).Code(1:4,:),1,4*sum(Parameter.JobCOPNum))';
    % dlState = dlarray(state, 'CB');
    % qValues = predict(target_Q_network, dlState);
    % qValues = extractdata(qValues);
    % [~, action] = max(qValues);
    action = randi(4);
    switch action
        case 1
            IndividualsLS = L1(i,Parameter,EliteIndividual_temp);
        case 2
            IndividualsLS = L2(i,Parameter,EliteIndividual_temp);
        case 3 
            IndividualsLS = L3(i,Parameter,EliteIndividual_temp);
        case 4
            IndividualsLS = L4(i,Parameter,EliteIndividual_temp);
    end

    if any(IndividualsLS(1).Fit<EliteIndividual_temp(i).Fit) && all(IndividualsLS(1).Fit<=EliteIndividual_temp(i).Fit)
        EliteIndividual(selected_indices(i)) = IndividualsLS(1);
        continue
    elseif any(IndividualsLS(1).Fit<=EliteIndividual_temp(i).Fit)
        continue
    elseif any(IndividualsLS(1).Fit>EliteIndividual_temp(i).Fit) && all(IndividualsLS(1).Fit>=EliteIndividual_temp(i).Fit)
        continue
    end
end
end
