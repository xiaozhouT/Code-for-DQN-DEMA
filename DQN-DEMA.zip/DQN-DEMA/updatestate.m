function information_pool = updatestate(reschedule_individual,Parameter,breakdown_fac,breakdown_time,repair_time,breakdown_machine)

if size(breakdown_fac,2) == 1
    if breakdown_fac == 1
        tempDecode = reschedule_individual.F1Decode;
    else
        tempDecode = reschedule_individual.F2Decode;
    end
    information_pool = singlefacbreak(reschedule_individual,tempDecode,Parameter,breakdown_time,repair_time,breakdown_machine);  
else
    for f = 1:size(breakdown_fac,2)
        if breakdown_fac == 1
            tempDecode = reschedule_individual.F1Decode;
            breakdown_machine = breakdown_machine(1);
            information_pool = singlefacbreak(reschedule_individual,tempDecode,Parameter,breakdown_time,repair_time,breakdown_machine);
            information_pool_F1 = information_pool;
        else
            tempDecode = reschedule_individual.F2Decode;
            breakdown_machine = breakdown_machine(2);
            information_pool = singlefacbreak(reschedule_individual,tempDecode,Parameter,breakdown_time,repair_time,breakdown_machine);
            information_pool_F2 = information_pool;
        end
        information_pool = [information_pool_F1;information_pool_F2];
    end
end
end

function information_pool = singlefacbreak(reschedule_individual,tempDecode,Parameter,breakdown_time,repair_time,breakdown_machine)

direct_effect_pos1 = tempDecode(9,:) < breakdown_time;
direct_effect_pos2 = tempDecode(10,:) > breakdown_time;
direct_effect_pos = [direct_effect_pos1;direct_effect_pos2];
direct_effect_pos = direct_effect_pos(1,:)==direct_effect_pos(2,:); 
indirect_affect_pos = tempDecode(9,:) >= breakdown_time; 

remaining_operation = nnz(direct_effect_pos)+nnz(indirect_affect_pos);
information_pool.operation.Reschedule_operations = remaining_operation;
information_pool.operation.Reschedule_integerschemes = [tempDecode(11,direct_effect_pos),tempDecode(11,indirect_affect_pos)];
for i = 1:length(information_pool.operation.Reschedule_integerschemes)
    index = find(reschedule_individual.Code(5,:) == information_pool.operation.Reschedule_integerschemes(i),1);
    information_pool.operation.Reschedule_globalindex(i) = index;
end
%% Update machine information
information_pool.machine.Reschedule_available = cell(1,length(information_pool.operation.Reschedule_integerschemes));
information_pool.machine.Reschedule_processtime = cell(1,length(information_pool.operation.Reschedule_integerschemes));
for i = 1:length(information_pool.operation.Reschedule_integerschemes)
    integerschemes = information_pool.operation.Reschedule_integerschemes(i);
    p = mod(integerschemes,100); 
    q = (integerschemes-p)/100; 
    machine = Parameter.AvalueMachine{q,p};
    processtime = Parameter.ProcessTime{q,p};
    information_pool.machine.Reschedule_available{1,i} = machine;
    information_pool.machine.Reschedule_processtime{1,i} = processtime;
end    
%% Determine machine release time，

information_pool.machine.Reschedule_release = zeros(1,Parameter.MaxMachineNum);
for m = 1:Parameter.MaxMachineNum

    if m == breakdown_machine
        m_index = tempDecode(2,:) == m;
        m_infor = tempDecode(9:10,m_index);
        m_pos = [m_infor(2,:)>breakdown_time;m_infor(1,:)<breakdown_time];
        m_pos = m_pos(1,:)==m_pos(2,:);
        information_pool.machine.Reschedule_release(m) = m_infor(2,m_pos)+repair_time;
    else
        m_index = tempDecode(2,:) == m;
        if all(m_index==0)
            information_pool.machine.Reschedule_release(m) = breakdown_time;
        else
            m_infor = tempDecode(9:10,m_index);
            m_pos = [m_infor(2,:)>breakdown_time;m_infor(1,:)<breakdown_time];
            m_pos = m_pos(1,:)==m_pos(2,:);
            if all(m_pos==0) 
                information_pool.machine.Reschedule_release(m) = breakdown_time;
            else 
                information_pool.machine.Reschedule_release(m) = m_infor(2,m_pos);
            end
        end
    end
end
%% Fixing the operation rescheduling sequence
for i = 1:length(direct_effect_pos)
    if ~direct_effect_pos(i)
        continue;
    else
        index = information_pool.operation.Reschedule_integerschemes == tempDecode(11,i);
        information_pool.operation.Reschedule_integerschemes(index) = [];
        information_pool.operation.Reschedule_globalindex(index) = [];
        information_pool.machine.Reschedule_available(index) = [];
        information_pool.machine.Reschedule_processtime(index) = [];
    end
end
information_pool.operation.Reschedule_operations = length(information_pool.operation.Reschedule_integerschemes);

% At this point, the remaining rescheduling operation information has been corrected, but the available start time ( i.e., release time) for the part is still missing.

%% Determine the location and availability of the AGV.
information_pool.AGV.rate = zeros(1,Parameter.AGVNum);
information_pool.AGV.rate_index = zeros(1,Parameter.AGVNum);
information_pool.AGV.position = zeros(1,Parameter.AGVNum);
information_pool.AGV.midposition = zeros(1,Parameter.AGVNum);
information_pool.AGV.nextposition = zeros(1,Parameter.AGVNum);
information_pool.AGV.Reschedule_release = zeros(1,Parameter.AGVNum);
information_pool.AGV.whetherload = zeros(1,Parameter.AGVNum);
for agv = 1:Parameter.AGVNum
    index = tempDecode(3,:)==agv;
    tempAGVinfor = tempDecode(:,index);
    unload = zeros(2,size(tempAGVinfor,2));
    for un = 1:size(tempAGVinfor,2)
        if un == 1
            if tempAGVinfor(4,un) == 0
                unload(1,un) = 0;
                unload(2,un) = 0;
            else
                unload(1,un) = 0;
                unload(2,un) = tempAGVinfor(5,un);
            end
        else
            if tempAGVinfor(4,un) == 0
                unload(1,un) = 0;
                unload(2,un) = 0;
            else
                unload(1,un) = tempAGVinfor(7,un-1);
                unload(2,un) = tempAGVinfor(7,un-1)+ tempAGVinfor(4,un);
            end
        end
    end
    unloading1 = unload(1,:)< breakdown_time;
    unloading2 = unload(2,:)>breakdown_time;
    unloading = [unloading1;unloading2];
    unloading = unloading(1,:)==unloading(2,:);
    load = zeros(2,size(tempAGVinfor,2));
    load(1,:) = tempAGVinfor(5,:);
    load(2,:) = tempAGVinfor(7,:);
    loading1 = load(1,:)< breakdown_time;
    loading2 = load(2,:)> breakdown_time;
    loading = [loading1;loading2];
    loading = loading(1,:)==loading(2,:);

    final = unloading == loading;
    if any(final ~= 1) 
        if any(loading==1) 
            information_pool.AGV.rate(agv) = (breakdown_time-tempAGVinfor(5,loading))/(tempAGVinfor(7,loading)-tempAGVinfor(5,loading)); 
            information_pool.AGV.rate_index(agv) = find(tempDecode(11,:) == tempAGVinfor(11,loading),1);
            if find(tempAGVinfor(11,:)==tempAGVinfor(11,loading),1)-1 == 0
                information_pool.AGV.position(agv) = 0;
            else
                information_pool.AGV.position(agv) =  tempAGVinfor(2,find(tempAGVinfor(11,:)==tempAGVinfor(11,loading),1)-1);
            end
            if isempty(find(tempDecode(11,:) == tempAGVinfor(11,loading)-1,1))
                information_pool.AGV.midposition(agv) =0;
            else
                information_pool.AGV.midposition(agv) = tempDecode(2,find(tempDecode(11,:) == tempAGVinfor(11,loading)-1,1));
            end          
            information_pool.AGV.nextposition(agv) = tempAGVinfor(2,loading); 
            information_pool.AGV.Reschedule_release(agv) = breakdown_time;
            information_pool.AGV.whetherload(agv) = 1;
        else 
            information_pool.AGV.rate(agv) = (breakdown_time-unload(1,unloading))/(unload(2,unloading)-unload(1,unloading));
            information_pool.AGV.rate_index(agv) = find(tempDecode(11,:) == tempAGVinfor(11,unloading),1);
            if find(tempAGVinfor(11,:)==tempAGVinfor(11,unloading),1)-1 ==0
                information_pool.AGV.position(agv) = 0;
            else
                information_pool.AGV.position(agv) = tempAGVinfor(2,find(tempAGVinfor(11,:)==tempAGVinfor(11,unloading),1)-1);
            end
            if isempty(find(tempDecode(11,:) == tempAGVinfor(11,unloading)-1,1))
                information_pool.AGV.midposition(agv) =0;
            else
                information_pool.AGV.midposition(agv) = tempDecode(2,find(tempDecode(11,:) == tempAGVinfor(11,unloading)-1,1));
            end  
            information_pool.AGV.nextposition(agv) = tempAGVinfor(2,unloading);
            information_pool.AGV.Reschedule_release(agv)  = breakdown_time;
        end
    else
        idel = load(1,:)>breakdown_time;
        pos = find(idel == 1,1);
        if isempty(pos)
            machine = tempAGVinfor(2,end);
            information_pool.AGV.rate(agv) = inf;
            information_pool.AGV.rate_index(agv) = inf;
            information_pool.AGV.position(agv) = machine;
            information_pool.AGV.midposition(agv) = inf;
            information_pool.AGV.nextposition(agv) = inf;
            information_pool.AGV.Reschedule_release(agv) = breakdown_time;
        else
        information_pool.AGV.rate(agv) = 0;
        information_pool.AGV.rate_index(agv) = 0;
        information_pool.AGV.position(agv) = tempAGVinfor(2,pos-1);
        if isempty(find(tempDecode(11,:) == tempAGVinfor(11,pos)-1,1))
            information_pool.AGV.midposition(agv) = 0;
        else
            information_pool.AGV.midposition(agv) = tempDecode(2,find(tempDecode(11,:) == tempAGVinfor(11,pos)-1,1));
        end
        information_pool.AGV.nextposition(agv) = tempAGVinfor(2,pos);
        information_pool.AGV.Reschedule_release(agv) = breakdown_time;
        end
    end
end
%% Combination of AGV position and workpiece position
jobtemp = ones(1,Parameter.MaxJobNum);
information_pool.operation.position = zeros(1,length(information_pool.operation.Reschedule_integerschemes));
information_pool.operation.release = zeros(1,length(information_pool.operation.Reschedule_integerschemes));  
for op = 1:length(information_pool.operation.Reschedule_integerschemes)
    integer = information_pool.operation.Reschedule_integerschemes(op);
    operation = mod(integer,100);
    job = (integer-operation)/100;
    if jobtemp(job)==1
        index = find(tempDecode(11,:) == integer);
        if ismember(index,information_pool.AGV.rate_index) 
            index2 = find(information_pool.AGV.rate_index == index,1);
            if information_pool.AGV.whetherload(index2) == 1 
                information_pool.operation.position(op) = index2; 
                information_pool.operation.release(op) = breakdown_time;
            else
                information_pool.operation.position(op) = inf;
                if operation == 1
                    information_pool.operation.release(op) = breakdown_time;
                else
                    index3 = find(tempDecode(11,:) == (integer-1),1); 
                    if tempDecode(2,index3) == breakdown_machine
                        information_pool.operation.release(op) = tempDecode(10,index3)+repair_time;
                        if information_pool.machine.Reschedule_release(breakdown_machine) < information_pool.operation.release(op)
                            information_pool.machine.Reschedule_release(breakdown_machine) = information_pool.operation.release(op);
                        end
                    else
                        if tempDecode(10,index3) > breakdown_time
                            information_pool.operation.release(op) = tempDecode(10,index3);
                        else
                            information_pool.operation.release(op) = breakdown_time;
                        end
                    end
                end
            end
        else
            information_pool.operation.position(op) = inf; 
            if operation == 1 
                information_pool.operation.release(op) = breakdown_time;
            else
                index3 = find(tempDecode(11,:) == (integer-1),1); 
                if tempDecode(2,index3) == breakdown_machine
                    information_pool.operation.release(op) = tempDecode(10,index3)+repair_time;
                    if information_pool.machine.Reschedule_release(breakdown_machine) < information_pool.operation.release(op)
                        information_pool.machine.Reschedule_release(breakdown_machine) = information_pool.operation.release(op);
                    end
                else
                    if tempDecode(10,index3) > breakdown_time
                        information_pool.operation.release(op) = tempDecode(10,index3);
                    else
                        information_pool.operation.release(op) = breakdown_time;
                    end
                end
            end
        end
        jobtemp(job) = 0; 
    else
        information_pool.operation.position(op) = inf;
        information_pool.operation.release(op) = inf;
    end
end
end








































