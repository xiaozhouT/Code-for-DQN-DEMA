function [] = Gantt(Parameter,PF_S)
color = [1,0.94118,0.96078;0.94118,1,0.94118;1,0.98039,0.80392;1,0.87059,0.67843;...
   0.6902,0.87843,0.90196;0.59608,0.98431,0.59608;1,0.62745,0.47843;0.60392,0.75294,0.80392;...
    0.93333,0.91373,0.74902;0.51373,0.43529,1];
% color = hsv(64);

MST = cat(1,PF_S(1).F1Decode(9,:),PF_S(1).F1Decode(10,:));
M = PF_S(1).F1Decode(2,:);
Atotal = cat(1,PF_S(1).F1Decode(3,:),PF_S(1).F1Decode(4,:),PF_S(1).F1Decode(5,:),PF_S(1).F1Decode(7,:));

subplot(2,1,1)
x = sort(randperm(Parameter.MaxJobNum));
for i = 1:size(PF_S(1).F1Decode,2)
    rec(1) = MST(1,i); 
    rec(2) = M(1,i)-0.5; 
    rec(3) = MST(2,i) - MST(1,i); 
    rec(4) = 1; 
    temp2 = PF_S(1).F1Decode(11,i);
    a = (mod(temp2,100));
    b = ((temp2 - a)/100);
    temp2 = x==b;
    biaozhu = 'O%d0%d';
    txt = sprintf(biaozhu,b,a);
    rectangle('position',rec,'linewidth',0.5,'linestyle','-','facecolor',color(temp2,:));
    set(gca,'xlim',[0,40],'fontsize',15);
    set(gca,'ylim',[0,Parameter.MaxMachineNum+1],'fontsize',15);
    set(gca,'xtick',0:5:(max(MST(2,:))+10));
    set(gca,'ytick',0:(Parameter.MaxMachineNum+10));
    set(gca,'LooseInset',get(gca,'TightInset'));
    text(rec(1)+0.1,rec(2)+0.5,txt,'fontsize',10,'FontName','Times New Roman');
    ylabel('Machine','FontSize',18);
    xlabel('Makespan','FontSize',18);
    title('Factory1-Gantt-chart','FontSize',18);
    set(gca,'FontName','Times New Roman','FontWeight','normal')
    grid on;
end
subplot(2,1,2)
x = sort(randperm(Parameter.MaxJobNum));
for  i = 1:size(PF_S(1).F1Decode,2)
    if Atotal(1,i) ~=0
        rec(1) = Atotal(3,i); 
        rec(2) = Atotal(1,i)-0.5; 
        rec(3) = Atotal(4,i)-Atotal(3,i); 
        rec(4) = 1;
        temp2 = PF_S(1).F1Decode(11,i);
        a = (mod(temp2,100));
        b = ((temp2 - a)/100);
        temp2 = x==b;
        if a == 1
            biaozhu = 'O%d0%d,%s%s%s%d';
            arrow = '��';
            txt = sprintf(biaozhu,b,a,'C',arrow,'M',M(1,i));
        else
            previous_index = find_previous_index(PF_S(1).F1Decode(1,:), i);
            biaozhu = 'O%d0%d,%s%d%s%s%d';
            arrow = '��';
            txt = sprintf(biaozhu,b,a,'M',M(1,previous_index),arrow,'M',M(1,i));
        end
        rectangle('position',rec,'linewidth',0.5,'linestyle','-','facecolor',color(temp2,:));
        set(gca,'xlim',[0,40],'fontsize',15);
        set(gca,'ylim',[0,Parameter.MaxMachineNum+1],'fontsize',15);
        set(gca,'xtick',0:5:(max(MST(2,:))+10));
        set(gca,'ytick',0:(Parameter.MaxMachineNum+10));
        set(gca,'LooseInset',get(gca,'TightInset'));
        text(rec(1)+0.1,rec(2)+0.5,txt,'fontsize',10,'FontName','Times New Roman');
        ylabel('AGV','FontSize',18);
        xlabel('Makespan','FontSize',18);
        title('AGV-chart','FontSize',18);
        set(gca,'FontName','Times New Roman','FontWeight','normal')
        grid on;
    else
        continue
    end
end
hold on
for  i = 1:size(PF_S(1).F1Decode,2)
    if Atotal(2,i) ~=0 
        previous_index = find_previous_index(Atotal(1,:), i);
        if previous_index == -1 
            rec(1) = 0;
            rec(2) = Atotal(1,i)-0.5;
            rec(3) = Atotal(2,i);
            rec(4) = 1;            
        else 
            rec(1) = Atotal(4,previous_index); % ��ʼ
            rec(2) = Atotal(1,previous_index)-0.5;
            rec(3) = Atotal(2,i);
            rec(4) = 1;
        end
        temp2 = PF_S(1).F1Decode(11,i);
        a = (mod(temp2,100));
        b = ((temp2 - a)/100);
        temp2 = x==b;
        if a == 1 
            previous_index = find_previous_index(Atotal(1,:), i);
            prem = M(1,previous_index);
            biaozhu = '%s%d%s%s';
            arrow = '��';
            txt1 = sprintf(biaozhu,'M',prem,arrow,'C');
        else
            previous_index = find_previous_index(Atotal(1,:), i);
            if previous_index == -1 
                previous_index = find_previous_index(PF_S(1).F1Decode(1,:), i);
                biaozhu = '%s%s%s%d';
                arrow = '��';
                txt1 = sprintf(biaozhu,'C',arrow,'M',M(1,previous_index));
            else 
                previous_index2 = find_previous_index(PF_S(1).F1Decode(1,:), i);
                prem = M(1,previous_index);
                biaozhu = '%s%d%s%s%d';
                arrow = '��';
                txt1 = sprintf(biaozhu,'M',prem,arrow,'M',M(1,previous_index2));
            end
        end
        rectangle('position',rec,'linewidth',0.5,'linestyle','--');
        text(rec(1)+0.1,rec(2)+0.5,txt1,'fontsize',10,'FontName','Times New Roman');
    else
        continue
    end
end
hold off
end

function previous_index = find_previous_index(arr, current_index)
    current_value = arr(current_index);
    for j = current_index - 1:-1:1
        if arr(j) == current_value
            previous_index = j;
            return;
        end
    end
    previous_index = -1;
end