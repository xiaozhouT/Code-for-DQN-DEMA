function [reschedule_individual1,reschedule_individual2,reschedule_individual3] = reInitialPop(reschedule_individual,information_pool,Parameter)

reschedule_individual1 = reschedule_individual;
reschedule_individual2 = reschedule_individual;
reschedule_individual3 = reschedule_individual;

if size(information_pool,1) == 1  
    machine1 = zeros(1,information_pool(1).operation.Reschedule_operations);
    machine2 = zeros(1,information_pool(1).operation.Reschedule_operations);
    machine3 = zeros(1,information_pool(1).operation.Reschedule_operations);
    for i = 1:information_pool(1).operation.Reschedule_operations
        
        Power = Parameter.MLP(information_pool(1).machine.Reschedule_available{i}) .* information_pool(1).machine.Reschedule_processtime{i};
        [~,index1] = min(Power);
        machine1(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index1);

        PTime = information_pool(1).machine.Reschedule_processtime{i};
        [~,index2] = min(PTime);
        machine2(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index2);
        
        machinetemp = information_pool(1).machine.Reschedule_available{i};
        index3 = randi(size(machinetemp,2));
        machine3(1,i) = information_pool(1).machine.Reschedule_available{i}(1,index3);
    end
    for i = 1:information_pool(1).operation.Reschedule_operations
        integer = information_pool(1).operation.Reschedule_integerschemes(i);
        operation = mod(integer,100);
        job = (integer-operation)/100;
        m1 = machine1(1,i);
        m2 = machine2(1,i);
        m3 = machine3(1,i);
        if job == 1
            reschedule_individual1.Code(3,operation) = m1;
            reschedule_individual2.Code(3,operation) = m2;
            reschedule_individual3.Code(3,operation) = m3;
        else
            reschedule_individual1.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m1;
            reschedule_individual2.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m2;
            reschedule_individual3.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m3;
        end
    end
else
    if f == 1
        machine1 = zeros(1,information_pool(f).operation.Reschedule_operations);
        machine2 = zeros(1,information_pool(f).operation.Reschedule_operations);
        machine3 = zeros(1,information_pool(f).operation.Reschedule_operations);
        for i = 1:information_pool(f).operation.Reschedule_operations
            Power = Parameter.MLP(information_pool(f).machine.Reschedule_available{i}) .* information_pool(f).machine.Reschedule_processtime{i};
            [~,index] = min(Power);
            machine1(1,i) = information_pool(f).machine.Reschedule_available{i}(1,index);
            PTime = information_pool(f).machine.Reschedule_processtime{i};
            [~,index2] = min(PTime);
            machine2(1,i) = information_pool(f).machine.Reschedule_available{i}(1,index2);
            machinetemp = information_pool(f).machine.Reschedule_available{i};
            index3 = randi(size(machinetemp,2));
            machine3(1,i) = information_pool(f).machine.Reschedule_available{i}(1,index3);
        end
        for i = 1:information_pool(1).operation.Reschedule_operations
            integer = information_pool(1).operation.Reschedule_integerschemes(i);
            operation = mod(integer,100);
            job = (integer-operation)/100;
            m1 = machine1(1,i);
            m2 = machine2(1,i);
            m3 = machine3(1,i);
            if job == 1
                reschedule_individual1.Code(3,operation) = m1;
                reschedule_individual2.Code(3,operation) = m2;
                reschedule_individual3.Code(3,operation) = m3;
            else
                reschedule_individual1.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m1;
                reschedule_individual2.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m2;
                reschedule_individual3.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m3;
            end
        end
    else
        machine1 = zeros(1,information_pool(f).operation.Reschedule_operations);
        machine2 = zeros(1,information_pool(f).operation.Reschedule_operations);
        machine3 = zeros(1,information_pool(f).operation.Reschedule_operations);
        for i = 1:information_pool(f).operation.Reschedule_operations
            Power = Parameter.MLP(information_pool(f).machine.Reschedule_available{i}) .* information_pool(f).machine.Reschedule_processtime{i};
            [~,index] = min(Power);
            machine1(1,i) = information_pool(f).machine.Reschedule_available{i}(1,index);
            PTime = information_pool(f).machine.Reschedule_processtime{i};
            [~,index2] = min(PTime);
            machine2(1,i) = information_pool(f).machine.Reschedule_available{i}(1,index2);
            machinetemp = information_pool(f).machine.Reschedule_available{i};
            index3 = randi(size(machinetemp,2));
            machine3(1,i) = information_pool(f).machine.Reschedule_available{i}(1,index3);
        end
        for i = 1:information_pool(1).operation.Reschedule_operations
            integer = information_pool(1).operation.Reschedule_integerschemes(i);
            operation = mod(integer,100);
            job = (integer-operation)/100;
            m1 = machine1(1,i);
            m2 = machine2(1,i);
            m3 = machine3(1,i);
            if job == 1
                reschedule_individual1.Code(3,operation) = m1;
                reschedule_individual2.Code(3,operation) = m2;
                reschedule_individual3.Code(3,operation) = m3;
            else
                reschedule_individual1.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m1;
                reschedule_individual2.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m2;
                reschedule_individual3.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation) = m3;
            end
        end
    end
end
end