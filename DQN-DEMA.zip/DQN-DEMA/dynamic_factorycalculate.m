function reschedule_individual =  dynamic_factorycalculate(Parameter,reschedule_individual,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time)
for i = 1:size(reschedule_individual,1)
    reindividual = reschedule_individual(i);
    if size(information_pool,1)
        f = 1;
        if breakdown_fac == 1
            tempInfor = reschedule_individual(i).F1Infor;
            temp = nnz(tempInfor(5,:));
            tempDecode = reschedule_individual(i).F1Decode;
            [~,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = dynamic_calculate(Parameter,reindividual,tempInfor,temp,tempDecode,information_pool,f,breakdown_time,breakdown_machine,repair_time);
            reschedule_individual(i).F1JobCmax = JobCmax;
            reschedule_individual(i).F1MachineCmax = MachineCmax;
            reschedule_individual(i).F1AGV = AGVInfor;
            reschedule_individual(i).F1Decode = Decode;
            reschedule_individual(i).F1AGVextralT = AGVextralT;
        else
            tempInfor = reschedule_individual(i).F2Infor;
            temp = nnz(tempInfor(5,:));
            tempDecode = reschedule_individual(i).F2Decode;
            [~,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = dynamic_calculate(Parameter,reindividual,tempInfor,temp,tempDecode,information_pool,f,breakdown_time,breakdown_machine,repair_time);
            reschedule_individual(i).F2JobCmax = JobCmax;
            reschedule_individual(i).F2MachineCmax = MachineCmax;
            reschedule_individual(i).F2AGV = AGVInfor;
            reschedule_individual(i).F2Decode = Decode;
            reschedule_individual(i).F2AGVextralT = AGVextralT;
        end
    else
        for f = 1:Parameter.FactoryNum
            if f == 1
                tempInfor = reschedule_individual(i).F1Infor;
                temp = nnz(tempInfor(5,:));
                tempDecode = reschedule_individual(i).F1Decode;
                [~,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = dynamic_calculate(Parameter,reindividual,tempInfor,temp,tempDecode,information_pool,f,breakdown_time,breakdown_machine,repair_time);
                reschedule_individual(i).F1JobCmax = JobCmax;
                reschedule_individual(i).F1MachineCmax = MachineCmax;
                reschedule_individual(i).F1AGV = AGVInfor;
                reschedule_individual(i).F1Decode = Decode;
                reschedule_individual(i).F1AGVextralT = AGVextralT;
            else
                tempInfor = reschedule_individual(i).F2Infor;
                temp = nnz(tempInfor(5,:));
                tempDecode = reschedule_individual(i).F2Decode;
                [~,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = dynamic_calculate(Parameter,reindividual,tempInfor,temp,tempDecode,information_pool,f,breakdown_time,breakdown_machine,repair_time);
                reschedule_individual(i).F2JobCmax = JobCmax;
                reschedule_individual(i).F2MachineCmax = MachineCmax;
                reschedule_individual(i).F2AGV = AGVInfor;
                reschedule_individual(i).F2Decode = Decode;
                reschedule_individual(i).F2AGVextralT = AGVextralT;
            end
        end
    end
end
end


function [reschedule_individual,Decode,JobCmax,MachineCmax,AGVInfor,AGVextralT] = dynamic_calculate(Parameter,reschedule_individual,tempInfor,temp,tempDecode,information_pool,f,breakdown_time,breakdown_machine,repair_time)
Decode = zeros(11,temp);
temp2 = temp-information_pool(f).operation.Reschedule_operations;
[~, loc_index] = ismember(information_pool(f).operation.Reschedule_integerschemes, tempDecode(11,:));
tempDecode(:,loc_index) = [];
Decode(:,1:temp2) = tempDecode;
for k = 1:Parameter.MaxMachineNum
    if information_pool(f).machine.Reschedule_release(k) > breakdown_time && k == breakdown_machine
        index = Decode(2,:) == k;
        temptt = Decode(:,index);
        temptt(10,end) = temptt(10,end)+repair_time;
        Decode(:,index) = temptt;
    else
        continue
    end
end
JobCmax = zeros(1,Parameter.MaxJobNum);
MachineCmax = information_pool(f).machine.Reschedule_release;  
for i = 1:Parameter.MaxJobNum
    if ~ismember(i,Decode(1,:))
        continue
    else
        index = Decode(1,:) == i;
        temp = Decode(:,index);
        if temp(10,end) <= breakdown_time
            JobCmax(i) = breakdown_time;
        else
            JobCmax(i) = temp(10,end);
        end
    end
end

AGVInfor = zeros(2,Parameter.AGVNum);
AGVextralT = zeros(2,Parameter.AGVNum);
if size(information_pool,1) == 1
    A = size(Decode,2)-information_pool(f).operation.Reschedule_operations;
    AA = size(tempInfor,2)-information_pool(f).operation.Reschedule_operations+1:1:size(tempInfor,2);
else
    if f == 1
        A = size(Decode,2)-information_pool(f).operation.Reschedule_operations;
        AA = size(tempInfor,2) - information_pool(1).operation.Reschedule_operations-information_pool(2).operation.Reschedule_operations+1:size(tempInfor,2)-information_pool(2).operation.Reschedule_operations;
    else
        A = size(Decode,2)-information_pool(f).operation.Reschedule_operations;
        AA = size(tempInfor,2)-information_pool(2).operation.Reschedule_operations+1:size(tempInfor,2);
    end
end

for k = 1:size(AA,2)
    bufenpei = false;
    xiuzheng = false;
    integer = tempInfor(5,AA(k));
    operation = mod(integer,100);
    job = (integer-operation)/100;
    if job == 1
        m = reschedule_individual.Code(3,operation); 
        TAGV = reschedule_individual.Code(4,operation);
        if operation == 1
            op_m = 0; 
        else
            op_m = reschedule_individual.Code(3,operation-1);
        end
    else
        m = reschedule_individual.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation);
        TAGV = reschedule_individual.Code(4,sum(Parameter.JobCOPNum(1:job-1))+operation);
        if operation == 1
            op_m = 0; 
        else
            op_m = reschedule_individual.Code(3,sum(Parameter.JobCOPNum(1:job-1))+operation-1);
        end
    end
    index = information_pool(f).operation.Reschedule_integerschemes == integer;
    AM = information_pool(f).machine.Reschedule_available{index};
    PT = information_pool(f).machine.Reschedule_processtime{index};
    index1 = AM == m;
    TPT = PT(index1); 
    TST = Parameter.SetupTime(job,operation);

    if AGVInfor(2,TAGV) == 0 
        origin_m = information_pool(f).AGV.nextposition(1,TAGV);  
        mid_m = information_pool(f).AGV.midposition(1,TAGV); 
        if information_pool(f).AGV.whetherload(TAGV)  
            if information_pool(f).AGV.position(1,TAGV) == op_m 
                car_no_load_t = 0;
            else
                car_no_load_t =  Parameter.AGVTime(information_pool(f).AGV.position(1,TAGV)+1, op_m+1)/60; 
            end
            if op_m == m 
                car_load_t = 2*information_pool(f).AGV.rate(1,TAGV)*Parameter.AGVTime(op_m+1,origin_m+1)/60; 
            else
                if m == origin_m
                    car_load_t = Parameter.AGVTime(op_m+1,m+1)/60; 
                else
                    a = Parameter.AGVTime(op_m+1,origin_m+1)/60;
                    b = Parameter.AGVTime(op_m+1,m+1)/60;
                    c = Parameter.AGVTime(origin_m+1,m+1)/60;
                    theta_rad = acos((a^2+b^2-c^2)/(2*a*b));
                    a = information_pool(f).AGV.rate(1,TAGV)*a;
                    car_load_t = a + sqrt(a^2+b^2-2*a*b*cos(theta_rad));
                end
            end
        else
            
            if information_pool(f).AGV.rate(1,TAGV) ~= inf && information_pool(f).AGV.rate(1,TAGV) ~= 0
                if op_m == m
                    bufenpei = true;
                    indexx = find(Decode(11,:) == (integer-1),1);
                    car_load_t = 0;
                else
                    car_load_t = Parameter.AGVTime(op_m+1,m+1)/60;
                end
                if information_pool(f).AGV.position(1,TAGV) == op_m 
                    car_no_load_t = 2*information_pool(f).AGV.rate(1,TAGV)*Parameter.AGVTime(information_pool(f).AGV.position(1,TAGV)+1,mid_m+1)/60;
                else
                    if op_m == mid_m
                        car_no_load_t = Parameter.AGVTime(information_pool(f).AGV.position(1,TAGV)+1,mid_m+1)/60;
                    else
                        a = Parameter.AGVTime(information_pool(f).AGV.position(1,TAGV)+1,mid_m+1)/60;
                        b = Parameter.AGVTime(information_pool(f).AGV.position(1,TAGV)+1,op_m+1)/60;
                        c = Parameter.AGVTime(mid_m+1,op_m+1)/60;
                        theta_rad = acos((a^2+b^2-c^2)/(2*a*b));
                        a = information_pool(f).AGV.rate(1,TAGV)*a;
                        car_no_load_t = a + sqrt(a^2+b^2-2*a*b*cos(theta_rad));
                    end
                end
            else 
                if information_pool(f).AGV.position(1,TAGV) == op_m 
                    car_no_load_t = 0;
                else
                    car_no_load_t =  Parameter.AGVTime(information_pool(f).AGV.position(1,TAGV)+1, op_m+1)/60; 
                end
                if op_m == m
                    bufenpei = true;
                    indexx = find(Decode(11,:) == (integer-1),1);
                    car_load_t = 0;
                else
                    car_load_t = Parameter.AGVTime(op_m+1,m+1)/60;
                end
            end
        end
    else
        position = AGVInfor(2,TAGV);
        if op_m == m 
            bufenpei = true;
            indexx = find(Decode(11,:) == (integer-1),1);
            car_no_load_t = 0;
            car_load_t = 0;
        else
            car_no_load_t =  Parameter.AGVTime(position+1, op_m+1)/60;
            car_load_t = Parameter.AGVTime(op_m+1,m+1)/60;
        end
    end

    if bufenpei 
        if ~isempty(indexx) 
            yizhixing_index = Decode(2,:) == m;
            yizhixing = Decode(:,yizhixing_index);
            if all(yizhixing_index==0)
                xiuzheng = false;
            else
                if yizhixing(11,end) == integer-1
                    xiuzheng = true;
                    Decode(10,indexx) = Decode(10,indexx)-Decode(8,indexx);
                    MachineCmax(1,m) = Decode(10,indexx);
                    JobCmax(1,job) = Decode(10,indexx);
                else
                    xiuzheng = false;
                end
            end
        end
        if AGVInfor(2,TAGV) == 0
            if information_pool(f).AGV.rate(1,TAGV) ~= inf && information_pool(f).AGV.rate(1,TAGV) ~= 0
                agv_index = Decode(3,:) == TAGV;
                agv = Decode(:,agv_index);
                AGVStart = 0; 
                if all(agv_index==0)
                    AGVInfor(1,TAGV) = 0+car_no_load_t+car_load_t;
                else
                    AGVInfor(1,TAGV) = agv(7,end)+car_no_load_t+car_load_t;
                end
                AGVInfor(2,TAGV) = m;
                StartT = MachineCmax(1,m);
            else
                AGVStart = 0;
                AGVInfor(1,TAGV) = information_pool(f).AGV.Reschedule_release(1,TAGV)+car_no_load_t+car_load_t;
                AGVInfor(2,TAGV) = m;
                StartT = MachineCmax(1,m);
            end
            TAGV = 0;
        else  
            TAGV = 0;
            AGVStart = 0;
            StartT = MachineCmax(1,m);
        end
    else
        if AGVInfor(2,TAGV) == 0
            if information_pool(f).AGV.whetherload(TAGV) 
                agv_index = Decode(3,:) == TAGV;
                if all(agv_index==0)
                    if car_no_load_t+car_load_t > MachineCmax(1,m)
                        StartT = car_no_load_t+car_load_t;
                    else
                        StartT = MachineCmax(1,m);
                    end
                    AGVStart = 0+car_no_load_t;
                    AGVInfor(1,TAGV) = AGVStart+car_load_t;
                    AGVInfor(2,TAGV) = m;
                else
                    agv = Decode(:,agv_index);
                    if agv(7,end) + car_no_load_t+car_load_t > MachineCmax(1,m)
                        StartT = agv(7,end)+car_no_load_t+car_load_t;
                    else
                        StartT = MachineCmax(1,m);
                    end
                    AGVStart = agv(7,end)+car_no_load_t;
                    AGVInfor(1,TAGV) = AGVStart+car_load_t;
                    AGVInfor(2,TAGV) = m;
                end
            else
                if information_pool(f).AGV.rate(1,TAGV) ~= inf && information_pool(f).AGV.rate(1,TAGV) ~= 0
                    agv_index = Decode(3,:) == TAGV;
                    if all(agv_index==0)
                        if car_no_load_t > JobCmax(1,job)
                            temp1 = 0+car_no_load_t;
                        else
                            temp1 = JobCmax(1,job);
                        end
                    else
                        agv = Decode(:,agv_index);
                        if agv(7,end)+car_no_load_t > JobCmax(1,job)
                            temp1 = agv(7,end)+car_no_load_t;
                        else
                            temp1 = JobCmax(1,job);
                        end
                    end
                    if temp1 + car_load_t > MachineCmax(1,m)
                        StartT = temp1 + car_load_t;
                    else
                        StartT = MachineCmax(1,m);
                    end
                    AGVStart = temp1;
                    AGVInfor(1,TAGV) = AGVStart+car_load_t;
                    AGVInfor(2,TAGV) = m;
                else
                    if information_pool(f).AGV.Reschedule_release(1,TAGV) > JobCmax(1,job)
                        temp1 = information_pool(f).AGV.Reschedule_release(1,TAGV);
                    else
                        temp1 = JobCmax(1,job);
                    end
                    if temp1 + car_load_t > MachineCmax(1,m)
                        StartT = temp1 + car_load_t;
                    else
                        StartT = MachineCmax(1,m);
                    end
                    AGVStart = temp1;
                    AGVInfor(1,TAGV) = AGVStart+car_load_t;
                    AGVInfor(2,TAGV) = m;
                end
            end
        else
            if AGVInfor(1,TAGV) + car_no_load_t > JobCmax(1,job)
                temp1 = AGVInfor(1,TAGV) + car_no_load_t;
            else
                temp1 = JobCmax(1,job);
            end
            if temp1 + car_load_t > MachineCmax(1,m)
                StartT = temp1 + car_load_t;
            else
                StartT = MachineCmax(1,m);
            end
            AGVStart = temp1;
            AGVInfor(1,TAGV) = AGVStart+car_load_t;
            AGVInfor(2,TAGV) = m;
        end
    end

    Decode(1,A+k) = job;
    Decode(2,A+k) = m;
    Decode(3,A+k) = TAGV;
    Decode(4,A+k) = car_no_load_t;
    Decode(5,A+k) = AGVStart; 
    Decode(6,A+k) = car_load_t;
    Decode(7,A+k) = AGVStart + car_load_t; 
    Decode(8,A+k) = TST;
    Decode(9,A+k) = StartT;
    if xiuzheng
        Decode(10,A+k) = StartT+TPT+TST;
    else
        Decode(10,A+k) = StartT+TST+TPT+TST;    
    end
    Decode(11,A+k) = integer;
    MachineCmax(1,m) = Decode(10,A+k); 
    JobCmax(1,job) = Decode(10,A+k);
    if any(isnan(Decode(:,A+k)) ~= 0)
        Decode(isnan(Decode(:,A+k)),A+k) = 0;
    end
end

%% At this point, the machining phase of the workpiece has been completed.
for q = 1:Parameter.MaxJobNum
    temp = find(Decode(1,:)==q);
    if isempty(temp)
        continue;
    end
    finaMachine = Decode(2,temp(end));
    car_no_load_retrieval = zeros(1,Parameter.AGVNum);
    for x = 1:Parameter.AGVNum
        current_position_of_car = AGVInfor(2,x) + 1;
        car_no_load_retrieval(1,x) = AGVInfor(1,x) + Parameter.AGVTime(current_position_of_car,finaMachine+1)/60;
    end
    if min(car_no_load_retrieval) >= JobCmax(1,q)
        carnum = find(car_no_load_retrieval == min(car_no_load_retrieval),1); 
        carposition = AGVInfor(2,carnum);
        car_no_load_t = Parameter.AGVTime(carposition+1,finaMachine+1)/60;
        car_load_t = Parameter.AGVTime(finaMachine+1,end)/60;
        AGVextralT(1,carnum) =  AGVextralT(1,carnum)+car_no_load_t; 
        AGVextralT(2,carnum) =  AGVextralT(2,carnum)+car_load_t;
        AGVInfor(1,carnum) = AGVInfor(1,carnum) + car_no_load_t + car_load_t;
        AGVInfor(2,carnum) = size(Parameter.AGVTime,2)-1;
        JobCmax(q) =  AGVInfor(1,carnum) + car_no_load_t + car_load_t;
    else
        car_no_load_retrieval_temp = JobCmax(1,q) - car_no_load_retrieval; 
        tmp = car_no_load_retrieval_temp > 0; 
        carnum = find(car_no_load_retrieval_temp == max(car_no_load_retrieval_temp(tmp)),1); 
        carposition = AGVInfor(2,carnum);
        car_no_load_t = Parameter.AGVTime(carposition+1,finaMachine+1)/60; 
        car_load_t = Parameter.AGVTime(finaMachine+1,end)/60;
        AGVextralT(1,carnum) =  AGVextralT(1,carnum)+car_no_load_t; 
        AGVextralT(2,carnum) =  AGVextralT(2,carnum)+car_load_t;
        AGVInfor(1,carnum) = AGVInfor(1,carnum) + car_no_load_t + car_load_t;
        AGVInfor(2,carnum) = size(Parameter.AGVTime,2)-1;
        JobCmax(q) =  JobCmax(1,q) + car_load_t;
    end
end
for n = 1:Parameter.AGVNum
    carposition2 = AGVInfor(2,n); 
    car_no_load_t = Parameter.AGVTime(carposition2+1,0+1)/60;
    car_load_t = 0;

    AGVextralT(1,n) =  AGVextralT(1,n)+car_no_load_t; 
    AGVextralT(2,n) =  AGVextralT(2,n)+car_load_t; 
    AGVInfor(1,n) = AGVInfor(1,n) + car_no_load_t + car_load_t;
    AGVInfor(2,n) = 0; 
end
end













