function IndividualsLS = L2(i,Parameter,ItEliteIndividual)
IndividualsLS = ItEliteIndividual(i); 
IndividualsLS = criticalbottleneck(IndividualsLS,Parameter); 
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = IndividualsLS.Code(1,j);
    temp(val) = temp(val)+1;
    IndividualsLS.Code(5,j) = val*100+temp(val);
end
IndividualsLS = fitness(IndividualsLS,Parameter); 
end

function IndividualsLS = criticalbottleneck(IndividualsLS,Parameter)
for fac = 1:Parameter.FactoryNum
    if fac == 1
        tempDecode = IndividualsLS.F1Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F1CriticalPath;
            IndividualsLS = Executecriticalbottleneck(IndividualsLS,tempDecode,tempCriticalPath,Parameter);
        end
    else
        tempDecode = IndividualsLS.F2Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F2CriticalPath;
            IndividualsLS = Executecriticalbottleneck(IndividualsLS,tempDecode,tempCriticalPath,Parameter);
        end
    end
end
end

function IndividualsLS = Executecriticalbottleneck(IndividualsLS,tempDecode,tempCriticalPath,Parameter)

Criticalcode = tempDecode(:,tempCriticalPath);
bottleneckindex = find((Criticalcode(10,:) - Criticalcode(9,:)) == max(Criticalcode(10,:) - Criticalcode(9,:)),1);
opo = Criticalcode(11,bottleneckindex);
p = mod(opo,100); 
q = (opo-p)/100 ; 
AM = Parameter.AvalueMachine{q,p};
PT = Parameter.ProcessTime{q,p};
minPT = find(PT == min(PT),1);
M = AM(minPT);

if M ~= Criticalcode(2,bottleneckindex)
    TAM = M;
else
    Engery = zeros(1,length(tempCriticalPath));
    for i = 1:length(tempCriticalPath)
        Engery(i) = (Criticalcode(10,i) - Criticalcode(9,i))*Parameter.MLP(Criticalcode(2,i));
    end
    bottleneckEngery = find(Engery==max(Engery),1);
    opo = Criticalcode(11,bottleneckEngery);
    p = mod(opo,100); 
    q = (opo-p)/100 ; 
    AM = Parameter.AvalueMachine{q,p};
    PT = Parameter.ProcessTime{q,p};
    Power = Parameter.MLP(AM);
    E = PT.*Power;
    minE = find(E == min(E),1);
    TAM = AM(minE);
end
if q == 1
    IndividualsLS.Code(3,p) = TAM;
else
    IndividualsLS.Code(3,sum(Parameter.JobCOPNum(1:q-1))+p) = TAM;
end
end



    


