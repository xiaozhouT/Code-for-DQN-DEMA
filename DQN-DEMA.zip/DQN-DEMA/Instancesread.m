function [Machine_load_power,Machine_unload_power,Job_avalue_machine,Operation_process_time] = Instancesread(M_Test)
Jobs = M_Test(1,1); 
MaxMachine = M_Test(1,2); 
MaxOperation = max(M_Test(2:end-1,1)); 
Job_avalue_machine = cell(Jobs,MaxOperation); 
Operation_process_time = cell(Jobs,MaxOperation); 
Machine_load_power = zeros(1,MaxMachine);
Machine_unload_power = zeros(1,MaxMachine);
Machine_load_power(1:1:MaxMachine) = M_Test(end,1:2:2*MaxMachine);
Machine_unload_power(1:1:MaxMachine) = M_Test(end,2:2:2*MaxMachine);

M_Test_temp = M_Test(2:end-1,2:end); 
for i = 1:Jobs 
    j = 1; 
    for q = 1:MaxOperation 
        if j==size(M_Test,2)
            break;
        end
        temp = M_Test_temp(i,j);
        if temp == 0
            break; 
        else
            Job_avalue_machine_temp = zeros(1,temp);
            Operation_process_time_temp = zeros(1,temp);
            for x = 1:length(Job_avalue_machine_temp)
                Job_avalue_machine_temp(1,x) = M_Test_temp(i,j+1); 
                Operation_process_time_temp(1,x) = M_Test_temp(i,j+2); 
                j = j+2; 
            end
            Job_avalue_machine(i,q) = {Job_avalue_machine_temp}; 
            Operation_process_time(i,q) = {Operation_process_time_temp};
            j = j+1; 
        end
    end
end

        
