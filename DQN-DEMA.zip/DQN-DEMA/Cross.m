function SelPopulation = Cross(Parameter,SelPopulation)
for j = 1:2:Parameter.NP
    p1 = rand;
    if Parameter.Pc > p1
        pos1 = unidrnd(Parameter.NP);
        pos2 = unidrnd(Parameter.NP);
        while pos1 == pos2
            pos1 = unidrnd(Parameter.NP);
            pos2 = unidrnd(Parameter.NP);
        end
        SelPopulation = POX(pos1,pos2,Parameter,SelPopulation);
        SelPopulation = UX(pos1,pos2,Parameter,SelPopulation);
        SelPopulation = FixingEncoding(pos1,pos2,Parameter,SelPopulation);
    else
        continue;
    end
end

function SelPopulation = POX(pos1,pos2,Parameter,SelPopulation)
father1 = SelPopulation(pos1).Code(1,:);
father2 = SelPopulation(pos2).Code(1,:);
child1 = zeros(1,sum(Parameter.JobCOPNum));
child2 = zeros(1,sum(Parameter.JobCOPNum));
operationset = randi(Parameter.MaxJobNum);
operationset1 = randperm(Parameter.MaxJobNum,operationset);
operationset2 = setdiff(1:Parameter.MaxJobNum,operationset1);

e1 = length(operationset1);
for i = 1:e1
    val = operationset1(i);
    index = find(father1 == val);
    for x = 1:length(index)
        child1(index(x)) = father1(index(x));
    end
end
e2 = length(operationset2);
for i = 1:e2
    val = operationset2(i);
    index = find(father2==val);
    for x = 1:length(index)
        child2(index(x)) = father2(index(x));
    end
end

for i = 1:sum(Parameter.JobCOPNum)
    index = find(operationset1==father1(i),1);
    if ~isempty(index)
        index_2 = find(child2==0,1);
        child2(index_2) = father1(i);
        father1(i) = 0;
    end
end
for i = 1:sum(Parameter.JobCOPNum)
    index = find(operationset2==father2(i),1);
    if ~isempty(index)
        index_1 = find(child1==0,1);
        child1(index_1) = father2(i);
        father2(i) = 0;
    end
end
SelPopulation(pos1).Code(1,:) = child1;
SelPopulation(pos2).Code(1,:) = child2;

function SelPopulation = UX(pos1,pos2,Parameter,SelPopulation)
ShieldedWord = randi([0,1],1,sum(Parameter.JobCOPNum));
father1 = SelPopulation(pos1).Code(3,:);
father2 = SelPopulation(pos2).Code(3,:);
child1 = zeros(1,sum(Parameter.JobCOPNum));
child2 = zeros(1,sum(Parameter.JobCOPNum));
for i = 1:sum(Parameter.JobCOPNum)
    val = ShieldedWord(i);
    if val == 0
        child1(i) = father1(i);
        child2(i) = father2(i);
    elseif val == 1
        child1(i) = father2(i);
        child2(i) = father1(i);
    end
end
SelPopulation(pos1).Code(3,:) = child1;
SelPopulation(pos2).Code(3,:) = child2;

function SelPopulation = FixingEncoding(pos1,pos2,Parameter,SelPopulation)
temp1 = zeros(1,Parameter.MaxJobNum);
temp2 = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val1 = SelPopulation(pos1).Code(1,j);
    val2 = SelPopulation(pos2).Code(1,j);
    temp1(val1) = temp1(val1)+1;
    temp2(val2) = temp2(val2)+1;
    SelPopulation(pos1).Code(5,j) = val1*100 + temp1(val1);
    SelPopulation(pos2).Code(5,j) = val2*100 + temp2(val2);
end

    
    
