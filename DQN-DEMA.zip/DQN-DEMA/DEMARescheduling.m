function [rePopulation,rePreschedule_Score,rePreschedule,rePreschedule_PF,reEliteIndividual,reTrace] = DEMARescheduling(Individual,reschedule_individual,information_pool,Parameter,breakdown_fac,breakdown_time,breakdown_machine,repair_time,target_Q_network)
[reschedule_individual1,reschedule_individual2,reschedule_individual3] = reInitialPop(reschedule_individual,information_pool,Parameter);
rePopulation = repmat([reschedule_individual1;reschedule_individual2,reschedule_individual3],Parameter.NP/3,1);
%% DQN-DEMA-RIP
% [reschedule_individual1,reschedule_individual2] = rerandInitialPop(reschedule_individual,information_pool,Parameter);
% rePopulation = repmat([reschedule_individual1;reschedule_individual2],Parameter.NP/2,1);
for i = 1:Parameter.NP
    reschedule_individual = rePopulation(i);
    real_reschedule = extractreal_reschedule(reschedule_individual,information_pool,breakdown_fac);
    reschedule_individual = reschedule_allocateAGV(Parameter,real_reschedule,reschedule_individual,information_pool,breakdown_fac);
    %% DQN-DEMA-RDA 
    % reschedule_individual = reschedule_randAllocateAGV(Parameter,real_reschedule,reschedule_individual,information_pool,breakdown_fac);
    reschedule_individual = dynamic_fitness(reschedule_individual,Parameter,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
    rePopulation(i) = reschedule_individual;
end 

rePopulation = Dominated(rePopulation);
rePopulation = CrowdDistance(rePopulation); 
reEliteIndividual = rePopulation([find([rePopulation.Rank]'==1)]);
reTrace = zeros(Parameter.MaxIt,2); 

learning_rate=0.0001;
bufferSize = 1536;
batch_size = 64;
updateTargetFrequency = 9;
experienceBuffer = cell(bufferSize, 1);
currentBufferSize = 0;

for it = 1:Parameter.MaxIt

    reSelPopulation = repmat(Individual,Parameter.NP,1);
    reSelPopulation = Select(Parameter,rePopulation,reSelPopulation); 
    reSelPopulation = reCross(Parameter,reSelPopulation,information_pool);
    reSelPopulation = reMutation(Parameter,reSelPopulation,information_pool); 
    reSelPopulation = dynamic_adjust(reSelPopulation,Parameter,information_pool); 
    reSelPopulation = dynamic_fitness(reSelPopulation,Parameter,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);

    reMergePopulation = [rePopulation;reSelPopulation];    
    reMergePopulation = Dominated(reMergePopulation); 
    reMergePopulation = CrowdDistance(reMergePopulation); 
    reMergePopulation = TrimPopulation(Parameter,reMergePopulation);
    rePopulation = reMergePopulation;

    reEliteIndex = [reMergePopulation.Rank]'==1; 
    reEliteIndividual =[reEliteIndividual;reMergePopulation(reEliteIndex)]; %#ok<*AGROW>
    reonlyfit = zeros(size(reEliteIndividual,1),2);
    for i = 1:size(reEliteIndividual,1)
        fit = reEliteIndividual(i).Fit;
        reonlyfit(i,:) = fit;
    end
    [reonlyfit,ia] = unique(reonlyfit,'rows');
    reEliteIndividual = reEliteIndividual(ia);

    Ittem = it;
    if Ittem >= Parameter.MaxIt * Parameter.historyIt
        selected_indices = rouletteWheelSelection(reonlyfit,Parameter);
        reEliteIndividual_temp = reEliteIndividual(selected_indices);
        statereEliteIndividual_temp = reEliteIndividual_temp;
        statereEliteIndividual_temp = fitness(statereEliteIndividual_temp,Parameter);
        statereEliteIndividual_temp = findCriticalpath4(Parameter,statereEliteIndividual_temp);
        for xx = 1:size(reEliteIndividual_temp,1)
            reEliteIndividual_temp(xx).F1CriticalPath = statereEliteIndividual_temp(xx).F1CriticalPath;
            reEliteIndividual_temp(xx).F2CriticalPath = statereEliteIndividual_temp(xx).F2CriticalPath;
            reEliteIndividual_temp(xx).F1CriticalBlock = statereEliteIndividual_temp(xx).F1CriticalBlock;
            reEliteIndividual_temp(xx).F2CriticalBlock = statereEliteIndividual_temp(xx).F2CriticalBlock;
        end

        [~,reEliteIndividual,experienceBuffer,currentBufferSize,target_Q_network] = reDQNselectLSO(selected_indices,Parameter,reEliteIndividual_temp,reEliteIndividual,target_Q_network,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time,...
                        experienceBuffer,currentBufferSize,batch_size,learning_rate,updateTargetFrequency);
        %% DEMA-RLS
        % [~,reEliteIndividual] = rerandselectLSO(selected_indices,Parameter,reEliteIndividual_temp,reEliteIndividual,information_pool,breakdown_fac,breakdown_time,breakdown_machine,repair_time);
    end
    reonlyfit = zeros(size(reEliteIndividual,1),2);
    for i = 1:size(reEliteIndividual,1)
        fit = reEliteIndividual(i).Fit;
        reonlyfit(i,:) = fit;
    end
    [~,ia] = unique(reonlyfit,'rows');
    reEliteIndividual = reEliteIndividual(ia);
    reTrace(it,1) = mean(reonlyfit(:,1));
    reTrace(it,2) = mean(reonlyfit(:,2));
end
reonlyfit = zeros(size(reEliteIndividual,1),2);
for i = 1:size(reEliteIndividual,1)
    fit = reEliteIndividual(i).Fit;
    reonlyfit(i,:) = fit;
end
[~,ia] = unique(reonlyfit,'rows');
reEliteIndividual = reEliteIndividual(ia);
reEliteIndividual = Dominated(reEliteIndividual); 
reEliteIndividual = CrowdDistance(reEliteIndividual); 

rePreschedule = reEliteIndividual([reEliteIndividual.Rank]'==1); 
rePreschedule_PF = zeros(size(rePreschedule,1),2);
for i = 1:size(rePreschedule,1)
    fit = rePreschedule(i).Fit;
    rePreschedule_PF (i,:) = fit;
end
rePreschedule_Score = ExperimentalIndicators(rePreschedule_PF, Parameter);
end


