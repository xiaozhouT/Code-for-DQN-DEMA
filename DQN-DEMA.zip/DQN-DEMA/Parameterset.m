function [Parameter] = Parameterset(Setup,Layout,Benchmark)
[Machine_load_power,Machine_unload_power,Job_avalue_machine,Operation_process_time] = Instancesread(Benchmark);
Parameter.FactoryNum = 2;
Parameter.NP = 120; 
Parameter.MaxIt = 400; 
Parameter.Pc = 0.90; 
Parameter.Pm = 0.2; 
Parameter.AGVNum = floor(max(0.3*Benchmark(1,2)+0.5,2));
Parameter.historyIt = 0.3; 
Parameter.AvalueMachine = Job_avalue_machine; 
Parameter.ProcessTime = Operation_process_time; 
Parameter.SetupTime = Setup;
Parameter.MLP = Machine_load_power;
Parameter.MULP = Machine_unload_power;
Parameter.AGVLP = 5;
Parameter.AGVULP = 1;
Parameter.AGVTime = pdist2(Layout,Layout);
Parameter.facTranstime = mean(mean(Parameter.AGVTime));
Parameter.JobCOPNum = Benchmark(2:end-1,1)';
Parameter.MaxJobNum = Benchmark(1,1);
Parameter.MaxMachineNum = Benchmark(1,2); 
Parameter.DynamicT = Benchmark(1,3);
Parameter.RepairT = Benchmark(1,4);
Parameter.EF = 0.6981;
Parameter.PF = 0.25;
Parameter.success = ones(1,4);
Parameter.failures = ones(1,4);
Parameter.reference_point_hv = [1,1];
% Parameter.reference_point_igd




