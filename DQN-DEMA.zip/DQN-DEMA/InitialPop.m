function Population = InitialPop(Population,Parameter,R)

if nargin == 2 
    R = false;
end
if R 
    for i = 1:Parameter.NP
        Population = RGPop(i,Population,Parameter);
    end
else
    for i = 1:Parameter.NP
        Popdivide(1:4) = Parameter.NP/3;
        Pop = cumsum(Popdivide);
        if i <= Pop(1) 
            Population = MinTimePop(i,Population,Parameter);
        elseif i > Pop(1) && i<= Pop(2) 
            Population = MinEnergyC(i,Population,Parameter);
        elseif i > Pop(2) && i<= Pop(3) 
            Population = FLBP(i,Population,Parameter);
        end
    end
end
end

function Population = RGPop(i,Population,Parameter)
JobCOPNum_temp = Parameter.JobCOPNum;
for j = 1:sum(Parameter.JobCOPNum)
    job = unidrnd(Parameter.MaxJobNum);
    while JobCOPNum_temp(job) == 0
        job = unidrnd(Parameter.MaxJobNum);
    end
    Population(i).Code(1,j) = job;
    JobCOPNum_temp(job) = JobCOPNum_temp(job)-1;
end
for q = 1:Parameter.MaxJobNum  
    fac = randi(Parameter.FactoryNum);
    if q == 1
        Population(i).Code(2,1:Parameter.JobCOPNum(q))=fac;
    else
        Population(i).Code(2,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=fac;
    end
end
for q = 1:Parameter.MaxJobNum  
    temp = zeros(1,Parameter.JobCOPNum(q)); 
    for p = 1:Parameter.JobCOPNum(q) 
        AM = Parameter.AvalueMachine{q,p};
        e = length(AM);
        b = AM(unidrnd(e));
        temp(1,p) = b;
    end
    if q == 1
        Population(i).Code(3,1:Parameter.JobCOPNum(q))=temp;
    else
        Population(i).Code(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=temp;
    end
end
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = Population(i).Code(1,j);
    temp(val) = temp(val)+1;
    Population(i).Code(5,j) = val*100+temp(val);
end
end

function Population = MinTimePop(i,Population,Parameter)
JobCOPNum_temp = Parameter.JobCOPNum;
for j = 1:sum(Parameter.JobCOPNum)
    job = unidrnd(Parameter.MaxJobNum);
    while JobCOPNum_temp(job) == 0
        job = unidrnd(Parameter.MaxJobNum);
    end
    Population(i).Code(1,j) = job;
    JobCOPNum_temp(job) = JobCOPNum_temp(job)-1;
end
for q = 1:Parameter.MaxJobNum  
    fac = randi(Parameter.FactoryNum);
    if q == 1
        Population(i).Code(2,1:Parameter.JobCOPNum(q))=fac;
    else
        Population(i).Code(2,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=fac;
    end
end
for q = 1:Parameter.MaxJobNum 
    temp = zeros(1,Parameter.JobCOPNum(q));
    for p = 1:Parameter.JobCOPNum(q) 
        AM = Parameter.AvalueMachine{q,p};
        PT = Parameter.ProcessTime{q,p};
        index = find(PT == min(PT),1);
        b = AM(index);
        temp(1,p) = b;
    end
    if q == 1
        Population(i).Code(3,1:Parameter.JobCOPNum(q))=temp;
    else
        Population(i).Code(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=temp;
    end
end
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = Population(i).Code(1,j);
    temp(val) = temp(val)+1;
    Population(i).Code(5,j) = val*100+temp(val);
end
end

function Population = MinEnergyC(i,Population,Parameter)
JobCOPNum_temp = Parameter.JobCOPNum;
for j = 1:sum(Parameter.JobCOPNum)
    job = unidrnd(Parameter.MaxJobNum);
    while JobCOPNum_temp(job) == 0
        job = unidrnd(Parameter.MaxJobNum);
    end
    Population(i).Code(1,j) = job;
    JobCOPNum_temp(job) = JobCOPNum_temp(job)-1;
end
for q = 1:Parameter.MaxJobNum  
    fac = randi(Parameter.FactoryNum);
    if q == 1
        Population(i).Code(2,1:Parameter.JobCOPNum(q))=fac;
    else
        Population(i).Code(2,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=fac;
    end
end
for q = 1:Parameter.MaxJobNum  
    temp = zeros(1,Parameter.JobCOPNum(q)); 
    for p = 1:Parameter.JobCOPNum(q)
        AM = Parameter.AvalueMachine{q,p};
        PT = Parameter.ProcessTime{q,p};
        Power = Parameter.MLP(AM);
        EnergyC = PT.*Power/60;
        index = find(EnergyC == min(EnergyC),1);
        b = AM(index);
        temp(1,p) = b;
    end
    if q == 1
        Population(i).Code(3,1:Parameter.JobCOPNum(q))=temp;
    else
        Population(i).Code(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=temp;
    end
end
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = Population(i).Code(1,j);
    temp(val) = temp(val)+1;
    Population(i).Code(5,j) = val*100+temp(val);
end
end

function Population = FLBP(i,Population,Parameter)

JobCOPNum_temp = Parameter.JobCOPNum;
for j = 1:sum(Parameter.JobCOPNum)
    job = unidrnd(Parameter.MaxJobNum);
    while JobCOPNum_temp(job) == 0
        job = unidrnd(Parameter.MaxJobNum);
    end
    Population(i).Code(1,j) = job;
    JobCOPNum_temp(job) = JobCOPNum_temp(job)-1;
end

total_f1 = 0;
total_f2 = 0;
shuffled_indices = randperm(Parameter.MaxJobNum);
for g = 1:Parameter.MaxJobNum
    job_index = shuffled_indices(g);
    job_processes = Parameter.JobCOPNum(job_index);
    if total_f1 <= total_f2
        choices = 1;
    else
        choices = 2;
    end
    if total_f1 == total_f2
        choices = [1, 2];
    end
    choice = choices(randi(length(choices)));
    if job_index == 1
        if choice == 1
            Population(i).Code(2,1:Parameter.JobCOPNum(job_index))=choice;
            total_f1 = total_f1+job_processes;
        else
            Population(i).Code(2,1:Parameter.JobCOPNum(job_index))=choice;
            total_f2 = total_f2+job_processes;
        end
    else
        if choice == 1
            Population(i).Code(2,sum(Parameter.JobCOPNum(1:job_index-1))+1:sum(Parameter.JobCOPNum(1:job_index)))=choice;
            total_f1 = total_f1+job_processes;
        else
            Population(i).Code(2,sum(Parameter.JobCOPNum(1:job_index-1))+1:sum(Parameter.JobCOPNum(1:job_index)))=choice;
            total_f2 = total_f2+job_processes;
        end
    end
end
for q = 1:Parameter.MaxJobNum  
    temp = zeros(1,Parameter.JobCOPNum(q)); 
    for p = 1:Parameter.JobCOPNum(q) 
        AM = Parameter.AvalueMachine{q,p};
        e = length(AM);
        b = AM(unidrnd(e));
        temp(1,p) = b;
    end
    if q == 1
        Population(i).Code(3,1:Parameter.JobCOPNum(q))=temp;
    else
        Population(i).Code(3,sum(Parameter.JobCOPNum(1:q-1))+1:sum(Parameter.JobCOPNum(1:q)))=temp;
    end
end
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = Population(i).Code(1,j);
    temp(val) = temp(val)+1;
    Population(i).Code(5,j) = val*100+temp(val);
end
end

    
    
    
        
        
        