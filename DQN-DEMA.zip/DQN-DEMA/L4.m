function IndividualsLS = L4(i,Parameter,ItEliteIndividual)
IndividualsLS = ItEliteIndividual(i);
IndividualsLS = criticaloper(IndividualsLS,Parameter);
temp = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val = IndividualsLS.Code(1,j);
    temp(val) = temp(val)+1;
    IndividualsLS.Code(5,j) = val*100+temp(val);
end

IndividualsLS = fitness(IndividualsLS,Parameter); 
end

function IndividualsLS = criticaloper(IndividualsLS,Parameter)
for fac = 1:Parameter.FactoryNum
    if fac == 1
        tempDecode = IndividualsLS.F1Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F1CriticalPath;
            IndividualsLS = Executecriticaloper(IndividualsLS,tempDecode,tempCriticalPath);
        end
    else
        tempDecode = IndividualsLS.F2Decode;
        if ~isempty(tempDecode)
            tempCriticalPath = IndividualsLS.F2CriticalPath;
            IndividualsLS = Executecriticaloper(IndividualsLS,tempDecode,tempCriticalPath);
        end
    end
end
end

function IndividualsLS = Executecriticaloper(IndividualsLS,tempDecode,tempCriticalPath)

pos = randperm(length(tempCriticalPath));
pos1 = pos(randi(length(tempCriticalPath)));
pos2 = pos(randi(length(tempCriticalPath)));
while pos1 == pos2
    pos2 = pos(randi(length(tempCriticalPath)));
end

opo1 = tempDecode(11,pos1);
opo2 = tempDecode(11,pos2);

opo1index = find(IndividualsLS.Code(5,:)==opo1);
opo2index = find(IndividualsLS.Code(5,:)==opo2);

temp = IndividualsLS.Code(1,opo2index);
IndividualsLS.Code(1,opo2index) = IndividualsLS.Code(1,opo1index);
IndividualsLS.Code(1,opo1index) = temp;
end






