function SelPopulation = Mutation(Parameter,SelPopulation)
for j = 1:3:Parameter.NP
    p1 = rand;
    if Parameter.Pm > p1
        pos1 = unidrnd(Parameter.NP);
        c = randi(2);
        switch c
            case 1
                SelPopulation = SinglePointMutation(pos1,Parameter,SelPopulation);
            case 2
                SelPopulation = ReverseOrderMutation(pos1,Parameter,SelPopulation); 
        end
        SelPopulation = RandomizeMutation(pos1,Parameter,SelPopulation); 
        SelPopulation = FixingEncoding(pos1,Parameter,SelPopulation);
    else
        continue;
    end
end
end

function SelPopulation = SinglePointMutation(pos1,Parameter,SelPopulation)
father = SelPopulation(pos1).Code(1,:);
index1 = unidrnd(sum(Parameter.JobCOPNum));
index2 = unidrnd(sum(Parameter.JobCOPNum));
while index1 == index2
    index1 = unidrnd(sum(Parameter.JobCOPNum));
    index2 = unidrnd(sum(Parameter.JobCOPNum));
end
father(index1) = SelPopulation(pos1).Code(1,index2);
father(index2) = SelPopulation(pos1).Code(1,index1);
SelPopulation(pos1).Code(1,:) = father;
end

function SelPopulation = ReverseOrderMutation(pos1,Parameter,SelPopulation)
    index = randperm(sum(Parameter.JobCOPNum));
    indext = index(randperm(numel(index),2));
    indext = sort(indext);
    SelPopulation(pos1).Code(1,indext(1):indext(2))=fliplr(SelPopulation(pos1).Code(1,indext(1):indext(2)));
end

function SelPopulation = RandomizeMutation(pos1,Parameter,SelPopulation)
index1 = unidrnd(sum(Parameter.JobCOPNum));
val = SelPopulation(pos1).Code(5,index1);
p = mod(val,100);
q = (val - p)/100;
AM = Parameter.AvalueMachine{q,p};

while length(AM) == 1
    index1 = unidrnd(sum(Parameter.JobCOPNum));
    val = SelPopulation(pos1).Code(5,index1);
    p = mod(val,100);
    q = (val - p)/100;
    AM = Parameter.AvalueMachine{q,p};
end

if q == 1
    TAM = SelPopulation(pos1).Code(3,p);
else
    TAM = SelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p);
end

t1 = length(AM);
m = AM(1,randi(t1));
while  m == TAM 
    m = AM(1,randi(t1));
end

if q == 1
    SelPopulation(pos1).Code(3,p) = m;
else
    SelPopulation(pos1).Code(3,sum(Parameter.JobCOPNum(1:q-1))+p) = m;
end
end

function SelPopulation = FixingEncoding(pos1,Parameter,SelPopulation)
temp1 = zeros(1,Parameter.MaxJobNum);
for j = 1:sum(Parameter.JobCOPNum)
    val1 = SelPopulation(pos1).Code(1,j);
    temp1(val1) = temp1(val1)+1;
    SelPopulation(pos1).Code(5,j) = val1*100+temp1(val1);
end
end



