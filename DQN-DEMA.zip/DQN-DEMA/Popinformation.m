function [Individual,Population] = Popinformation(Parameter)
Individual.Code = zeros(5,sum(Parameter.JobCOPNum)); 
Individual.Rank = Inf;
Individual.Cd = 0; 
Individual.Fit = zeros(1,2); 

Individual.F1MUCO2 = 0; 
Individual.F1MLCO2 = 0; 
Individual.F1AGVUCO2 = 0; 
Individual.F1AGVLCO2 = 0; 

Individual.F1JobCmax = zeros(1,Parameter.MaxJobNum); 
Individual.F1MachineCmax = zeros(1,Parameter.MaxMachineNum); 
Individual.F1AGV = zeros(2,Parameter.AGVNum);
Individual.F1Decode = []; 
Individual.F1Infor = [];
Individual.F1AGVextralT = zeros(2,Parameter.AGVNum); 
Individual.F1CriticalPath = [];  
Individual.F1CriticalBlock.B = struct;
Individual.F1CriticalBlock.C = struct;

Individual.F2MUCO2 = 0; 
Individual.F2MLCO2 = 0;
Individual.F2AGVUCO2 = 0; 
Individual.F2AGVLCO2 = 0; 

Individual.F2JobCmax = zeros(1,Parameter.MaxJobNum); 
Individual.F2MachineCmax = zeros(1,Parameter.MaxMachineNum); 
Individual.F2AGV = zeros(2,Parameter.AGVNum);
Individual.F2Decode = []; 
Individual.F2Infor = []; 
Individual.F2AGVextralT = zeros(2,Parameter.AGVNum); 
Individual.F2CriticalPath = [];  
Individual.F2CriticalBlock.B = struct;
Individual.F2CriticalBlock.C = struct;

Population = repmat(Individual,Parameter.NP,1);
