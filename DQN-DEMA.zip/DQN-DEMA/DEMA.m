% Copyright @ 20241120 Xinxin Zhou, All Rights Reserved.
% According to the article <Deep reinforcement learning-based memetic algorithm for solving dynamic distributed green flexible job shop scheduling problem...
%                           with finite transportation resources>
% DQN-Dynamic Efficient Memetic Algorithm->DQN-DEMA
% -------------------------------------------------------------------------

clear all; close all;clc; 
Casefile = 'Specify the file path';
Setupfile = 'Specify the file path';
Layoutfile = 'Specify the file path';
Benchmark = dlmread(Casefile);
Setup = dlmread(Setupfile);
Layout = dlmread(Layoutfile);
[Parameter] = Parameterset(Setup,Layout,Benchmark);
[Individual,Population] = Popinformation(Parameter); 

Population = InitialPop(Population,Parameter,1);
Population = AGVallocation(Population,Parameter,1);
Population = fitness(Population,Parameter);
Population = Dominated(Population);
Population = CrowdDistance(Population); 
%%
tic
[~,~,losses,rewardsPerEpisode] = DQNtraining(Population,Parameter); % Preliminary training
toc
%%
target_Q_network = load('Specify the file path','target_Q_network');
%%
tic
[Population,Parameter,Trace,Preschedule_Score,EliteIndividual,Preschedule,Preschedule_PF]= EMA(Parameter,Population,Individual,target_Q_network);
toc
%%
tic
finalreSchedule = [];
finalrePF = [];
totalbreakdownInfor.breakdown = zeros(size(Preschedule,1),5);
totalbreakdownInfor.fool = struct;
totalbreakdownInfortemp = [];
size(Preschedule,1)
for l = 1:size(Preschedule,1)
    l
    reschedule_individual = Preschedule(l); 
    [breakdown_fac,breakdown_time,repair_time,breakdown_machine,breakdown_pos] = generatebreakinfor(reschedule_individual,Parameter);
    information_pool = updatestate(reschedule_individual,Parameter,breakdown_fac,breakdown_time,repair_time,breakdown_machine);
    totalbreakdownInfor.breakdown(l,1) = breakdown_fac;
    totalbreakdownInfor.breakdown(l,2) = breakdown_time;
    totalbreakdownInfor.breakdown(l,3) = repair_time;
    totalbreakdownInfor.breakdown(l,4) = breakdown_machine;
    totalbreakdownInfor.breakdown(l,5) = breakdown_pos;
    totalbreakdownInfortemp = [totalbreakdownInfortemp;information_pool];
    totalbreakdownInfor.fool = totalbreakdownInfortemp;
    if information_pool.operation.Reschedule_operations <= 2 
        finalreSchedule = [finalreSchedule;reschedule_individual];
        continue
    end
    [reschedule_individual,need_reschedule] = adjust_encode(Parameter,reschedule_individual,information_pool);
    [rePopulation,rePreschedule_Score,rePreschedule,rePreschedule_PF,reEliteIndividual,reTrace] = DEMARescheduling(Individual,reschedule_individual,information_pool,Parameter,breakdown_fac,breakdown_time,breakdown_machine,repair_time,target_Q_network);
    finalreSchedule = [finalreSchedule;rePreschedule];  %#ok<*AGROW> 
end

finalfit = zeros(size(finalreSchedule,1),2);
for i = 1:size(finalreSchedule,1)
    fit = finalreSchedule(i).Fit;
    finalfit(i,:) = fit;
end
[~,ia] = unique(finalfit,'rows');
finalreSchedule = finalreSchedule(ia);
finalreSchedule = Dominated(finalreSchedule);
finalreSchedule = CrowdDistance(finalreSchedule);
finaldynamicrePF = finalreSchedule([finalreSchedule.Rank]'==1); 
finalPF = zeros(size(finaldynamicrePF,1),2);
for i = 1:size(finaldynamicrePF,1)
    fit = finaldynamicrePF(i).Fit;
    finalPF (i,:) = fit;
end
finalScore = ExperimentalIndicators(finalPF, Parameter);
toc
